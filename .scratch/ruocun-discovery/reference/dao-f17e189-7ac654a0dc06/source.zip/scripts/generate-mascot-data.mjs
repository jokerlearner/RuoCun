// 仅开发阶段从已验收 Sixel 资源再生成数据；正常 tsc/Bun 构建无需本机角色目录或 Sharp。
// 用法：node scripts/generate-mascot-data.mjs [manifest.json 路径]
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const repo = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const manifestPath = path.resolve(process.argv[2] || path.join(repo, '../.codex-analysis/ruocun-animated-preview/assets/manifest.json'));
const manifestDir = path.dirname(manifestPath);
const manifest = JSON.parse(await fs.readFile(manifestPath, 'utf8'));
const outputPath = path.join(repo, 'src/tui/mascot_frames.ts');
const sha256 = value => crypto.createHash('sha256').update(value).digest('hex');
const expectedIds = [0, 1, 2, 3, 12, 13];
if (manifest.width !== 256 || manifest.height !== 244 || !manifest.opaqueRaster
  || JSON.stringify(manifest.protocolBackground?.approximateRgb) !== '[10,15,28]') {
  throw new Error('需要已验收的 256×244 全矩形覆盖资源及背景 RGB(10,15,28)。');
}
if (!Array.isArray(manifest.frames) || JSON.stringify(manifest.frames.map(frame => frame.id).sort((a, b) => a - b)) !== JSON.stringify(expectedIds)) {
  throw new Error('需要已验收的 0、1、2、3、12、13 六帧。');
}
const frames = {};
const provenance = [];
let totalPayloadBytes = 0;
for (const frame of manifest.frames) {
  const file = path.resolve(manifestDir, frame.file);
  if (path.dirname(file) !== manifestDir) throw new Error(`帧文件必须位于 manifest 同目录：${frame.id}`);
  const bytes = await fs.readFile(file);
  if (bytes.length !== frame.bytes || sha256(bytes) !== frame.sha256) throw new Error(`帧 ${frame.id} 与验收清单不一致。`);
  const payload = bytes.toString('utf8');
  if (!payload.startsWith('\x1bP') || !payload.endsWith('\x1b\\')) throw new Error(`帧 ${frame.id} DCS 边界错误。`);
  if (!/^[a-f0-9]{64}$/i.test(frame.sourceSha256)) throw new Error(`帧 ${frame.id} 缺少原图 SHA256。`);
  frames[frame.id] = payload;
  totalPayloadBytes += bytes.length;
  provenance.push(` * frame-${String(frame.id).padStart(2, '0')}.png SHA256 ${frame.sourceSha256}`);
}
if (!Array.isArray(manifest.timeline) || !manifest.timeline.length) throw new Error('缺少已验收的动画时序。');
const timeline = manifest.timeline.map(({ frame, duration }) => {
  if (!Object.hasOwn(frames, frame) || !Number.isInteger(duration) || duration <= 0) throw new Error('动画时序无效。');
  return { frame, duration };
});

const source = `/**
 * 由 scripts/generate-mascot-data.mjs 从已验收的独立预览资源生成。
 * 来源：角色设计/N鲸鱼女仆-v1/frames。仅复用既有轻摆尾与眨眼帧；N 发卡等原角色细节保留。
 * 各帧已验证完整覆盖 256×244 矩形，源 PNG 未修改；运行时不读取外部路径或依赖 Sharp。
${provenance.join('\n')}
 */
export const MASCOT_FRAMES: Readonly<Record<number, string>> = ${JSON.stringify(frames, null, 2)};

export const MASCOT_TIMELINE: readonly { frame: number; duration: number }[] = ${JSON.stringify(timeline, null, 2)};

export const MASCOT_IMAGE = { width: 256, height: 244, background: [10, 15, 28] } as const;
`;
await fs.writeFile(outputPath, source, 'utf8');
console.log(JSON.stringify({ output: outputPath, bytes: Buffer.byteLength(source), frames: expectedIds,
  allPayloadHashesMatchManifest: true, totalPayloadBytes, periodMs: timeline.reduce((sum, item) => sum + item.duration, 0),
  runtimeExternalDependencies: [] }, null, 2));
