import { describe, it, expect } from "vitest";
import { parseHookOutput, loadHooks, selectHooks } from "./hooks.js";
import { mkdtempSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";

describe("parseHookOutput", () => {
  it("exit 2 -> block, stderr as reason", () => {
    expect(parseHookOutput("", "blocked!", 2)).toMatchObject({ block: true, reason: "blocked!" });
  });
  it("CC JSON hookSpecificOutput.additionalContext", () => {
    const out = parseHookOutput(JSON.stringify({ hookSpecificOutput: { hookEventName: "SessionStart", additionalContext: "HELLO" } }), "", 0);
    expect(out.additionalContext).toBe("HELLO");
  });
  it("top-level additionalContext / additional_context fallback", () => {
    expect(parseHookOutput(JSON.stringify({ additionalContext: "A" }), "", 0).additionalContext).toBe("A");
    expect(parseHookOutput(JSON.stringify({ additional_context: "B" }), "", 0).additionalContext).toBe("B");
  });
  it("permissionDecision / updatedInput", () => {
    const out = parseHookOutput(JSON.stringify({ hookSpecificOutput: { permissionDecision: "deny", updatedInput: { command: "ls" } } }), "", 0);
    expect(out.permissionDecision).toBe("deny");
    expect(out.updatedInput).toEqual({ command: "ls" });
  });
  it("non-JSON stdout becomes additionalContext", () => {
    expect(parseHookOutput("plain text", "", 0).additionalContext).toBe("plain text");
  });
});

describe("loadHooks (CC 嵌套格式)", () => {
  it("解外层 {hooks} + 嵌套 hooks[],规范化为 HookSpec[],带 pluginRoot", () => {
    const dir = mkdtempSync(path.join(tmpdir(), "hk-"));
    const f = path.join(dir, "hooks.json");
    writeFileSync(f, JSON.stringify({ hooks: { SessionStart: [
      { matcher: "startup|clear", hooks: [{ type: "command", command: "echo hi", timeout: 5000 }] },
    ] } }));
    const specs = loadHooks([{ path: f, pluginRoot: "/PLUGIN" }]);
    expect(specs).toHaveLength(1);
    expect(specs[0]).toMatchObject({ event: "SessionStart", matcher: "startup|clear", type: "command", command: "echo hi", timeout: 5000, pluginRoot: "/PLUGIN" });
  });
  it("裸 {event:[...]} 也接受(无外层 hooks 包)", () => {
    const dir = mkdtempSync(path.join(tmpdir(), "hk-"));
    const f = path.join(dir, "h2.json");
    writeFileSync(f, JSON.stringify({ PreToolUse: [{ matcher: "Write", hooks: [{ type: "command", command: "x", if: "Write(*.ts)" }] }] }));
    const specs = loadHooks([{ path: f }]);
    expect(specs[0]).toMatchObject({ event: "PreToolUse", matcher: "Write", if: "Write(*.ts)", type: "command", command: "x" });
  });
  it("坏文件跳过", () => {
    expect(loadHooks([{ path: "/no/such/file.json" }])).toEqual([]);
  });
});

const spec = (o: Partial<import("./hooks.js").HookSpec>): import("./hooks.js").HookSpec =>
  ({ event: "X", type: "command", command: "c", ...o } as import("./hooks.js").HookSpec);

describe("selectHooks", () => {
  it("工具事件:matcher 匹配工具名", () => {
    const specs = [spec({ event: "PreToolUse", matcher: "Write|Edit" }), spec({ event: "PreToolUse", matcher: "Bash" })];
    const sel = selectHooks(specs, "PreToolUse", { toolName: "Write", argsJson: "{}" });
    expect(sel).toHaveLength(1);
  });
  it("SessionStart:matcher 匹配来源", () => {
    const specs = [spec({ event: "SessionStart", matcher: "startup|clear" }), spec({ event: "SessionStart", matcher: "resume" })];
    expect(selectHooks(specs, "SessionStart", { source: "startup" })).toHaveLength(1);
  });
  it("无 matcher → 全选", () => {
    expect(selectHooks([spec({ event: "SessionStart" })], "SessionStart", { source: "resume" })).toHaveLength(1);
  });
});

import { runHooks } from "./hooks.js";

describe("runHooks (command + 合成)", () => {
  it("执行 command,解析 additionalContext,注入 CLAUDE_PLUGIN_ROOT", async () => {
    const specs = [spec({ event: "SessionStart", type: "command",
      command: `node -e 'process.stdout.write(JSON.stringify({hookSpecificOutput:{additionalContext:"ROOT="+process.env.CLAUDE_PLUGIN_ROOT}}))'`,
      pluginRoot: "/PR" })];
    const out = await runHooks(specs, "SessionStart", { cwd: process.cwd(), source: "startup" });
    expect(out.additionalContext).toContain("ROOT=/PR");
  });
  it("多 hook:permissionDecision 取 deny>ask>allow,context 拼接", async () => {
    const mk = (pd: string, ctx: string) => spec({ event: "PreToolUse", type: "command",
      command: `node -e 'process.stdout.write(JSON.stringify({hookSpecificOutput:{permissionDecision:"${pd}",additionalContext:"${ctx}"}}))'` });
    const out = await runHooks([mk("allow", "a"), mk("deny", "b"), mk("ask", "c")], "PreToolUse", { cwd: process.cwd(), toolName: "x", argsJson: "{}" });
    expect(out.permissionDecision).toBe("deny");
    expect(out.additionalContext).toContain("a"); expect(out.additionalContext).toContain("b");
  });
  it("exit 2 → block", async () => {
    const out = await runHooks([spec({ event: "PreToolUse", type: "command", command: `node -e 'process.stderr.write("NO");process.exit(2)'` })], "PreToolUse", { cwd: process.cwd(), toolName: "x", argsJson: "{}" });
    expect(out.block).toBe(true); expect(out.reason).toContain("NO");
  });
});
