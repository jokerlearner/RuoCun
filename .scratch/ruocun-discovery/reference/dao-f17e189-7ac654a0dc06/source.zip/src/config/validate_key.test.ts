import { describe, it, expect } from "vitest";
import { validateCredential, fetchModels } from "./validate_key.js";

const cred = { baseUrl: "https://api.deepseek.com", key: "sk-x" };

describe("validateCredential", () => {
  it("官方 GPT-6 用 Responses 探针,不因旧参数误拒有效凭证", async () => {
    let body: any;
    const fakeFetch = (async (url, init) => {
      expect(url).toBe("https://api.openai.com/v1/responses");
      body = JSON.parse(String(init?.body));
      return Response.json({ status: "completed", output: [] });
    }) as typeof fetch;
    expect(await validateCredential({ baseUrl: "https://api.openai.com/v1", key: "test", provider: "openai", model: "gpt-6.1-sol" }, fakeFetch)).toEqual({ ok: true });
    expect(body.max_output_tokens).toBe(16);
    expect(body).not.toHaveProperty("max_tokens");
  });
  it("calls the provider's /models endpoint with a Bearer header", async () => {
    let seenUrl = "";
    let seenAuth = "";
    const fakeFetch = async (url: string, init?: { headers?: Record<string, string> }) => {
      seenUrl = url;
      seenAuth = init?.headers?.Authorization ?? "";
      return { ok: true, status: 200 } as Response;
    };
    const r = await validateCredential(cred, fakeFetch as unknown as typeof fetch);
    expect(r.ok).toBe(true);
    expect(seenUrl).toBe("https://api.deepseek.com/models");
    expect(seenAuth).toBe("Bearer sk-x");
  });

  it("reports an invalid key on 401", async () => {
    const fakeFetch = async () => ({ ok: false, status: 401 } as Response);
    const r = await validateCredential(cred, fakeFetch as unknown as typeof fetch);
    expect(r).toEqual({ ok: false, reason: "invalid" });
  });

  it("reports unreachable when the request throws", async () => {
    const fakeFetch = async () => {
      throw new Error("ENOTFOUND");
    };
    const r = await validateCredential(cred, fakeFetch as unknown as typeof fetch);
    expect(r).toEqual({ ok: false, reason: "unreachable" });
  });

  it("reports an http error for other non-ok statuses", async () => {
    const fakeFetch = async () => ({ ok: false, status: 500 } as Response);
    const r = await validateCredential(cred, fakeFetch as unknown as typeof fetch);
    expect(r).toEqual({ ok: false, reason: "http", status: 500 });
  });
});

describe("validateCredential · volcengine probe", () => {
  const ark = { baseUrl: "https://ark.cn-beijing.volces.com/api/coding/v3", key: "ark-x", provider: "volcengine" as const };

  it("probes chat/completions with a tiny POST for volcengine", async () => {
    let seenUrl = ""; let seenMethod = "";
    const fakeFetch = async (url: string, init?: { method?: string }) => {
      seenUrl = url; seenMethod = init?.method ?? "GET";
      return { ok: true, status: 200 } as Response;
    };
    const r = await validateCredential(ark, fakeFetch as unknown as typeof fetch);
    expect(r.ok).toBe(true);
    expect(seenUrl).toBe("https://ark.cn-beijing.volces.com/api/coding/v3/chat/completions");
    expect(seenMethod).toBe("POST");
  });

  it("reports invalid on 401 for volcengine", async () => {
    const fakeFetch = async () => ({ ok: false, status: 401 } as Response);
    expect(await validateCredential(ark, fakeFetch as unknown as typeof fetch)).toEqual({ ok: false, reason: "invalid" });
  });

  it("reports unreachable when the volcengine probe throws", async () => {
    const fakeFetch = async () => { throw new Error("ENOTFOUND"); };
    expect(await validateCredential(ark, fakeFetch as unknown as typeof fetch)).toEqual({ ok: false, reason: "unreachable" });
  });

  it("still uses /models for deepseek (no provider given)", async () => {
    let seenUrl = "";
    const fakeFetch = async (url: string) => { seenUrl = url; return { ok: true, status: 200 } as Response; };
    await validateCredential({ baseUrl: "https://api.deepseek.com", key: "sk-x" }, fakeFetch as unknown as typeof fetch);
    expect(seenUrl).toBe("https://api.deepseek.com/models");
  });
});

describe("validateCredential · qianfan probe", () => {
  const qf = { baseUrl: "https://qianfan.baidubce.com/v2/tokenplan/personal", key: "qf-x", provider: "qianfan" as const };

  it("probes chat/completions with a tiny POST for qianfan", async () => {
    let seenUrl = ""; let seenMethod = "";
    const fakeFetch = async (url: string, init?: { method?: string }) => {
      seenUrl = url; seenMethod = init?.method ?? "GET";
      return { ok: true, status: 200 } as Response;
    };
    const r = await validateCredential(qf, fakeFetch as unknown as typeof fetch);
    expect(r.ok).toBe(true);
    expect(seenUrl).toBe("https://qianfan.baidubce.com/v2/tokenplan/personal/chat/completions");
    expect(seenMethod).toBe("POST");
  });

  it("reports invalid on 401 for qianfan", async () => {
    const fakeFetch = async () => ({ ok: false, status: 401 } as Response);
    expect(await validateCredential(qf, fakeFetch as unknown as typeof fetch)).toEqual({ ok: false, reason: "invalid" });
  });

  it("reports unreachable when the qianfan probe throws", async () => {
    const fakeFetch = async () => { throw new Error("ENOTFOUND"); };
    expect(await validateCredential(qf, fakeFetch as unknown as typeof fetch)).toEqual({ ok: false, reason: "unreachable" });
  });
});

describe("validateCredential · zhipu probe", () => {
  const zp = { baseUrl: "https://open.bigmodel.cn/api/coding/paas/v4", key: "zp-x", provider: "zhipu" as const };

  it("probes chat/completions with a tiny POST for zhipu, using the provider default model glm-5.3", async () => {
    let seenUrl = ""; let seenMethod = ""; let seenBody = "";
    const fakeFetch = async (url: string, init?: { method?: string; body?: string }) => {
      seenUrl = url; seenMethod = init?.method ?? "GET"; seenBody = init?.body ?? "";
      return { ok: true, status: 200 } as Response;
    };
    const r = await validateCredential(zp, fakeFetch as unknown as typeof fetch);
    expect(r.ok).toBe(true);
    expect(seenUrl).toBe("https://open.bigmodel.cn/api/coding/paas/v4/chat/completions");
    expect(seenMethod).toBe("POST");
    expect(JSON.parse(seenBody).model).toBe("glm-5.3"); // zhipu 端点没有 deepseek 系,不能沿用写死的 flash
  });

  it("reports invalid on 401 for zhipu", async () => {
    const fakeFetch = async () => ({ ok: false, status: 401 } as Response);
    expect(await validateCredential(zp, fakeFetch as unknown as typeof fetch)).toEqual({ ok: false, reason: "invalid" });
  });

  it("reports unreachable when the zhipu probe throws", async () => {
    const fakeFetch = async () => { throw new Error("ENOTFOUND"); };
    expect(await validateCredential(zp, fakeFetch as unknown as typeof fetch)).toEqual({ ok: false, reason: "unreachable" });
  });
});

describe("validateCredential · custom gateway model probe", () => {
  const gw = { baseUrl: "http://llm-gw.jd.local/v1", key: "gw-x", provider: "deepseek" as const, model: "GLM-5.3-joybuilder" };

  it("probes chat/completions with the chosen model when model is given (avoids 4012)", async () => {
    let seenUrl = ""; let seenMethod = ""; let seenBody = "";
    const fakeFetch = async (url: string, init?: { method?: string; body?: string }) => {
      seenUrl = url; seenMethod = init?.method ?? "GET"; seenBody = init?.body ?? "";
      return { ok: true, status: 200 } as Response;
    };
    const r = await validateCredential(gw, fakeFetch as unknown as typeof fetch);
    expect(r.ok).toBe(true);
    expect(seenUrl).toBe("http://llm-gw.jd.local/v1/chat/completions");
    expect(seenMethod).toBe("POST");
    expect(JSON.parse(seenBody).model).toBe("GLM-5.3-joybuilder"); // 用选中 model 探针,而非写死 flash
  });

  it("reports http (not ok) when the model is unauthorized", async () => {
    const fakeFetch = async () => ({ ok: false, status: 400 } as Response); // 京东网关 4012 走 HTTP 400
    expect(await validateCredential(gw, fakeFetch as unknown as typeof fetch)).toEqual({ ok: false, reason: "http", status: 400 });
  });
});

describe("fetchModels", () => {
  const baseUrl = "http://llm-gw.jd.local/v1";

  it("GET /models with Bearer, returns data[].id list", async () => {
    let seenUrl = ""; let seenAuth = "";
    const fakeFetch = async (url: string, init?: { headers?: Record<string, string> }) => {
      seenUrl = url; seenAuth = init?.headers?.Authorization ?? "";
      return { ok: true, status: 200, json: async () => ({ data: [{ id: "GLM-5.3-joybuilder" }, { id: "DeepSeek-V4-Pro-joybuilder" }] }) } as unknown as Response;
    };
    const ids = await fetchModels(baseUrl, "gw-x", fakeFetch as unknown as typeof fetch);
    expect(ids).toEqual(["GLM-5.3-joybuilder", "DeepSeek-V4-Pro-joybuilder"]);
    expect(seenUrl).toBe("http://llm-gw.jd.local/v1/models");
    expect(seenAuth).toBe("Bearer gw-x");
  });

  it("returns [] on non-ok (gateway without /models)", async () => {
    const fakeFetch = async () => ({ ok: false, status: 404 } as Response);
    expect(await fetchModels(baseUrl, "gw-x", fakeFetch as unknown as typeof fetch)).toEqual([]);
  });

  it("returns [] when the request throws", async () => {
    const fakeFetch = async () => { throw new Error("ENOTFOUND"); };
    expect(await fetchModels(baseUrl, "gw-x", fakeFetch as unknown as typeof fetch)).toEqual([]);
  });

  it("filters out non-string / empty ids", async () => {
    const fakeFetch = async () => ({ ok: true, status: 200, json: async () => ({ data: [{ id: "ok" }, { id: 42 }, { id: "" }, {}] }) } as unknown as Response);
    expect(await fetchModels(baseUrl, "gw-x", fakeFetch as unknown as typeof fetch)).toEqual(["ok"]);
  });
});
