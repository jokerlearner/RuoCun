#!/usr/bin/env node
import { createDeckBridge } from "./agent/deck_bridge.js";
import { recoverBackground, repairToolPairs } from "./session/recovery.js";
import type { SessionStore } from "./session/log.js";
import { runShellRunner } from "./tools/shell_runner.js";
import { getBackend } from "./obs/backend.js";
import { BackgroundRuntime } from "./agent/background_runtime.js";
import { SessionScheduler } from "./agent/session_scheduler.js";
import type { TurnOutcome } from "./agent/background_types.js";
import { taskWaitTool } from "./tools/task_wait.js";
import { plainEvents, type TurnEvents } from "./tui/render.js";
import { createInterface, type Interface } from "node:readline/promises";
import { readFileSync, mkdirSync, writeFileSync, readdirSync, rmSync } from "node:fs";
import { promises as fs } from "node:fs";
import { execSync } from "node:child_process";
import path from "node:path";
import os from "node:os";
import { pathToFileURL } from "node:url";
import { loadProfiles, saveProfiles, setActive, removeProfile } from "./config/profiles_store.js";
import { DEFAULTS, MODELS_BY_PROVIDER, contextWindowFor, type Provider, type ResolvedCredential } from "./config/profiles.js";
import { createClassifierRunner, defaultClassifierModel } from "./permissions/classifier_model.js";
import { resolveExtractModel } from "./tools/fetch_extract.js";
import { getAgentModel } from "./config/model_selection.js";
import { resolveCredential, persistKey } from "./config/credential.js";
import { validateCredential, fetchModels } from "./config/validate_key.js";
import { runtimeKeychain, noopKeychain, keychainAvailable, keychainDelete } from "./config/keychain.js";
import { migrateLegacyDir } from "./config/migrate_dirs.js";
import { streamChat as streamChatRaw, isContextLengthError, isRateLimitError } from "./client/client.js";
import { runTurn as runTurnRaw, sanitizeHistoryForResume } from "./agent/loop.js";
import { executeToolCalls as executeToolCallsRaw } from "./tools/execute.js";
import { initObs, wrapStreamChat, wrapRunTurn, wrapToolExec, flushObs, setObsSession, setObsMeta, obsStatus } from "./obs/index.js";
import { applyDotenv } from "./config/env_file.js";
import { ToolRegistry } from "./tools/registry.js";
import { readFileTool } from "./tools/read_file.js";
import { listDirTool } from "./tools/list_dir.js";
import { writeFileTool } from "./tools/write_file.js";
import { editFileTool } from "./tools/edit_file.js";
import { notebookEditTool } from "./tools/notebook_edit.js";
import { installSkills } from "./skills/install.js";
import { scheduleAdd, scheduleList, scheduleRemove } from "./schedule.js";
import { scheduleTool } from "./tools/schedule_tool.js";
import { skillInstallTool } from "./tools/skill_install.js";
import { loadPlugins, installPlugin, removePlugin, pluginsRoot, pluginComponentDirs } from "./plugins.js";
import { loadProjectInstructions } from "./project_doc.js";
import { gatherEnvSnapshotData, formatEnvSnapshot, probeTopLevelDir, probeMemory, formatFastEnvFields, wrapDelayedEnvNotice } from "./env_snapshot.js";
import { execShellTool, cleanupDbBackups } from "./tools/exec_shell.js";
import { execShellPollTool } from "./tools/exec_shell_poll.js";
import { execShellKillTool } from "./tools/exec_shell_kill.js";
import { grepFilesTool } from "./tools/grep_files.js";
import { fileSearchTool } from "./tools/file_search.js";
import { askUserTool } from "./tools/ask_user.js";
import { fetchUrlTool } from "./tools/fetch_url.js";
import { webSearchTool } from "./tools/web_search.js";
import { todoWriteTool } from "./tools/todo_write.js";
import { memoryWriteTool } from "./tools/memory_write.js";
import { memoryReadTool } from "./tools/memory_read.js";
import { runAgent } from "./agent/runAgent.js";
import { resolveLang, setLang, getLang, t, readUserLang, writeUserLang } from "./i18n/i18n.js";
import { createTaskManager } from "./agent/tasks.js";
import { createForegroundRegistry } from "./tui/foreground_registry.js";
import { loadAgentDefs, type AgentDef } from "./agent/agent_defs.js";
import { BUNDLED_AGENTS } from "./agent/bundled_agents.js";
import { formatAgentLine } from "./agent/agent_prompt.js";
import { parseHandoffClassifierResponse, type ClassifyResult } from "./agent/agent_handoff.js";
import { resumeAgentBackground } from "./agent/resume_agent.js";
import { createWorktree } from "./agent/worktree.js";
import { runDiagnosticsCmd, detectDiagnosticsCmd } from "./tools/diagnostics.js";
import { shouldTrustProject, addTrusted } from "./config/trust.js";
import { maybeCleanup } from "./agent/cleanup.js";
import { maybeCheckUpdate } from "./config/update_check.js";
import { notify } from "./tui/notifier.js";
import { acquireWakeLock } from "./tui/wakelock.js";
import { loadCustomCommands, expandCommand, type CustomCommand } from "./commands/custom.js";
import { loadSkills, findUserInvocableSkill, skillCatalogLines } from "./skills/skills.js";
import { BUNDLED_SKILLS, toggleBundled } from "./skills/bundled.js";
import { loadUsage, saveUsage, recordUsage } from "./skills/usage.js";
import { makeSkillAdapter } from "./skills/convert.js";
import { skillTool } from "./tools/skill.js";
import { taskSendTool } from "./tools/task_send.js";
import { messageParentTool } from "./tools/message_parent.js";
import { notifyUserTool } from "./tools/notify_user.js";
import { toolSearchTool } from "./tools/tool_search.js";
import { taskCreateTool } from "./tools/task_create.js";
import { taskListTool } from "./tools/task_list.js";
import { taskGetTool } from "./tools/task_get.js";
import { taskOutputTool } from "./tools/task_output.js";
import { monitorTool } from "./tools/monitor.js";
import { taskUpdateTool } from "./tools/task_update.js";
import { taskStopTool } from "./tools/task_stop.js";
import { enterPlanModeTool, exitPlanModeTool } from "./tools/plan_mode.js";
import { enterWorktreeTool } from "./tools/enter_worktree.js";
import { exitWorktreeTool } from "./tools/exit_worktree.js";
import { configTool } from "./tools/config.js";
import { sendMessageTool } from "./tools/send_message.js";
import { cronCreateTool, cronDeleteTool, cronListTool } from "./tools/cron_tools.js";
import { loadHooks, runHooks } from "./hooks/hooks.js";
import { loadMcpConfig, McpManager, type ElicitHandler } from "./mcp/mcp.js";
import { loadLspConfig } from "./lsp/config.js";
import { LspManager } from "./lsp/manager.js";
import { lspTool } from "./tools/lsp.js";
import { repoMapTool } from "./tools/repo_map.js";
import { buildRepoMap, wrapRepoMapNotice, repoMapTokenBudget } from "./repomap/index.js";
import { processManager } from "./tools/process_manager.js";
import { agentTool } from "./tools/agent.js";
import { loadAllMemories, upsertMemory, migrateLegacy, routeScope, projectIdOf, keepKnowledgeForProject } from "./memory/store.js";
import { gatherAudit, formatAudit } from "./memory/audit.js";
import { buildClassifierMessages, parseXmlBlock, parseXmlReason, STAGE1_SUFFIX, STAGE2_SUFFIX, type AutoModeRules } from "./permissions/classifier.js";
import { validateMemory, type Verdict } from "./memory/validate.js";
import { buildMemorySection, selectFullText, selectIndexNames, buildIndexSection } from "./memory/inject.js";
import { reflect as unifiedReflect } from "./agent/unified_reflect.js";
import { initCadence, tickCadence, applyOutcome } from "./agent/reflect_cadence.js";
import { reflectMemToCand, applyCorrections, applyConfirmed } from "./agent/reflect_persist.js";
import { apiToolsForMode } from "./tools/tools_for_mode.js";
import { CHALLENGER_PROMPT, REFOCUSER_PROMPT } from "./agent/reflect_prompts.js";
import { gcMemories } from "./memory/gc.js";
import { maybeConsolidate } from "./memory/consolidate.js";
import type { ApprovalGate } from "./approval/types.js";
import { makeApprovalPrompt } from "./approval/stdin_prompt.js";
import { loadAlwaysApproved, appendAlwaysApproved } from "./approval/store.js";
import { PermissionGate } from "./permissions/gate.js";
import { loadPermissions, mergePermissions, appendRule, appendRuleSync, removeRule, removeRuleSync, enterpriseSettingsPath, extractCliPermissions, type PermissionMode } from "./permissions/settings.js";
import { buildSystemPrompt, LONG_TASK_DIRECTIVE, LONG_TASK_DIRECTIVE_EN } from "./prompt/system_prompt.js";
import { Session } from "./session/session.js";
import { createSessionStore, logEvents, findResumable, loadState, listSessions, firstUserExcerpt } from "./session/log.js";
import { createCacheAuditSink, type CacheAuditSink, formatCacheReport } from "./session/cache_audit.js";
import { auditEnabled } from "./session/audit_switch.js";
import { createMemoryAuditSink, type MemoryAuditSink, summarizeMemoryTrace, formatMemoryReport, summarizeReflectTrace, formatReflectReport } from "./memory/memory_audit.js";
import { createToolAuditSink, type ToolAuditSink, summarizeToolTrace, formatToolReport } from "./tools/tool_audit.js";
import { createPermAuditSink, type PermAuditSink, summarizePermTrace, formatPermReport } from "./permissions/perm_audit.js";
import { createSkillAuditSink, type SkillAuditSink, readAllSkillTraces, summarizeSkillTrace, formatSkillReport } from "./skills/skill_audit.js";
import { createCheckpointer } from "./session/checkpoint.js";
import { runRepl } from "./repl.js";
import { dispatchCommand } from "./commands/commands.js";
import { runBuiltinCommand } from "./commands/builtin.js";
import { buildWelcome } from "./tui/banner.js";
import { detectCapabilities } from "./tui/capabilities.js";
import { resolveBackground } from "./tui/background.js";
import { randomMaxim } from "./tui/maxim.js";
import { runInkApp } from "./tui/app/run.js";
import { runOnboarding } from "./tui/onboarding/run.js";
import { walkFiles } from "./tools/walk.js";
import { globToRegExp } from "./tools/glob.js";
import type { ApprovalPrompt } from "./approval/types.js";
import { VERSION } from "./version.js";
import { compactMessages, estimateTokens } from "./agent/compact.js";
import { todoStore, formatTodos } from "./tools/todo_store.js";
import type { ChatMessage } from "./client/types.js";
import type { ToolContext } from "./tools/types.js";
import type { TranscriptItem } from "./tui/app/types.js";

// 续跑时,把历史消息重建成可见的 transcript(只回放 user/assistant 文本;工具细节在日志里)。
function transcriptFromMessages(messages: ChatMessage[]): TranscriptItem[] {
  const out: TranscriptItem[] = [];
  let id = 1;
  for (const m of messages) {
    if (m.role === "user" && typeof m.content === "string") out.push({ id: id++, kind: "user", text: m.content });
    else if (m.role === "assistant" && typeof m.content === "string" && m.content.trim())
      out.push({ id: id++, kind: "assistant", text: m.content });
  }
  return out;
}

// 读 settings.json 的 checkpoint.enabled:项目级 > 用户级;缺失/损坏 → false(默认关闭)。
async function readCheckpointEnabled(userFile: string, projectFile: string | null): Promise<boolean> {
  const readVal = async (file: string): Promise<boolean | undefined> => {
    try {
      const raw = await fs.readFile(file, "utf8");
      const v = (JSON.parse(raw) as { checkpoint?: { enabled?: unknown } }).checkpoint?.enabled;
      return typeof v === "boolean" ? v : undefined;
    } catch { return undefined; }
  };
  const projectVal = projectFile ? await readVal(projectFile) : undefined;
  const userVal = await readVal(userFile);
  return projectVal ?? userVal ?? false;
}

async function main() {
  // 退出/中断时清理所有后台进程,避免孤儿(长任务里模型常起 dev server/watch)。
  // 但一次性 headless 调用(argvPrompt,eval/脚本化场景的主要形态)正常跑完退出时不清——
  // 这类调用常常就是靠 background:true 起一个任务要求"保持运行"的服务(见 Bash 工具描述),
  // 退出就杀等于把这个用法废掉;isHeadlessOneShot 在下面 argvPrompt 算出来后回填,
  // 处理函数注册要趁早(即便早期崩溃也能兜底清理),用闭包变量而非把注册挪到 argvPrompt 之后。
  // SIGINT/SIGTERM 是显式中断信号,不管什么模式都应该清——用户/上层主动喊停就是要停干净。
  let cleaned = false;
  let isHeadlessOneShot = false;
  const cleanup = () => {
    if (!cleaned) {
      cleaned = true;
      if (!isHeadlessOneShot) { try { processManager.reset(); } catch {} }
    }
  };
  const cleanupForce = () => { if (!cleaned) { cleaned = true; } try { processManager.reset(); } catch {} };
  process.on("exit", cleanup);
  process.on("SIGINT", async () => { cleanupForce(); await flushObs(); process.exit(130); });
  process.on("SIGTERM", async () => { cleanupForce(); await flushObs(); process.exit(143); });

  const rawArgs = process.argv.slice(2);
  // 启动即加载工作目录 .env(如 LMNR_PROJECT_API_KEY):仅补未设置的键,真实 env 变量优先。
  // 放在 initObs 之前,让 --obs 无需手动 export 即可从 .env 拿到 key。
  await applyDotenv(`${process.cwd()}/.env`);
  // 观测旁路:仅 --obs 时动态 import Laminar 初始化;三个包装 const 遮蔽原 import 名,
  // 关闭时 wrap* 返回原函数(引用相等、零开销),main() 内所有引用自动走包装版。
  await initObs(rawArgs.includes("--obs"));
  setObsMeta({ version: VERSION }); // trace 级元数据:按 dao 版本号过滤(空开销,obs 关时被忽略)
  // obs 状态标签(交互模式可见,避免降级了却无声无息);未请求观测则返回空串(不显示)。
  const obsLabel = (): string => {
    const s = obsStatus();
    if (!s.requested) return "";
    return s.on ? `obs→${s.endpoint}` : "obs降级(检查 LMNR_PROJECT_API_KEY)";
  };
  const streamChat = wrapStreamChat(streamChatRaw);
  const runTurn = wrapRunTurn(runTurnRaw);
  // wrapToolExec 的 ToolExecFn 刻意用 unknown 解耦 obs↔core;strictFunctionTypes 下
  // 具体入参函数无法逆变赋给 unknown 入参签名,故在组合根用 cast 桥接(仅入参类型,返回值仍为 ToolMessage[])。
  const executeToolCalls = wrapToolExec(executeToolCallsRaw as unknown as Parameters<typeof wrapToolExec>[0]);
  // --version/-v 必须在任何初始化(读配置/连 API)之前拦下,否则整句会被当 prompt 发给模型。
  if (rawArgs.includes("--version") || rawArgs.includes("-v")) {
    process.stdout.write(`dao-code v${VERSION}\n`);
    return;
  }
  // 操作员命令:dao trust —— 信任当前目录,允许加载其项目级 .dao/settings.json 与 hooks.json。不连 API。
  if (rawArgs[0] === "trust") {
    const cwd = process.cwd();
    await addTrusted(cwd);
    process.stdout.write(`✓ 已信任 ${cwd}(下次启动将加载其 .dao/settings.json 与 hooks.json)\n`);
    return;
  }
  // 操作员命令:dao schedule add|list|remove —— 本地 OS crontab 定时跑 headless dao。不连 API。
  if (rawArgs[0] === "Schedule") {
    const sub = rawArgs[1];
    const w = (s: string) => process.stdout.write(s);
    try {
      if (sub === "add") {
        const cron = rawArgs[2], prompt = rawArgs.slice(3).join(" ");
        if (!cron || !prompt) { process.stderr.write('用法:dao schedule add "<cron 5 字段>" "<prompt>"\n'); process.exit(1); }
        await scheduleAdd(cron, prompt, process.cwd(), process.execPath, w);
      } else if (sub === "list") {
        await scheduleList(w);
      } else if (sub === "remove") {
        await scheduleRemove(Number(rawArgs[2]), w);
      } else {
        process.stderr.write("用法:dao schedule <add \"<cron>\" \"<prompt>\" | list | remove <n>>\n");
        process.exit(1);
      }
    } catch (e) { process.stderr.write(`schedule 失败:${(e as Error).message}\n`); process.exit(1); }
    return;
  }
  // 操作员命令:dao plugin add|list|remove —— 插件(打包 skills,~/.dao/plugins/<名>/)。不连 API。
  if (rawArgs[0] === "plugin") {
    const sub = rawArgs[1];
    const w = (s: string) => process.stdout.write(s);
    try {
      if (sub === "add" && rawArgs[2]) await installPlugin(rawArgs[2], w);
      else if (sub === "list") {
        const ps = await loadPlugins();
        w(ps.length ? "已装插件:\n" + ps.map((p) => `  ${p.name} — ${p.description}`).join("\n") + "\n" : "未装任何插件。\n");
      } else if (sub === "remove" && rawArgs[2]) await removePlugin(rawArgs[2], w);
      else { process.stderr.write("用法:dao plugin <add <git-url|路径> | list | remove <名>>\n"); process.exit(1); }
    } catch (e) { process.stderr.write(`plugin 失败:${(e as Error).message}\n`); process.exit(1); }
    return;
  }
  // 操作员命令:dao skill add <git-url|本地路径> [--user|--project]。不连 API,装完即退。
  if (rawArgs[0] === "Skill" && rawArgs[1] === "add") {
    const rest = rawArgs.slice(2);
    const source = rest.find((a) => !a.startsWith("--"));
    const scope: "user" | "project" = rest.includes("--project") ? "project" : "user"; // 默认用户级(技能多为通用)
    if (!source) { process.stderr.write("用法:dao skill add <git-url|本地路径> [--user|--project]\n"); process.exit(1); }
    try {
      await installSkills(source, scope, process.cwd(), (s) => process.stdout.write(s));
    } catch (e) {
      process.stderr.write(`安装失败:${(e as Error).message}\n`);
      process.exit(1);
    }
    return;
  }
  const yoloFlag = rawArgs.includes("--yolo");
  const continueFlag = rawArgs.includes("--continue") || rawArgs.includes("-c");
  // --continue/-c 可选带一个显式会话 id(如 dao -c 20260717-143212-b8wt),直接续写那一个会话文件;
  // 不给就续写"最近一个可续写的会话"(findResumable)。取值规则:紧跟在 --continue/-c 后面、且本身
  // 不是另一个已知 flag 的 token——否则这个 id 会被当成普通文本,连同别的内容一起被误发成一次性
  // 提示词发给模型(真实撞见过:dao -c <id> 里的 id 被当 argvPrompt 直接发出去,触发一次真实 API 调用)。
  const continueFlagIdx = (() => { const i = rawArgs.indexOf("--continue"); return i >= 0 ? i : rawArgs.indexOf("-c"); })();
  const continueArgRaw = continueFlagIdx >= 0 ? rawArgs[continueFlagIdx + 1] : undefined;
  const cliResumeId = continueArgRaw && !continueArgRaw.startsWith("-") ? continueArgRaw : undefined;
  const taskFlag = rawArgs.includes("--goal") || rawArgs.includes("--task") || rawArgs.includes("--coordinator"); // --task/--coordinator 为旧别名,均进长任务自主模式(已并入)
  // 回合末"统一反思器"(反思进展 + 抽/改记忆)默认关闭,--reflect-memory 启动时显式开启才跑。
  // 启动时定一次、会话全程不变——中途切换会让系统提示词字节变化,废掉整段对话的前缀缓存。
  const reflectMemoryFlag = rawArgs.includes("--reflect-memory");
  // 轮内"确定性卡住检测"(assessTurn→挑战者/纠偏者 fork)同样默认关闭,--reflect-challenger 才开。
  // 这是另一套独立机制(不依赖 --reflect-memory),之前一直无条件跑(仅一次性 headless 因
  // argvPrompt 而被跳过),交互态/非 TTY 多轮管道下每轮都在算 + 命中阈值就 fork 一次 LLM 调用。
  const reflectChallengerFlag = rawArgs.includes("--reflect-challenger");
  // --eval:评测模式糖,等价于同时 --no-memory --no-skills --no-mcp --no-project-instructions --no-web。
  // 每个子开关也可单独使用。--no-skills 的隔离范围覆盖"磁盘/插件自定义"通道:
  // 磁盘/插件技能 + 自定义子代理定义(.dao/agents)+ 自定义 slash 命令(.dao/commands)——三者都是同一类
  // 用户/项目/插件自带的、会改变模型行为的注入源,不隔离会让评测结果混入本机个性化配置的影响。
  // DAO 自带的内置技能(BUNDLED_SKILLS)和 hooks 不受 --eval 影响:它们是 DAO 本身能力的一部分,
  // 不是"本机个性化配置",评测时应该像真实使用一样可用;仍可用 --no-skills/--no-hooks 单独关闭。
  // --no-web 关 WebSearch/WebFetch(和 MCP 同属"外部、不受控的信息源"):terminal-bench
  // polyglot-rust-c 真实撞见过模型联网搜到并抓取了该题带 canary GUID 的官方 solve.sh 全文
  // (2026-07-30 真实复测)——这类基准任务的参考答案已被公开镜像到 GitHub,评测时开着网络工具
  // 就是给模型一条查答案的路,而不是在测真实解题能力,污染的是 reward 本身,不是某道具体题的
  // 结果。这两个工具会连公网抓取任意内容,污染风险和 MCP server 是同一类,理应和 MCP 一起归入
  // "评测保持纯净"的默认关闭范围。
  const evalFlag = rawArgs.includes("--eval");
  // 进度提醒(noProgress 计数器,连续 N 轮无实质推进就追加静态提醒)【仅 headless 默认开启】,
  // --no-progress-advice 显式关;交互式会话(TTY 且非一次性调用)默认不启用——有人盯着,
  // 卡没卡用户自己看得见,提醒只会打断正常工作流。它保护的是无人值守场景(headless/eval/长任务)。
  // 和上面 reflectChallengerFlag 是两套独立机制(这个是纯本地计数器,不 fork LLM 调用),互不影响。
  // 2026-07-19 的 f939ddf 曾把它改成需要显式 --progress-advice 才开,而真实评测从未传过这个参数,
  // 等于在所有无人值守长任务里静默失去了这道保险(真实案例:一道题的历史通过 trace 里提醒在第 5 轮
  // 触发、触发后模型立刻收敛写完,回归后同一题再没通过过)。同时判据已修正为"改动文件或执行命令"
  // (见 loop.ts 的 PROGRESS_TOOLS),误触发率比当初关掉它的时候低得多。
  // 交互式会话(TTY 且非一次性 prompt)默认不开进度提醒——有人盯着,卡没卡用户看得见,
  // 提醒只会打断正常工作流。真正的判定见下方 progressAdviceFlag(要等 argvPrompt 解析完,
  // 才能准确区分交互式与 headless;此处 rawArgs 里 -c/--model 等的【值】不以 - 开头,
  // 天真地扫位置参数会把 `dao -c <session-id>` 的 id 误当 prompt → 交互式下误开提醒)。
  const noMemory = evalFlag || rawArgs.includes("--no-memory");
  // 只管磁盘/插件技能 + 自定义子代理/命令,不管内置技能(见下面 noBuiltinSkills)。
  const noSkills = evalFlag || rawArgs.includes("--no-skills");
  // 内置技能单独一个开关,--eval 不隐含它,只有显式 --no-skills 才关。
  const noBuiltinSkills = rawArgs.includes("--no-skills");
  const noMcp = evalFlag || rawArgs.includes("--no-mcp");
  const noHooks = rawArgs.includes("--no-hooks");
  // 项目/用户级自定义指令(DAO.md,CLAUDE.md 的 DAO 对应物)。之前一直无条件加载并注入系统提示词,
  // --eval 完全没覆盖到——同样是"用户自定义、会改变模型行为"的影响源,单独给一个子开关。
  const noProjectInstructions = evalFlag || rawArgs.includes("--no-project-instructions");
  const noWeb = evalFlag || rawArgs.includes("--no-web");
  const verbose = rawArgs.includes("--verbose") || rawArgs.includes("--debug");
  // headless 临时 key:--api-key <key> + --provider <deepseek|volcengine|qianfan|zhipu|...>
  const apiKeyIdx = rawArgs.indexOf("--api-key");
  const cliApiKey = apiKeyIdx >= 0 ? rawArgs[apiKeyIdx + 1] : undefined;
  const providerIdx = rawArgs.indexOf("--provider");
  const cliProviderRaw = providerIdx >= 0 ? rawArgs[providerIdx + 1] : undefined;
  const cliProvider = (cliProviderRaw === "deepseek" || cliProviderRaw === "volcengine" || cliProviderRaw === "qianfan" || cliProviderRaw === "zhipu" || cliProviderRaw === "anthropic" || cliProviderRaw === "openai") ? cliProviderRaw : undefined;
  const flags = new Set(["--yolo", "--continue", "-c", "--goal", "--task", "--coordinator", "--verbose", "--debug", "--api-key", "--provider", "--model", "--obs", "--reflect-memory", "--reflect-challenger", "--progress-advice", "--no-progress-advice", "--eval", "--no-memory", "--no-skills", "--no-mcp", "--no-hooks", "--no-project-instructions", "--no-web"]);
  // 同时把每个 flag 后面的参数值也加进 flags(避免被拼成 prompt)
  if (cliApiKey) flags.add(cliApiKey);
  if (cliProviderRaw) flags.add(cliProviderRaw);
  if (cliResumeId) flags.add(cliResumeId);
  const modelIdx = rawArgs.indexOf("--model");
  const cliModel = modelIdx >= 0 ? rawArgs[modelIdx + 1] : undefined;
  if (cliModel) flags.add(cliModel);
  // 先抽取 CLI 权限规则/模式(--allow/--deny/--add-dir/--permission-mode),其余再去掉布尔 flag 作 prompt。
  const { config: cliPerms, rest: argsAfterPerms } = extractCliPermissions(rawArgs);
  const argvPrompt = argsAfterPerms.filter((a) => !flags.has(a)).join(" ").trim();
  isHeadlessOneShot = !!argvPrompt; // 回填给上面注册好的 exit cleanup 用
  const workspaceRoot = process.cwd();
  // 尽早起、晚点等:与下面 onboarding/凭证解析等慢流程重叠执行,常见路径下不额外拖启动时延。
  const envSnapshotPromise = gatherEnvSnapshotData(workspaceRoot).catch(() => null);
  // 语言先于迁移提示解析:readUserLang 读 ~/.dao/settings.json(缺失→undefined,容错),
  // resolveLang 再回退 env/locale/en;迁移读写 .codeds→.dao 与语言无关,故安全前置。
  setLang(resolveLang(process.env, await readUserLang()));
  // codeds → DAO CODE 改名:一次性把旧 .codeds/ 数据(项目级+用户级)整体迁到 .dao/。
  // 必须在任何 .dao 路径被读写之前做;失败不阻塞启动(等价于全新环境)。
  for (const base of [workspaceRoot, os.homedir()]) {
    const r = await migrateLegacyDir(path.join(base, ".codeds"), path.join(base, ".dao")).catch(() => "absent" as const);
    if (r === "migrated") process.stdout.write(`${t("ui.migrated", path.join(base, ".codeds"), path.join(base, ".dao"))}\n`);
  }
  const approvalsFile = path.join(workspaceRoot, ".dao", "approvals.json");
  const keyFile = path.join(os.homedir(), ".dao", "config.json");

  const write = (s: string) => process.stdout.write(s);

  // 背景(亮/暗)检测:env 显式(DAO_THEME/COLORFGBG)> OSC 11 向终端查背景色 > 默认 dark。
  // 在 readline(懒创建)与 Ink 之前做,stdin 干净;OSC 完成即恢复。非 TTY 立即回退,不阻塞 eval。
  const bg = await resolveBackground(process.env);

  // 懒创建 readline:仅「key 引导 / 非 TTY 纯文本 REPL」需要。
  // Ink 交互态绝不创建 readline——readline 会接管 stdin,其 create+close 周期会破坏 stdin 状态,
  // 导致 Ink 接管后立刻收到 EOF/退出(表现为渲染一帧就退回 shell)。不碰它,Ink 的 useInput keep-alive 才正常。
  let rl: Interface | null = null;
  const lineQueue: string[] = [];
  const lineWaiters: Array<(line: string | null) => void> = [];
  let rlClosed = false;
  const ensureRl = () => {
    if (rl) return rl;
    rl = createInterface({ input: process.stdin, output: process.stdout });
    rl.on("line", (line) => {
      const w = lineWaiters.shift();
      if (w) w(line);
      else lineQueue.push(line);
    });
    rl.on("close", () => {
      rlClosed = true;
      for (const w of lineWaiters) w(null);
      lineWaiters.length = 0;
    });
    return rl;
  };
  const closeRl = () => {
    if (rl) rl.close();
  };
  const nextLine = (): Promise<string | null> => {
    ensureRl();
    if (lineQueue.length) return Promise.resolve(lineQueue.shift()!);
    if (rlClosed) return Promise.resolve(null);
    return new Promise((res) => lineWaiters.push(res));
  };
  const ask = async (prompt: string): Promise<string> => {
    write(prompt);
    const line = await nextLine();
    return line ?? "";
  };

  // ---- 解析当前生效凭证:CLI --api-key(如有) > 激活 profile(钥匙串/文件)> 首次运行引导 ----
  // 交互模式只有 profile 一条路径;headless 通过 --api-key + --provider CLI 参数传入。
  const kc = keychainAvailable() ? runtimeKeychain : noopKeychain; // keychain 优先,文件兜底
  let profilesCfg = await loadProfiles(keyFile); // 自动迁移旧版 { apiKey }
  let resolved: ResolvedCredential | null = null;
  if (cliApiKey && cliProvider) {
    // headless 临时 key:构造合成凭证(不持久化,不存 profile)
    // --model 可覆盖默认模型(如 --model kimi-k2.8-preview);未给则用 provider 默认模型。
    resolved = {
      key: cliApiKey,
      provider: cliProvider,
      baseUrl: DEFAULTS[cliProvider].baseUrl,
      model: cliModel || DEFAULTS[cliProvider].model,
      source: "cli:--api-key",
    };
  } else {
    resolved = await resolveCredential(profilesCfg, kc);
  }
  let firstRun = false; // 跑过 key 引导 → 信任步骤呈现为同一 onboarding 的下一步

  // welcome 束(纯数据,无副作用):banner 信息 + 能力 + 背景 + 箴言。上移到首启分支之前,
  // 让 Ink onboarding 与 runInkApp 共用同一束(首启 banner 由 onboarding 渲染,runInkApp 走 skipBanner)。
  const caps = detectCapabilities(process.env, process.stdout.isTTY ?? false, process.stdout.columns);
  // 实时读取当前 git 分支(每次 getStatus 调用都重读 .git/HEAD,切分支后 StatusBar 立即刷新)。
  const readGitBranch = (): string | undefined => {
    try {
      const head = readFileSync(path.join(workspaceRoot, ".git", "HEAD"), "utf8");
      return head.match(/ref: refs\/heads\/(.+)/)?.[1]?.trim();
    } catch {
      return undefined;
    }
  };
  const gitBranch = readGitBranch();
  const welcomeInfo = {
    model: resolved?.model ?? DEFAULTS.deepseek.model, // 首启尚无凭证 → 默认模型(banner 仅展示;runInkApp 首启 skipBanner)
    thinking: process.env.DAO_REASONING_EFFORT || "max",
    cwd: workspaceRoot,
    version: VERSION,
    branch: gitBranch,
    obs: obsLabel() || undefined, // 带 --obs 时在欢迎屏显示观测状态(开→地址 / 降级),不请求则不显示
  };
  const welcome = { info: welcomeInfo, caps, bg, maxim: randomMaxim() };

  // 目录信任在首启分支之前先求值,便于 onboarding 结果覆盖(onboarding 内已处理信任问答)。
  let trustProject = await shouldTrustProject(workspaceRoot);

  if (!resolved) {
    if (process.stdin.isTTY && !argvPrompt) {
      // 真终端(非 headless):Ink 引导。交互路径全程不创建 readline(create+close 会污染 stdin → Ink 挂载即退出)。
      const ob = await runOnboarding({
        welcome,                       // 与 runInkApp 同一束
        detectedLang: getLang(),       // setLang(resolveLang(...)) 已在前(B 接线)
        validate: (c) => validateCredential(c),
        persist: async (provider, meta, key) => {
          // 一账户一 key:default 若已存在(如钥匙串项被外部删除导致 resolved 为空触发重新引导)先删旧再建新,不原地覆盖。
          const base = profilesCfg.profiles.default ? removeProfile(profilesCfg, "default") : profilesCfg;
          const { cfg } = await persistKey(base, "default", { provider, ...meta }, key, kc, { preferKeychain: keychainAvailable() });
          profilesCfg = { ...cfg, onboardingComplete: true };
          await saveProfiles(keyFile, profilesCfg);
          return { resolved: { key, provider, baseUrl: meta.baseUrl, model: meta.model, source: "profile:default" } };
        },
        writeLang: (lang) => writeUserLang(lang),
        trustCurrent: () => addTrusted(workspaceRoot),
        workspaceRoot,
      });
      if (!ob) { write(`${t("onboard.abortNoKey")}\n`); process.exit(1); }
      resolved = ob.resolved;
      trustProject = ob.trusted;       // onboarding 内已处理信任,跳过后续 readline 信任问答
      if (!ob.trusted) write(`${t("trust.untrusted")}\n`); // 首启在 onboarding 拒绝信任时也要提示项目配置不加载(对标非首启 readline 路径)
      firstRun = true;
    } else {
      // 非交互(管道/CI):无法引导。提示用 --api-key CLI 参数或先跑交互模式配 profile。
      console.error(
        [
          t("key.missing.title"),
          t("key.missing.cli"),
          t("key.missing.tty"),
          t("key.help"),
        ].join("\n"),
      );
      closeRl();
      process.exit(1);
    }
  }

  // cfg 形态保持 { apiKey, baseUrl, model } 不变(下游 20+ 处沿用);keySource 仅用于呈现来源。
  let keySource = resolved.source;
  const cfg = { apiKey: resolved.key, baseUrl: resolved.baseUrl, model: resolved.model, provider: resolved.provider };

  // ---- 目录信任(P2-37):紧接 key 之后,作为首次 onboarding 的第二步 ----
  // 未信任目录【不加载】其项目级 settings/hooks,防恶意仓库自动执行。必须在加载任何项目级配置之前决定。
  // 信任对话:交互终端进入未信任文件夹时直接问,y→信任整个文件夹并当场加载(无需重启);
  // 否则继续不信任(只用用户级)。headless(-p 一次性)与非 TTY 不弹问,默认不信任(自动化不卡交互、安全默认)。
  // trustProject 已在首启分支前求值;首启(firstRun)时 onboarding 已问过信任,这里不再用 readline 重复问。
  if (!trustProject) {
    if (process.stdin.isTTY && !argvPrompt && !firstRun) {
      const a = (await ask(
        `\n${t("trust.prompt", workspaceRoot)}`,
      )).trim().toLowerCase();
      if (a === "y" || a === "yes") {
        await addTrusted(workspaceRoot);
        trustProject = true;
        write(`${t("trust.trusted")}\n`);
      } else {
        write(`${t("trust.untrusted")}\n`);
      }
    } else if (!process.stdin.isTTY || argvPrompt) {
      process.stderr.write(`${t("trust.nonTty")}\n`);
    }
  }
  if (firstRun) write(`\n${t("onboard.done")}\n`);

  // ---- 账户(profile)操作:供 /account 选择器与文本子命令共用(单一实现,UI 只是壳)----
  const listAccounts = () =>
    Object.keys(profilesCfg.profiles).map((n) => {
      const p = profilesCfg.profiles[n]!;
      return { name: n, active: n === profilesCfg.activeProfile, detail: `${p.provider}/${p.model} · ${p.keyRef ? "钥匙串" : "文件"}` };
    });
  // /model 无参选择器:内置 provider 列 MODELS_BY_PROVIDER;自定义网关(baseUrl 与默认不同)只列当前 model,
  // 由 openModelPicker 异步拉取网关 /models 替换列表。
  const listModels = () => {
    const activeProf = profilesCfg.profiles[profilesCfg.activeProfile];
    const isCustomGw = activeProf && activeProf.baseUrl !== DEFAULTS[activeProf.provider].baseUrl;
    if (isCustomGw) return [{ model: session.model, active: true }];
    return (MODELS_BY_PROVIDER[cfg.provider] ?? MODELS_BY_PROVIDER.deepseek).map((m) => ({ model: m.id, active: m.id === session.model }));
  };
  // 切换:钥匙串读取是异步的,但 model/provider/baseUrl 都在 profile 文件里,可同步生效(让 StatusBar 立即刷新);
  // 只有 apiKey 需要等钥匙串异步解析(下一回合 streamChat 读 cfg.apiKey)。
  const switchAccount = (name: string): boolean => {
    if (!profilesCfg.profiles[name]) return false;
    profilesCfg = setActive(profilesCfg, name);
    saveProfiles(keyFile, profilesCfg).catch(() => {});
    const p = profilesCfg.profiles[name];
    if (p) {
      cfg.baseUrl = p.baseUrl; cfg.model = p.model; cfg.provider = p.provider;
      session.setModel(p.model); // 实际发请求用的字段;不重放会拿旧 provider 的模型串打新 baseUrl
    }
    resolveCredential(profilesCfg, kc).then((r) => {
      if (r) { cfg.apiKey = r.key; keySource = r.source; }
    }).catch(() => {});
    return true;
  };
  // 限流重试用的版本:和 switchAccount 逻辑一致,但 await 凭据解析完成才返回——
  // 调用方紧接着就要用新账号重试请求,不能像 switchAccount 那样 fire-and-forget
  // (那样的话 apiKey 大概率还没解析完,重试会用错账号的 key)。
  const switchAccountAndWait = async (name: string): Promise<boolean> => {
    if (!profilesCfg.profiles[name]) return false;
    profilesCfg = setActive(profilesCfg, name);
    saveProfiles(keyFile, profilesCfg).catch(() => {});
    const p = profilesCfg.profiles[name];
    if (p) {
      cfg.baseUrl = p.baseUrl; cfg.model = p.model; cfg.provider = p.provider;
      session.setModel(p.model);
    }
    const r = await resolveCredential(profilesCfg, kc);
    if (!r) return false;
    cfg.apiKey = r.key; keySource = r.source;
    return true;
  };
  const removeAccount = (name: string): void => {
    const ref = profilesCfg.profiles[name]?.keyRef;
    if (ref?.startsWith("keychain:")) keychainDelete(ref.slice("keychain:".length)).catch(() => {});
    profilesCfg = removeProfile(profilesCfg, name);
    saveProfiles(keyFile, profilesCfg).catch(() => {});
  };
  // 起名:未指定时取 default / account-2 / account-3… 第一个空位。
  const nextAccountName = (): string => {
    if (!profilesCfg.profiles.default) return "default";
    for (let i = 2; ; i++) if (!profilesCfg.profiles[`account-${i}`]) return `account-${i}`;
  };
  // 添加:一账户一 key,同名已存在直接拒绝(想换 key 先 /account rm 再新建)→ 校验 → 持久化(钥匙串优先)→ 激活并即时生效。
  // baseUrl/model 可选:自定义网关(OpenAI 兼容,如京东 llm-gw)传入实际值,不传则回退 provider 默认。
  const addAccount = async (key: string, name?: string, provider: Provider = "deepseek", baseUrl?: string, model?: string): Promise<{ ok: boolean; name?: string; reason?: string }> => {
    const targetName = name?.trim() || nextAccountName();
    if (profilesCfg.profiles[targetName]) return { ok: false, reason: `账户已存在:${targetName}(先 /account rm ${targetName} 再新建)` };
    const meta = { provider, baseUrl: baseUrl?.trim() || DEFAULTS[provider].baseUrl, model: model?.trim() || DEFAULTS[provider].model };
    // 自定义 model(自定义网关选完模型)→ 按该 model 探针,确认这个 token 对它有授权(京东网关未授权返回 4012)。
    const v = await validateCredential({ baseUrl: meta.baseUrl, key, provider: meta.provider, ...(model?.trim() ? { model: meta.model } : {}) });
    if (!v.ok) return { ok: false, reason: v.reason };
    const { cfg: nc } = await persistKey(profilesCfg, targetName, meta, key, kc, { preferKeychain: keychainAvailable() });
    profilesCfg = { ...nc, onboardingComplete: true };
    await saveProfiles(keyFile, profilesCfg);
    cfg.apiKey = key; cfg.baseUrl = meta.baseUrl; cfg.model = meta.model; cfg.provider = meta.provider; keySource = `profile:${targetName}`;
    session.setModel(meta.model);
    return { ok: true, name: targetName };
  };
  const accountReasonText = (reason?: string): string =>
    reason === "invalid" ? "key 无效(401/403)"
      : reason === "unreachable" ? "网络不通,连不上 provider"
      : reason === "http" ? "provider 返回非 2xx"
      : reason ?? "未知原因";

  const registry = new ToolRegistry();
  for (const t of [
    readFileTool, listDirTool, writeFileTool, editFileTool, notebookEditTool,
    execShellTool, execShellPollTool, execShellKillTool,
    grepFilesTool, fileSearchTool, askUserTool,
    // --no-web / --eval 跳过(见上方 noWeb 定义处说明):不注册就是全流程(含子代理,子代理复用
    // 同一个 registry)都拿不到这两个工具,不是"注册了但不给用"这种更容易被绕过的软限制。
    ...(noWeb ? [] : [fetchUrlTool, webSearchTool]),
    todoWriteTool, memoryWriteTool, memoryReadTool, skillTool, skillInstallTool, taskSendTool, messageParentTool, agentTool, scheduleTool,
    taskWaitTool, taskCreateTool, taskListTool, taskGetTool, taskOutputTool, taskUpdateTool, taskStopTool, notifyUserTool,
    enterPlanModeTool, exitPlanModeTool,
    enterWorktreeTool, exitWorktreeTool,
    monitorTool,
    configTool, sendMessageTool,
    cronCreateTool, cronDeleteTool, cronListTool,
  ]) {
    registry.register(t);
  }

  // MCP:连配置的 server,把其工具/资源/提示注册进来(名字 mcp__server__*)。失败的 server 不影响其余/启动。
  // --no-mcp / --eval 跳过(评测场景不需要外部工具源,保持纯净)。
  const mcpConfigFiles = noMcp ? [] : [
    path.join(os.homedir(), ".dao", "mcp.json"),
    path.join(workspaceRoot, ".dao", "mcp.json"),
  ];
  const mcpConfig = noMcp ? { mcpServers: {} } : await loadMcpConfig(mcpConfigFiles);
  // elicitation 处理器:连接发生在 UI 就绪前,故经可变引用延迟绑定(下方 inkAsk 声明后赋值)。未绑定则婉拒。
  let mcpElicit: ElicitHandler | null = null;
  const mcp = new McpManager(registry, mcpConfig, {
    onElicit: (m, s) => (mcpElicit ? mcpElicit(m, s) : Promise.resolve({ action: "decline" as const })),
    disabledFile: path.join(os.homedir(), ".dao", "mcp_state.json"),
  });
  await mcp.init();
  // MCP server 变化(toggle/reconnect/list_changed)时注入尾部 system 消息告知模型--不碰固定前缀。
  // 只入队,不直接改 session.messages——onServerChange 可能在任意时刻异步触发(比如模型刚发出
  // 一个 tool_use、还没等到 tool_result 的窗口期),直接 push 会把这对还没闭合的消息拆开,
  // 下一次请求被 API 判成 400。改成和 pendingReflectAdvisories/steeringQueue 一样的队列,
  // 由 runTurn 在工具轮边界(loop.ts 的 drainMcpNotices)统一消费,保证时机安全。
  const mcpChangeQueue: string[] = [];
  mcp.onServerChange = (notice) => mcpChangeQueue.push(notice);
  // MCP 工具默认隐藏(见 registry.isMcpVisible)。ToolSearch 无条件注册——它不只是发现 MCP 工具的
  // 入口,也是激活上面 22 个内置 shouldDefer 工具(TaskOutput/TaskCreate/Monitor 等)的唯一入口,
  // 这些内置工具跟连不连 MCP 无关、任何模式下都无条件注册。此前按"连了 MCP 才注册 ToolSearch"
  // 门这个条件,导致 --eval/--no-mcp 场景下(评测环境从不连 MCP)这些内置工具永久不可达——而
  // system_prompt.ts 明确写着"调用前必须先用 ToolSearch 搜该工具名"、Agent 工具描述明确指导
  // "用 TaskOutput 做 checkpoint 式进度检查",这两条指导在这些场景里根本执行不了(真实撞见:
  // torch-pipeline-parallelism 复测,模型派了后台 verify 子代理后想用 TaskOutput 查进度,发现
  // 工具不可见,以为自己没有 ToolSearch,放弃等待提前收尾,子代理真实验证结果永久丢失)。
  // ToolSearch 本身只读、无副作用,不引入外部状态,无条件注册不违背"--eval 保持纯净"的本意
  // (那条注释针对的是外部 MCP server 连接,不是内置工具能不能被发现)。
  registry.register(toolSearchTool);

  // LSP:不接入任何语言的二进制,纯协议客户端;server 命令完全来自用户配置(同 MCP 的配置文件模式)。
  // 没配置任何 server 就不注册 lsp 工具(没意义,只会让模型看见一个必然报错的工具)。
  const lspConfig = await loadLspConfig([
    path.join(os.homedir(), ".dao", "lsp.json"),
    path.join(workspaceRoot, ".dao", "lsp.json"),
  ]);
  const lspManager = new LspManager(lspConfig, pathToFileURL(workspaceRoot).href);
  if (Object.keys(lspConfig.servers ?? {}).length > 0) registry.register(lspTool);

  // 代码库地图(aider 风格 repo map):tree-sitter 提取符号 + PageRank 排序。无条件注册
  // (shouldDefer,模型用 ToolSearch 才展开 schema);构建是否在后台跑见下方 repoMap 预算判断。
  registry.register(repoMapTool);

  const lang = getLang();
  const toolSummaries = registry
    .toApiTools(undefined, lang)
    .map((t) => `- ${t.function.name}:${t.function.description}`)
    .join("\n");

  // ---- 记忆读路径(会话启动一次性):迁移旧 JSON → 加载 → 确定性权威验证 → 注入固定前缀 ----
  const projectMemoryDir = path.join(workspaceRoot, ".dao", "memory");
  const userMemoryDir = path.join(os.homedir(), ".dao", "memory");
  // 三层记忆:项目级(本项目事实/进展)、用户级(用户信息+偏好)、知识库(跨项目可复用技术知识 procedural)。
  const knowledgeMemoryDir = path.join(os.homedir(), ".dao", "knowledge");
  const today = new Date().toISOString().slice(0, 10);
  // 一次性把旧 memories.json 迁移成 md(已迁移则跳过;目录不存在也容错)。
  await migrateLegacy(projectMemoryDir, today);
  await migrateLegacy(userMemoryDir, today);
  // 衰减 GC:先剪掉死记忆(留存跌破阈值的低价值事实 / 过期且宽限期已过的取代项),
  // 使它们既不被加载也不被注入。确定性,无 LLM。
  await gcMemories(projectMemoryDir, today);
  await gcMemories(userMemoryDir, today);
  await gcMemories(knowledgeMemoryDir, today);
  // 启动期合并 pass:【后台非阻塞】——合并本身可能带一次 LLM 调用(几十秒),绝不能 await 在用户能打字之前
  // (见 20260701 慢启动:knowledge 作用域一次合并把启动卡住)。代价:本会话注入用【合并前】的集合,
  // 合并结果下个会话生效——只影响真正触发合并的那次(每 3 天/作用域一次,shouldConsolidate 节流),可接受。
  // 审计:onAudit 直接写 memoryAudit;后台合并在 sink 建好(下方创建)之后才完成,触发时 sink 已就绪。
  // 并发:maybeConsolidate 内部自载记忆快照;与反思器每回合写入极少撞同一文件,撞了 last-write-wins、下轮自愈。
  if (!noMemory && !argvPrompt) {
    const consolModel = getAgentModel(process.env.DAO_CONSOLIDATE_MODEL, cfg.model);
    const consolNow = Date.now();
    const consolCommon = {
      today, now: consolNow, streamChat,
      config: { baseUrl: cfg.baseUrl, apiKey: cfg.apiKey }, model: consolModel,
      onAudit: (e: { scope: string; groups: number; superseded: number; reasons: string[] }) => memoryAudit.consolidated(e),
    };
    void (async () => {
      try {
        await maybeConsolidate({ ...consolCommon, dir: userMemoryDir, scope: "user" });
        await maybeConsolidate({ ...consolCommon, dir: knowledgeMemoryDir, scope: "knowledge" });
        await maybeConsolidate({ ...consolCommon, dir: projectMemoryDir, scope: "project" });
      } catch { /* 后台合并失败绝不影响会话 */ }
    })();
  }
  // knowledge 层单独加载并【按项目过滤】:只留本项目学到的(origin 命中)或 locked 钉住的通用知识,
  // 挡掉别的项目学到的领域知识泄进本会话(如 iOS 记忆进 dao-code)。project/user 层不过滤。
  const projectId = projectIdOf(workspaceRoot);
  const localMems = await loadAllMemories(projectMemoryDir, userMemoryDir);
  const knowAll = await loadAllMemories(knowledgeMemoryDir);
  const knowKept = knowAll.filter((m) => keepKnowledgeForProject(m, projectId));
  const recallForeign = knowAll.length - knowKept.length; // 被项目过滤挡掉的 knowledge 条数(可观测)
  const memories = [...localMems, ...knowKept];
  // 逐条对照 live code 做确定性验证(stale 剔除 / changed 标注 / ok 注入)。
  const validated: { mem: (typeof memories)[number]; verdict: Verdict }[] = [];
  for (const mem of memories) {
    const { verdict } = await validateMemory(mem, workspaceRoot, today);
    validated.push({ mem, verdict });
  }
  // 注入:DAO_NO_MEMORY 禁注入(demo 对照);小 N(<50)全注入整句、跳索引层(召回最简);
  // 否则两层——高价值整句常驻 + 长尾只给 title 索引(MemoryRead 按需取整句)。
  // 都在会话开始算定、整会话固定,不刷新、不破前缀缓存。
  const SMALL_N = 50;
  const liveCount = validated.filter((v) => v.verdict !== "stale").length;
  let injectedMems: typeof validated; let indexNames: string[];
  if (noMemory) {
    injectedMems = []; indexNames = [];
  } else if (liveCount < SMALL_N) {
    injectedMems = selectFullText(validated, today, SMALL_N); indexNames = [];
  } else {
    injectedMems = selectFullText(validated, today);
    indexNames = selectIndexNames(validated, today, injectedMems);
  }
  const memoryText = buildMemorySection(injectedMems) + buildIndexSection(indexNames);
  const recallStale = validated.filter((v) => v.verdict === "stale").length;
  const recallChanged = validated.filter((v) => v.verdict === "changed").length;
  const recallTypes: Record<string, number> = {};
  for (const it of injectedMems) recallTypes[it.mem.type] = (recallTypes[it.mem.type] ?? 0) + 1;

  // B-5 插件多组件:插件除 skills 外还可带 commands/agents/hooks;先加载插件、聚合其组件目录。
  const installedPlugins = await loadPlugins();
  const pluginComp = pluginComponentDirs(installedPlugins);
  // 自定义子代理类型(.dao/agents/*.md + 插件 agents/):专属 prompt/工具白名单/模型。
  // --no-skills / --eval 跳过(和技能同属"磁盘/插件自定义"通道,评测场景不加载,保持纯净;
  // 内置子代理 BUNDLED_AGENTS 不受影响,那是 DAO 自带的核心能力,不是用户自定义)。
  const diskAgentDefs = noSkills ? [] : await loadAgentDefs(
    path.join(workspaceRoot, ".dao", "agents"),
    path.join(os.homedir(), ".dao", "agents"),
    pluginComp.agentDirs,
  );
  // 并入内置子代理(explore/verify);同名磁盘定义优先(可覆盖)。
  const diskAgentNames = new Set(diskAgentDefs.map((d) => d.agentType));
  const agentDefs: AgentDef[] = [...diskAgentDefs, ...BUNDLED_AGENTS.filter((a) => !diskAgentNames.has(a.agentType))];
  // 自定义 slash 命令(.dao/commands/*.md + 插件 commands/):/name 展开成 prompt。
  // --no-skills / --eval 跳过(同上,磁盘/插件自定义通道统一隔离)。
  const customCommands = noSkills ? new Map<string, CustomCommand>() : await loadCustomCommands(
    path.join(workspaceRoot, ".dao", "commands"),
    path.join(os.homedir(), ".dao", "commands"),
    pluginComp.commandDirs,
  );
  const agentTypesHeader = lang === "en"
    ? "\n\n# Available Subagent Types (specify agent_type when dispatching; each has a dedicated role and tools)\n"
    : "\n\n# 可用子代理类型(派 agent 时用 agent_type 指定,各有专属角色与工具)\n";
  const agentTypesSection =
    agentDefs.length > 0
      ? agentTypesHeader +
        agentDefs.map((d) => formatAgentLine(d)).join("\n")
      : "";
  // 开箱即用 skill(.dao/skills/ + 已装插件的 skills/):启动只列 name+description,模型用 skill 工具按需取正文。
  // --no-skills / --eval 跳过(评测场景不加载用户/插件技能,保持纯净)。
  // 插件技能打【命名空间】(=插件名):用于 plugin:slug 调用与防撞;本地/项目/内置不加前缀。
  const pluginSkills = noSkills ? [] : (await Promise.all(installedPlugins.map(async (p) => (await loadSkills(p.skillsDir)).map((s) => ({ ...s, namespace: p.name }))))).flat();
  const diskSkills = noSkills ? [] : [
    ...(await loadSkills(path.join(os.homedir(), ".dao", "skills"), path.join(workspaceRoot, ".dao", "skills"))),
    ...pluginSkills,
  ];
  const diskNames = new Set(diskSkills.map((s) => s.name));
  // skill 去重(对齐 CC):物理文件去 realpath(loadSkills 内)、同名按优先级覆盖、插件加命名空间防撞、条件技能按 paths 收窄。
  //   仍无法自动消的是【不同名的语义重复】(dao debugging vs superpowers Systematic Debugging)——CC 也不自动去,靠策展:
  //   保留 dao 原生(更贴),冗余的让用户 /skills 关。来源已在 /skills 列表标 [内置/用户/插件]。
  // 禁用集(~/.dao/skills-disabled.json):被禁用的技能(内置或磁盘)都不注入上下文(省 token),/skills 可开关。
  const disabledPath = path.join(os.homedir(), ".dao", "skills-disabled.json");
  const disabledSet = new Set<string>((() => { try { return JSON.parse(readFileSync(disabledPath, "utf8")); } catch { return []; } })());
  // 内置技能:默认开、描述常驻上下文(可自动触发)。同名磁盘/插件技能覆盖之;也可在 /skills 关。
  // 只有显式 --no-skills 才清空;--eval 不隐含关闭内置技能(见 noBuiltinSkills 定义处的说明)。
  const coreBundled = noBuiltinSkills ? [] : BUNDLED_SKILLS
    .filter((b) => b.core && !diskNames.has(b.name) && !disabledSet.has(b.name))
    .map((b) => ({ name: b.name, description: b.description, body: b.body, dir: "", slug: b.name, ...(b.modelInvokable === false ? { modelInvokable: false } : {}), ...(b.userInvocable === false ? { userInvocable: false } : {}) } as import("./skills/skills.js").Skill));
  const pluginsDir = pluginsRoot();
  const skillSource = (s: { dir: string }) => (s.dir.startsWith(pluginsDir) ? "插件" : s.dir.startsWith(workspaceRoot) ? "项目" : "用户");
  const skillTokens = (s: { name: string; description: string }) => Math.max(1, Math.round((s.name.length + s.description.length) / 2));
  const enabledDisk = diskSkills.filter((s) => !disabledSet.has(s.name));
  // /skills 选择器后端:列出(内置+磁盘)、单开关、批量(内置/第三方/全部)。写禁用集,重启生效。
  const persistDisabled = () => { try { writeFileSync(disabledPath, JSON.stringify([...disabledSet])); } catch { /* 落盘失败不致命 */ } };
  const allBundledNames = BUNDLED_SKILLS.filter((b) => b.core).map((b) => b.name);
  const invMark = (s: { modelInvokable?: boolean; userInvocable?: boolean }) =>
    s.modelInvokable === false ? "·仅手动" : s.userInvocable === false ? "·仅自动" : "";
  const listSkills = () => [
    ...BUNDLED_SKILLS.filter((b) => b.core).map((b) => ({
      name: b.name,
      on: !disabledSet.has(b.name) && !diskNames.has(b.name),
      source: (diskNames.has(b.name) ? "内置·被覆盖" : "内置") + invMark(b),
      detail: b.description,
    })),
    ...diskSkills.map((s) => ({ name: s.name, on: !disabledSet.has(s.name), source: skillSource(s) + invMark(s), detail: s.description })),
  ];
  // 斜杠命令面板用:列出可 /调用的 skill(slug + 简述),与 findUserInvocableSkill 同一数据源(skills)。
  const listInvocableSkills = () =>
    skills
      .filter((s) => s.userInvocable !== false)
      .map((s) => ({
        slug: `${s.namespace ? s.namespace + ":" : ""}${s.slug ?? s.name}`,
        description: s.description,
      }));
  const setSkillEnabled = (name: string, on: boolean) => { if (on) disabledSet.delete(name); else disabledSet.add(name); persistDisabled(); };
  const batchSkills = (scope: "bundled" | "installed" | "all", on: boolean) => {
    const names = scope === "bundled" ? allBundledNames : scope === "installed" ? diskSkills.map((s) => s.name) : [...allBundledNames, ...diskSkills.map((s) => s.name)];
    toggleBundled(disabledSet, names, on);
    persistDisabled();
  };
  // 条件技能(对齐 CC 的 paths):带 paths 的技能仅当项目里有匹配文件才"在场"。
  // 启动时做一次预扫描(保留原有行为),未匹配的进待激活池,运行时文件操作时动态匹配。
  // 已匹配的进常驻列表(固定前缀);运行时新激活的通过尾部 system 消息注入(不碰前缀)。
  const visible = [...coreBundled, ...enabledDisk];
  const { initConditionalPool, activateConditionalSkillsForPaths, discoverSkillDirsForPath, loadSkillsFromDirs } = await import("./skills/discover.js");
  // 启动时预扫描:快速判断已有文件是否匹配条件 skill
  const condSkills = visible.filter((s) => s.paths && s.paths.length);
  const condMatched = new Set<string>();
  if (condSkills.length > 0) {
    const pats = condSkills.map((s) => ({ name: s.name, res: s.paths!.map(globToRegExp) }));
    let scanned = 0;
    for await (const { rel } of walkFiles(workspaceRoot)) {
      if (++scanned > 4000) break;
      for (const p of pats) if (!condMatched.has(p.name) && p.res.some((re) => re.test(rel))) condMatched.add(p.name);
      if (condMatched.size === condSkills.length) break;
    }
  }
  // 预匹配的标记为已激活(不进待激活池),其余的进待激活池等待运行时匹配。
  // 预激活的 skill 在传入 initConditionalPool 前先移除 paths 标记——没有 paths 的会被
  // initConditionalPool 判定为"无条件"并直接收进返回的 skills 列表里,不用再手动 push 一次
  // (之前这里还有一个额外的 for 循环把预激活的原始副本又 push 了一次,导致同一个 skill 在
  // 固定前缀的目录表里出现两条完全相同的记录,浪费 token 也容易让模型误以为有两个同名 skill)。
  const preActivated = new Set(condMatched);
  const skillsForPool = visible.map((s) =>
    s.paths?.length && preActivated.has(s.name) ? { ...s, paths: undefined } : s,
  );
  const skills = initConditionalPool(skillsForPool);
  // 使用频率加权(常用且最近用过的技能在发现/列表里靠前)。启动加载一次,记录时增量更新+落盘。
  let usageMap = await loadUsage(os.homedir());
  const skillsHeader = lang === "en"
    ? `\n\n# Available Skills — scan this table before starting any task\n` +
      `[MANDATORY] If a skill could possibly be relevant to the current task (even 1% chance, especially those whose "when to use" says "before…" or "must use" — ` +
      `such [trigger-tagged] skills must be loaded first), you [MUST use the skill tool to load and follow it, before taking any other action or response] — ` +
      `including before asking clarifying questions. Don't skip it by "just doing it directly" or only mention the skill name without loading it.\n` +
      `After loading, the skill body is a [mandatory workflow to follow] (including steps like "present user with options / get confirmation / phase work"), not a reference — its priority is higher than your default habits, only yielding to the user's current explicit instruction and safety/evidence.\n`
    : `\n\n# 可用 skill —— 开始任何任务前先扫这张表\n` +
      `【强制要求】只要某个 skill 可能与当前任务相关(哪怕只有一点可能,尤其其"何时用"写明"在…之前/必须用"的——` +
      `这类标了【触发时机】的,匹配上就该先加载),就【必须先用 skill 工具加载它、照它做,再做其它任何回应或动作】——` +
      `包括在澄清提问之前。别凭感觉直接上手而跳过它,也别只提技能名却不调用。\n` +
      `加载后,skill 正文是【必须照做的流程】(含其中"给用户选项/确认/分阶段"的步骤),不是参考——优先级高于你的默认习惯,仅让位于用户当前明确指令与安全/证据。\n`;
  const skillsSection =
    skills.length > 0
      ? // 只列【可被模型自动触发】的(modelInvokable !== false);disable-model-invocation 的不进此表,仅用户 /手动调。
        skillsHeader + skillCatalogLines(skills)
      : "";

  // 真正的交互式会话:有 TTY 且不是一次性 --goal 调用——决定 ctx.askChoice 是否注入(下方)、
  // 也决定系统提示词要不要加"会话特定指引"(AskUserQuestion 在 headless 下没人回答)。
  const interactiveSession = (process.stdin.isTTY === true || process.env.DAO_DECK_MANAGED === "1") && !argvPrompt;
  // 进度提醒(noProgress 计数器,连续 N 轮无实质推进就追加静态提醒):仅 headless/一次性场景默认开,
  // 交互式默认关(有人盯着,卡没卡看得见,提醒只会打断)。用权威的 interactiveSession(基于解析后的
  // argvPrompt)判定,避免 `dao -c <session-id>` 的 id 被误当 prompt 而在交互式下误开。--no-progress-advice 显式关。
  const progressAdviceFlag = !rawArgs.includes("--no-progress-advice") && !interactiveSession;
  // 快字段(顶层目录/内存)同步瞬时,直接拼进不可变 system prompt。慢字段(工具链/git/网络)
  // 不再同步 await——见下方 envNoticeQueue,避免网络探测拖慢 Ink 挂载(index.ts 里的 runInkApp)。
  const envSnapshot = formatFastEnvFields(probeTopLevelDir(workspaceRoot), probeMemory(), lang === "en");
  const systemPrompt =
    buildSystemPrompt({
      modelId: cfg.model,
      toolSummaries,
      memories: memoryText,
      cwd: workspaceRoot,
      platform: process.platform,
      envSnapshot,
      // --no-project-instructions / --eval 跳过(评测场景不注入用户/项目自定义指令,保持纯净)。
      projectInstructions: noProjectInstructions ? "" : loadProjectInstructions(workspaceRoot), // DAO.md/AGENTS.md/CLAUDE.md + 用户级
      lang,
      reflectMemoryEnabled: reflectMemoryFlag,
      reflectChallengerEnabled: reflectChallengerFlag,
      interactive: interactiveSession,
    }) + agentTypesSection + skillsSection;

  // 慢字段(工具链/git/网络):envSnapshotPromise 在 index.ts:297 就已经发起、和 onboarding 等
  // 慢启动流程并发跑;这里只是等它就绪后格式化打 tag、推进队列。loop.ts 的 drainEnvNotices 在
  // 下一次面向模型的请求前统一消费——赶上第一条请求就自然随它一起出现,赶不上就在下一次请求
  // 前补投递,只投一次,不阻塞任何交互界面挂载。
  const envNoticeQueue: string[] = [];
  envSnapshotPromise.then((data) => {
    const formatted = wrapDelayedEnvNotice(formatEnvSnapshot(data, lang === "en"), lang === "en");
    if (formatted) envNoticeQueue.push(formatted);
  });

  // 代码库地图:后台构建(不阻塞 Ink 挂载;实测 ~500 文件 <1s,大仓库靠 MAX_FILES 截断保护),
  // 构建完作为尾部 system 消息走同一条 drainEnvNotices 通道注入——不进固定前缀,不破 prefix cache。
  // DAO_REPO_MAP_TOKENS=0 显式禁用。失败静默(repo map 是增强,绝不能拖垮启动)。
  // 不跟 --no-project-instructions/--eval 绑定:repo map 是产品内置能力(同 LSP 工具性质),
  // 不是用户注入的内容;aider 的 benchmark 也全程开着 repo map。
  const repoMapBudget = repoMapTokenBudget();
  if (repoMapBudget > 0) {
    void buildRepoMap(workspaceRoot, repoMapBudget).then((r) => {
      const notice = r.text ? wrapRepoMapNotice(r.text, lang === "en", r.fileCount) : "";
      if (notice) envNoticeQueue.push(notice);
    }).catch(() => {});
  }

  // Ink 交互态注册的审批/提问模态(App 挂载后填入);未填则回退 readline。
  let inkApprovalPrompt: ApprovalPrompt | null = null;
  let inkAsk: ((q: string) => Promise<string>) | null = null;
  let inkAskChoice: ((q: string, opts: string[], multi?: boolean) => Promise<string>) | null = null;

  // MCP elicitation → ask 层(运行时 server 中途要结构化输入):无字段=确认;有字段=逐项收字符串,留空即取消。
  mcpElicit = async (message, requestedSchema) => {
    const askQ = (q: string) => (inkAsk ? inkAsk(q) : ask(`\n${q}\n> `));
    const propsObj = requestedSchema?.properties;
    const props = propsObj && typeof propsObj === "object" ? Object.keys(propsObj as Record<string, unknown>) : [];
    if (props.length === 0) {
      const a = (await askQ(`MCP server 请求确认:${message}(y 接受 / 其它拒绝)`)).trim().toLowerCase();
      return a === "y" || a === "yes" ? { action: "accept", content: {} } : { action: "decline" };
    }
    const content: Record<string, unknown> = {};
    for (const k of props) {
      const v = (await askQ(`MCP 输入「${k}」(${message})— 留空取消:`)).trim();
      if (!v) return { action: "cancel" };
      content[k] = v;
    }
    return { action: "accept", content };
  };

  // 长任务自主模式(--goal/--task/--coordinator / 运行时 /goal [目标]):自主连续推进 + 自动批准 + 更高轮数上限。
  // 阶段化多 agent 编排(原 Coordinator)已并入本模式,见 LONG_TASK_DIRECTIVE。
  let longTask = taskFlag;
  // YOLO(免审批,deny 之外全过,慎用):只能启动时开启——来源 --yolo / DAO_AUTO_APPROVE。
  // 长任务不再强开 yolo,改用 auto(AI 判定自动批准,见下方 permModeOverride 初始化)。
  let yolo = yoloFlag || !!process.env.DAO_AUTO_APPROVE;
  const alwaysApproved = await loadAlwaysApproved(approvalsFile);
  const readlinePrompt = makeApprovalPrompt(ask, process.stdin.isTTY === true && !argvPrompt);

  void maybeCleanup(workspaceRoot); // P2-58/67 卫生清理:每日一次、非阻塞、best-effort
  void maybeCheckUpdate((msg) => process.stderr.write(`ℹ ${msg}\n`)); // P3-59 更新检查:每日一次、非阻塞、仅提示
  // ---- CC 风格权限:分层加载 settings.json(user < project < local)----
  const localSettingsFile = path.join(workspaceRoot, ".dao", "settings.local.json");
  // 优先级(低→高):user < project < local < CLI < enterprise(企业托管策略不可被下层覆盖)。
  // 仅在信任时加载 project/local;否则只用用户级,杜绝未信任目录的规则/默认模式生效。
  const lowerLoaded = await loadPermissions([
    path.join(os.homedir(), ".dao", "settings.json"),
    ...(trustProject ? [path.join(workspaceRoot, ".dao", "settings.json"), localSettingsFile] : []),
  ]);
  const enterpriseLoaded = await loadPermissions([enterpriseSettingsPath()]);
  const lowerPerms = lowerLoaded.config;
  const enterprisePerms = enterpriseLoaded.config;
  const ruleSources = new Map<string, string>([...lowerLoaded.sources, ...enterpriseLoaded.sources]);
  const loadedPerms = mergePermissions([lowerPerms, cliPerms, enterprisePerms]);
  // 本会话临时追加的 allow 规则("session"/"always" 决定产生);always 另持久化到 local。
  const sessionAllow: string[] = [];
  const getRules = () => ({ ...loadedPerms, allow: [...loadedPerms.allow, ...sessionAllow] });
  // 运行时模式覆盖(/mode auto 等);null = 用 settings 的 defaultMode。
  // --goal/--task/--coordinator 启动:用 auto(AI 判定自动批准)推进自主流程,而非 yolo 全开。
  let permModeOverride: PermissionMode | null = taskFlag && !yolo ? "auto" : null;
  // 有效权限模式:plan 会话 > YOLO(=bypass)> 运行时覆盖 > settings 默认 > auto(智能判定)。
  // plan 只读规划不在 /mode 切换里,但 settings.defaultMode/--permission-mode//plan 可进入。
  // 链尾回退从 default 改为 auto(2026-08):开箱即智能判定,只读/安全操作自动过、
  // 拿不准的转人工——比「每个写操作都弹窗」的 default 对新用户更顺手;显式配置了
  // settings.defaultMode 的用户不受影响。
  const getMode = (): PermissionMode =>
    session.mode === "plan"
      ? "plan"
      : yolo
        ? "bypassPermissions"
        : permModeOverride ?? loadedPerms.defaultMode ?? "auto";

  // auto 模式分类器:结合近期对话(用户意图 + 历史工具调用)judge 本次调用是否安全可自动批准。
  // 只回 allow/deny;出错→拒绝(fail-closed)。快速路径(白名单/工作区内编辑)已在 engine.decide 里短路,不到这里。
  // Stage 1(fast):max_tokens=64 + stop=["</block>"],快路径判断。allow -> 直接放行。
  // Stage 2(thinking):max_tokens=4096,完整推理。<block>no</block> -> 放行;其余 -> 转人工。
  // 出错/不可解析 -> fail-closed(转人工,不是拒绝)。快速路径(白名单/工作区内编辑)已在 engine.decide 短路。
  // recentMessages 由调用方(PermissionGate.getMessages())传入,不能自己去读 session.messages——
  // 子代理走 withModeOverride 时会传自己的 sub.messages,这里必须原样透传,否则子代理的调用
  // 又会被根会话的转录判定,分类器看不到子代理自己在做什么(复盘 session 20260721-215548-uq75)。
  const runClassifier = createClassifierRunner((text) => process.stdout.write(text));
  const classifierContext = () => ({
    model: session.model, provider: cfg.provider, baseUrl: cfg.baseUrl, apiKey: cfg.apiKey,
    override: process.env.DAO_CLASSIFIER_MODEL,
  });

  const classifyPermission = async (toolName: string, argsJson: string, recentMessages: ChatMessage[]): Promise<boolean> => {
    const rules: AutoModeRules | undefined = loadedPerms.autoMode;
    return runClassifier(classifierContext(), classifyWithModel);
    // 两阶段裁决(参数化模型):Stage1 快判 allow 即放行;拿不准升 Stage2 完整推理。
    async function classifyWithModel(m: string): Promise<boolean> {
      const onUsage = (u: any) => {
        session.addUsage(u, m);
        cacheSink.record({ agent: "classifier", depth: 0, turn: 0, model: m, usage: u, sys: "", tools: "", tail: "" });
      };
      // Stage 1(fast):共享 system prompt + transcript,加 STAGE1_SUFFIX。
      const gen1 = streamChat({
        baseUrl: cfg.baseUrl,
        apiKey: cfg.apiKey,
        model: m,
        messages: buildClassifierMessages(toolName, argsJson, recentMessages, rules, "zh", STAGE1_SUFFIX),
        maxTokens: 64,
        extra: { thinking: { type: "disabled" }, temperature: 0, stop: ["</block>"] },
        onUsage,
      });
      let out1 = "";
      let r1 = await gen1.next();
      while (!r1.done) { if (r1.value.kind === "content") out1 += r1.value.text; r1 = await gen1.next(); }
      const block1 = parseXmlBlock(out1);
      if (block1 === false) return true;  // <block>no</block> -> 允许(快路径)
      // block1 === true(应阻止)或 null(不可解析)-> 升级 Stage 2 做完整推理,减少 false positive。

      // Stage 2(thinking):共享 system prompt + transcript,加 STAGE2_SUFFIX。
      const gen2 = streamChat({
        baseUrl: cfg.baseUrl,
        apiKey: cfg.apiKey,
        model: m,
        messages: buildClassifierMessages(toolName, argsJson, recentMessages, rules, "zh", STAGE2_SUFFIX),
        maxTokens: 4096,
        extra: { temperature: 0 },
        onUsage,
      });
      let out2 = "";
      let r2 = await gen2.next();
      while (!r2.done) { if (r2.value.kind === "content") out2 += r2.value.text; r2 = await gen2.next(); }
      const block2 = parseXmlBlock(out2);
      if (block2 === false) return true;  // <block>no</block> -> 允许(复核通过)
      return false;  // <block>yes</block> 或不可解析 -> 转人工
    }
  };

  const gate: ApprovalGate = new PermissionGate(
    getMode,
    getRules,
    async (reqs) => {
      const clear = deck?.attention("approval", reqs.map(r => r.summary).join("\n"));
      try { return await (process.env.DAO_DECK_MANAGED === "1" && deck ? deck.approve(reqs) : (inkApprovalPrompt ?? readlinePrompt)(reqs)); } finally { clear?.(); }
    }, // Ink 态用模态,否则 readline
    (rule) => appendRule(localSettingsFile, rule, "allow"), // "always" 持久化
    (rule) => { sessionAllow.push(rule); }, // "session"/"always" 本会话生效
    classifyPermission, // auto 模式
    () => session.messages, // 分类器的 transcript 来源:根会话自己的消息(子代理会在 runAgent 里 withModeOverride 换成自己的)
  );

  const session = new Session(systemPrompt, cfg.model);
  // 缓存审计:根 sink。会话 store 就绪(下方)后赋值;此处先占位 no-op,
  // 让早于 store 定义的闭包(classify/子代理/压缩/蒸馏)能按引用捕获其绑定,运行时已是真 sink。
  let cacheSink: CacheAuditSink = { record() {} };
  let memoryAudit: MemoryAuditSink = { recalled() {}, wrote() {}, distilled() {}, reflected() {}, corrected() {}, consolidated() {} };
  let toolAudit: ToolAuditSink = { call() {} };
  let permAudit: PermAuditSink = { decided() {} };
  // 技能加载审计:同样占位,store 就绪后赋值。skillRound = 每条用户消息一轮(关联 loaded)。
  let skillSink: SkillAuditSink = { loaded() {} };
  let skillRound = 0;
  // P3-17 预算提醒阈值(￥,可选):DAO_MAX_BUDGET 设了则超阈值提醒一次(默认不停);DAO_MAX_BUDGET_HARD=1 才硬停。
  { const b = Number(process.env.DAO_MAX_BUDGET); if (Number.isFinite(b) && b > 0) session.budgetCNY = b; }
  // P0-1 前缀缓存埋点:命中率骤降(多半是压缩/注入改写了前缀)时,--verbose 下打到 stderr。
  // 前缀缓存命中比未命中省约 98%,这条日志让"压缩前后 cache 不塌"可验证。
  if (verbose) {
    session.onCacheBust(({ from, to, promptTokens, changed }) =>
      console.error(`[cache] 前缀缓存命中率骤降 ${(from * 100).toFixed(0)}%→${(to * 100).toFixed(0)}%(本回合输入 ${promptTokens} tok)${changed.length ? `——变化维度:${changed.join("/")}` : "(前缀维度未变,可能 5min TTL 过期/服务端)"}`),
    );
  }
  // settings/CLI/企业策略指定的初始模式:plan→会话只读规划;bypassPermissions→等价 YOLO。
  // default/auto 由 getMode 读 loadedPerms.defaultMode 处理,无需在此设置。
  if (loadedPerms.defaultMode === "plan") session.mode = "plan";
  else if (loadedPerms.defaultMode === "bypassPermissions") yolo = true;
  // WebFetch 每次调用读取当前账号/模型，自定义网关默认继承主模型。
  const EXTRACT_INSTRUCTION = "下面是一个网页的纯文本内容,请严格按照<提取要求>从中提取相关信息,只输出提取结果," +
    "不要复述原文、不要寒暄、不要输出提取要求之外的内容。如果页面里确实没有<提取要求>要的信息,明确说明没有,不要编造。";
  const extractFromPage = async (text: string, prompt: string): Promise<string> => {
    const EXTRACT_MODEL = resolveExtractModel(process.env.DAO_FETCH_EXTRACT_MODEL, cfg.provider, session.model, cfg.baseUrl);
    const gen = streamChat({
      baseUrl: cfg.baseUrl,
      apiKey: cfg.apiKey,
      model: EXTRACT_MODEL,
      messages: [{ role: "user", content: `${EXTRACT_INSTRUCTION}\n\n<页面内容>\n${text}\n</页面内容>\n\n<提取要求>\n${prompt}\n</提取要求>` }],
      extra: { thinking: { type: "disabled" }, temperature: 0 },
      onUsage: (u) => {
        session.addUsage(u, EXTRACT_MODEL);
        cacheSink.record({ agent: "fetch-extract", depth: 0, turn: 0, model: EXTRACT_MODEL, usage: u, sys: "", tools: "", tail: "" });
      },
    });
    let out = "";
    let r = await gen.next();
    while (!r.done) {
      if (r.value.kind === "content") out += r.value.text;
      r = await gen.next();
    }
    return out.trim() || (typeof r.value.content === "string" ? r.value.content.trim() : "");
  };
  // interactiveSession 已在系统提示词组装时算过(上方)。之前 askChoice 无条件构造,
  // headless/一次性调用(harbor/terminal-bench 这类没有真实 stdin 可交互的场景)里也会拿到
  // 这个函数,退回走 ask() 读 stdin——但那里的 stdin 不是真终端,读到的是空/EOF,不匹配任何
  // 选项前缀,会被 loop.ts 里"过载/超时/网络异常"的恢复逻辑误判成"用户选择了中止本轮",
  // 直接抛错终止整个 episode,把 loop.ts 自己那套"非交互场景保留原有自动恢复"的设计完全
  // 绕过了。真实撞见:terminal-bench path-tracing-reverse 复测,一次 120s 空闲超时被这样
  // 直接判成中止,而不是走后面的限流重试/模型回退/退避重试。
  const ctx: ToolContext = {
    workspaceRoot,
    headless: !!argvPrompt,
    foregroundRegistry: createForegroundRegistry(),
    readFiles: new Set<string>(),
    readMeta: new Map<string, { mtime: number; size: number }>(),
    pendingUnverifiedWrites: new Set<string>(),
    todoWriteRequired: argvPrompt ? { done: false } : undefined,
    ask: (q: string) => (process.env.DAO_DECK_MANAGED === "1" && deck ? deck.question(q) : inkAsk ? inkAsk(q) : ask(`\n${q}\n> `)),
    // 结构化选择:Ink 用 数字/↑↓+Enter 选择器(多选 checkbox);非交互(stdin/eval)退回"编号 + 自由作答"。
    // 只在真正交互式会话里提供——非交互场景不给这个函数,让 AskUserQuestion 工具退回 ctx.ask()(已有
    // 优雅降级:读到空就回"(用户未回答)"),loop.ts 的异常恢复逻辑也据此正确落到 headless 分支。
    ...(interactiveSession ? {
      askChoice: async (q: string, opts: string[], multi?: boolean) => {
        if (process.env.DAO_DECK_MANAGED !== "1" && inkAskChoice) return inkAskChoice(q, opts, multi);
        const hint = multi ? "(回逗号分隔的多个序号,或直接作答)" : "(回序号选择,或直接作答)";
        const question = `${q}\n${opts.map((o, i) => `  ${i + 1}. ${o}`).join("\n")}\n${hint}`;
        const raw = (await ctx.ask!(question)).trim();
        const pick = (s: string) => { const n = Number(s.trim()); return Number.isInteger(n) && n >= 1 && n <= opts.length ? opts[n - 1]! : null; };
        if (multi && /[,，]/.test(raw)) {
          const picked = raw.split(/[,，]/).map(pick).filter((x): x is string => x !== null);
          return picked.length ? picked.join(", ") : raw;
        }
        return pick(raw) ?? raw;
      },
    } : {}),
    fetchImpl: fetch,
    extractFromPage,
    today,
    notifyUser: (m: string) => notify("dao", m), // NotifyUser 用;主会话与子代理均可(复用现成的桌面通知)
    setMode: (mode: "normal" | "plan") => {
      session.mode = mode;
      if (mode === "normal") permModeOverride = null; // 退出 plan 时清覆盖
    },
    searchTools: (q: string) => {
      // 先搜延迟加载的内置工具,再搜 MCP 工具;两者结果合并返回
      const deferredHits = registry.searchAndActivateDeferred(q, lang);
      const mcpHits = registry.searchAndActivateMcp(q);
      if (deferredHits.startsWith("没有") && mcpHits.startsWith("没有")) return mcpHits;
      return [deferredHits, mcpHits].filter((s) => !s.startsWith("没有")).join("\n\n");
    },
    lsp: lspManager, // lsp 工具用
  };

  // 子代理的直接输出在 Ink 态需静默(否则 write 到 stdout 会冲掉 Ink 渲染;其最终结果仍作工具结果展示)。
  let subagentWrite: (s: string) => void = write;
  ctx.agentDefinitions = agentDefs;
  ctx.skills = skills;
  // skill 工具加载某技能后回调:累加使用频率并异步落盘(用于发现/列表加权)。
  ctx.recordSkillUse = (name: string) => { usageMap = recordUsage(usageMap, name, today); void saveUsage(os.homedir(), usageMap); skillSink.loaded(skillRound, name); };
  // SkillInstall 装完 → 把新技能加载进【当前会话】(无需重启):load 目标 scope 目录 → 未知的 push 进活列表(ctx.skills 同引用)
  // → 追加一条 catalog system 消息(同框法;append-only,只此一条一次性 miss,不动已缓存前缀)。返回新加载技能名。
  ctx.loadInstalledSkills = async (scope) => {
    const dir = scope === "project" ? path.join(workspaceRoot, ".dao", "skills") : path.join(os.homedir(), ".dao", "skills");
    const known = new Set(skills.map((s) => s.name.toLowerCase()));
    const fresh = (await loadSkills(dir)).filter((s) => !known.has(s.name.toLowerCase()) && !disabledSet.has(s.name) && !s.paths?.length);
    if (!fresh.length) return [];
    skills.push(...fresh);
    const lines = skillCatalogLines(fresh);
    if (lines) session.messages.push({ role: "system", content: lang === "en" ? `\n# New skills loaded (active this session; use the skill tool to load their full body before acting when they match the task)\n${lines}` : `\n# 新装 skill(本次会话已加载,匹配任务时先用 skill 工具加载其正文再动手)\n${lines}` });
    return fresh.map((s) => s.name);
  };
  // 文件操作后触发:动态发现 .dao/skills/ 目录 + 评估条件 skill 路径匹配。
  // fire-and-forget(不阻塞工具返回);新 skill 通过尾部 system 消息注入(不碰固定前缀)。
  ctx.onFileAccessed = async (filePath: string) => {
    // 1. 动态目录发现
    try {
      const newDirs = await discoverSkillDirsForPath(filePath, workspaceRoot);
      if (newDirs.length > 0) {
        const known = new Set(skills.map((s) => s.name.toLowerCase()));
        // 漏掉用户显式禁用的 skill 会导致文件操作把它重新激活进本次会话——ctx.loadInstalledSkills
        // (skill_install 装完后那条路径)一直有这道过滤,这里是另一条独立的动态加载路径,之前没加。
        const fresh = (await loadSkillsFromDirs(newDirs, known)).filter((s) => !disabledSet.has(s.name));
        if (fresh.length > 0) {
          skills.push(...fresh);
          const lines = skillCatalogLines(fresh);
          if (lines) session.messages.push({ role: "system", content: `\n# 动态发现 skill(本次会话已加载,匹配任务时先用 skill 工具加载其正文)\n${lines}` });
        }
      }
    } catch { /* 发现失败不影响文件操作 */ }
    // 2. 条件 skill 运行时激活
    try {
      const activated = activateConditionalSkillsForPaths([filePath], workspaceRoot);
      if (activated.length > 0) {
        skills.push(...activated);
        const lines = skillCatalogLines(activated);
        if (lines) session.messages.push({ role: "system", content: `\n# 条件 skill 已激活(路径匹配,本次会话已加载)\n${lines}` });
      }
    } catch { /* 激活失败不影响文件操作 */ }
  };
  // 外来技能适配：按当前端点选择辅助模型，转换指令默认继承主模型。
  const apiTools = registry.toApiTools(undefined, lang);
  const daoTools = new Set(apiTools.map((t) => t.function.name));
  const toolCatalog = apiTools.map((t) => `${t.function.name} — ${t.function.description.split(/[。\n]/)[0]!.slice(0, 60)}`).join("\n");
  const callFlash = async (system: string, user: string): Promise<string> => {
    const gen = streamChat({
      baseUrl: cfg.baseUrl, apiKey: cfg.apiKey, model: defaultClassifierModel(classifierContext()),
      messages: [{ role: "system", content: system }, { role: "user", content: user }],
      extra: { thinking: { type: "disabled" }, temperature: 0 },
    });
    let out = ""; let r = await gen.next();
    while (!r.done) { if (r.value?.kind === "content") out += r.value.text; r = await gen.next(); }
    if (!out && typeof r.value?.content === "string") out = r.value.content;
    return out;
  };
  ctx.adaptSkill = makeSkillAdapter({ daoTools, catalog: toolCatalog, callFlash, homeDir: os.homedir() });

  // 生命周期钩子(.dao/hooks.json + 用户级):工具前/后、用户提交、会话起止。
  // 只有显式 --no-hooks 才跳过;--eval 不再隐含关闭 hooks(hooks 视为 DAO 正常能力的一部分)。
  const hooks = noHooks ? [] : loadHooks([
    { path: path.join(os.homedir(), ".dao", "hooks.json") },
    ...pluginComp.hookFiles.map((h) => ({ path: h.file, pluginRoot: h.root })), // B-5 插件 hooks(pluginRoot=插件根,兼容 CC 的 hooks/ 子目录布局)
    // 未信任目录:不加载项目 hooks(hooks 会在事件时执行命令,是最危险的自动执行面)。
    ...(trustProject ? [{ path: path.join(workspaceRoot, ".dao", "hooks.json") }] : []),
  ]);
  ctx.preToolHook = hooks.length ? async (toolName, argsJson) => {
    const o = await runHooks(hooks, "PreToolUse", { cwd: workspaceRoot, toolName, argsJson, payload: { tool: toolName, args: argsJson } });
    return { block: o.block, reason: o.reason, additionalContext: o.additionalContext, permissionDecision: o.permissionDecision, updatedInput: o.updatedInput };
  } : undefined;
  ctx.postToolHook = async (toolName, argsJson, result) => {
    await runHooks(hooks, "PostToolUse", { cwd: workspaceRoot, toolName, argsJson, payload: { tool: toolName, args: argsJson, result } });
  };
  // SessionStart 注入(三入口共用):把 additionalContext 一次性注入,紧随系统提示。
  // 须在 resume 替换 session.messages 之后、首个回合之前调用。该注入是【每次启动重新生成】的合成前缀,
  // 会被 persist 落盘 → resume 又重放;用哨兵标记在注入前剔除上次同标记消息,使其跨多次 --continue 幂等
  // (始终只一条,内容为本次最新)。注入在 index 1(系统提示之后),首次压缩时被并入摘要;无论是否压缩都不累积。
  const SS_MARK = "[[dao:session-start-hook]]";
  const injectSessionStart = async (): Promise<void> => {
    session.messages = session.messages.filter((m) => !(m.role === "system" && typeof m.content === "string" && (m.content as string).startsWith(SS_MARK)));
    const ss = await runHooks(hooks, "SessionStart", { cwd: workspaceRoot, source: continueFlag ? "resume" : "startup" });
    if (ss.additionalContext.trim()) {
      const sysIdx = session.messages[0]?.role === "system" ? 1 : 0;
      session.messages.splice(sysIdx, 0, { role: "system", content: `${SS_MARK}\n${ss.additionalContext}` });
    }
  };
  // UserPromptSubmit 裁决(三入口共用):可阻断本次提交,或把命令输出作上下文注入。
  const gateUserPrompt = async (text: string): Promise<{ blocked: boolean; reason?: string; additionalContext?: string }> => {
    const up = await runHooks(hooks, "UserPromptSubmit", { cwd: workspaceRoot, payload: { prompt: text } });
    if (up.block) return { blocked: true, reason: up.reason };
    return { blocked: false, additionalContext: up.additionalContext.trim() ? up.additionalContext : undefined };
  };
  ctx.createWorktree = (id: string) => createWorktree(workspaceRoot, id);

  // 后台任务管理器:异步子代理 + 通知队列(主循环不阻塞)。
  const taskManager = createTaskManager();
  ctx.taskManager = taskManager; // TaskCreate/get/list/update/stop 用;同一个实例,不是第二套系统
  const backgroundRuntime = new BackgroundRuntime([taskManager, processManager], workspaceRoot, (name, fields) => getBackend()?.event(name, fields));
  let activeScheduler: SessionScheduler | undefined;
  let activeStore: SessionStore | undefined;
  // Agent Deck:观察与输入复用本地调度器,不依赖面板进程。
  let deck: ReturnType<typeof createDeckBridge>;
  const connectDeck = (scheduler: SessionScheduler) => {
    deck?.close();
    deck = createDeckBridge({ scheduler, session, runtime: backgroundRuntime, cwd: workspaceRoot,
      version: VERSION, writable: !argvPrompt,
      tasks: () => taskManager.all().map(t => ({ taskId: t.id, runId: t.runId, kind: t.kind,
        description: t.description, status: t.status, progress: t.summary, result: (t.result ?? t.error)?.slice(0, 8000) })),
      todos: () => todoStore.get(),
      // 面板权限切换与原生 PermissionGate 使用同一份运行状态。
      getPermissionMode: () => getMode(),
      setPermissionMode: (mode) => {
        session.mode = mode === "plan" ? "plan" : "normal";
        yolo = mode === "bypassPermissions";
        permModeOverride = mode === "default" || mode === "auto" ? mode : null;
      },
    });
  };
  let keepBackgroundOnExit = false;
  const bindStore = async (store: SessionStore) => {
    activeStore=store;ctx.durableStore=store.durable;ctx.toolScope="root";
    if(store.durable?.state() && ctx.todoWriteRequired)ctx.todoWriteRequired.done=true;
    setObsSession(store.id);cacheSink=createCacheAuditSink(store.dir);memoryAudit=createMemoryAuditSink(store.dir);
    toolAudit=createToolAuditSink(store.dir);permAudit=createPermAuditSink(store.dir,getMode);skillSink=createSkillAuditSink(store.dir);
    ctx.toolAudit=toolAudit;ctx.permAudit=permAudit;ctx.memoryAudit=memoryAudit;
    await recoverBackground(store.durable!,backgroundRuntime,taskManager);
    store.bindBackground?.(()=>backgroundRuntime.checkpoint());
    session.messages=repairToolPairs(session.messages,store.durable!);
    store.saveState({cwd:workspaceRoot,model:session.model,mode:session.mode,title:store.durable?.state()?.title,taskTitle:store.durable?.state()?.taskTitle,messages:session.messages,usage:{...session.usage}});
  };
  const recoveryCommand = async (line:string):Promise<string|undefined> => {
    if(!/^\/recovery\b/.test(line))return;
    const store=activeStore?.durable;if(!store)return "当前会话没有持久恢复存储。";
    const [,verb,scope,id,...rest]=line.trim().split(/\s+/);
    const recordDecision=(text:string)=>{
      session.messages.push({role:"user",content:`[用户恢复决定] ${text}`});
      activeStore!.saveState({cwd:workspaceRoot,model:session.model,mode:session.mode,title:store.state()?.title,taskTitle:store.state()?.taskTitle,messages:session.messages,usage:{...session.usage}});
    };
    if(verb==="resolve") {store.atomic(()=>{store.resolveTool(scope??"",id??"",rest.join(" "));recordDecision(line);});return "已记录核实决定；请发送下一条指令继续。";}
    if(verb==="decide") {
      const snapshot=backgroundRuntime.snapshot(scope??"");
      if(!snapshot||snapshot.status!=="unknown"||!["completed","failed","canceled"].includes(id??"")||!rest.length)return "用法：/recovery decide <待核实 taskId> <completed|failed|canceled> <核实证据>";
      store.atomic(()=>{store.setLaunch(snapshot.runId,{resolvedByUser:true});
      backgroundRuntime.publish({type:id as "completed"|"failed"|"canceled",snapshot:{...snapshot,status:id as "completed"|"failed"|"canceled",result:`[用户核实] ${rest.join(" ")}`},eventId:`${snapshot.runId}:user-decision`});recordDecision(line);});
      return "已记录该任务的核实结果；请发送下一条指令继续。";
    }
    if(verb==="continue") {
      if(!scope||!id)return "用法：/recovery continue <taskId> <继续指令>";
      if(store.unresolved().length)return "仍有未决操作，请先 /recovery resolve。";
      recoveryAgentAuthorization=scope;
      try {return JSON.stringify(await ctx.resumeAgent!(scope,[id,...rest].join(" ")));} finally {recoveryAgentAuthorization=undefined;}
    }
    return JSON.stringify({tasks:backgroundRuntime.snapshots(),unresolved:store.unresolved().map(r=>({scope:r.scope,id:r.id,tool:r.name,args:r.args}))},null,2)+"\n核实未决工具：/recovery resolve <scope> <toolCallId> <核实决定>；核实 unknown 后台任务：/recovery decide <taskId> <completed|failed|canceled> <核实证据>；继续代理：/recovery continue <taskId> <指令>";
  };
  let recoveryAgentAuthorization:string|undefined;
  const preserveStop=()=>{try{backgroundRuntime.setState("paused",true);}catch{}};
  process.once("SIGTERM",preserveStop);process.once("SIGINT",preserveStop);

  ctx.sendToTask = (id: string, message: string) => taskManager.send(id, message);
  // handoff 审查只在 auto 模式触发;用 getter 每次读最新值,/mode 或长任务切换 mode 时自动同步
  Object.defineProperty(ctx, 'permissionMode', { get: () => getMode(), enumerable: true });

  // auto 模式 handoff 安全审查分类器:子代理结束后审查整段转录。
  // 用 flash 模型(同 classifyPermission),构建 handoff 专用 messages -> 调 streamChat -> 解析 XML。
  // 模型不可用时同样回退主模型并提示一次(与 classifyPermission 同一套判据)。
  ctx.handoffClassifyFn = async (transcript: string): Promise<ClassifyResult> => {
    // transcript 是 buildClassifierTranscript 产出的 JSONL;构建完整 messages
    // buildHandoffClassifierMessages 需要 ChatMessage[],但 classifyHandoffIfNeeded 已经传了 transcript
    // 这里直接构建 system+user 消息发请求
    const messages = [
      { role: "system" as const, content: "你是 auto 模式的子代理安全审查器:子代理执行完毕后,审查其整段执行转录,判断是否有违反安全策略的操作。应标记(返回 block):不可逆破坏(rm -rf、drop table、force push 覆盖)、读写凭据(.ssh/.aws/.env/credentials)、工作区外写入、与任务无关的危险操作、向外部端点发送敏感数据。不标记(返回 allow):与用户意图一致的可逆操作、工作区内正常编辑、只读操作。拿不准就标记(fail-safe)。只回 XML:<decision>allow</decision> 或 <decision>block</decision><reason>原因</reason>。" },
      { role: "user" as const, content: `执行转录:\n${transcript}\n\n审查这段子代理的执行,有违反安全策略的操作吗?` },
    ];
    const runOnce = (m: string) => {
      const gen = streamChat({
        baseUrl: cfg.baseUrl,
        apiKey: cfg.apiKey,
        model: m,
        messages,
        extra: { thinking: { type: "disabled" }, temperature: 0 },
        onUsage: (u) => {
          session.addUsage(u, m);
          cacheSink.record({ agent: "classifier", depth: 0, turn: 0, model: m, usage: u, sys: "", tools: "", tail: "" });
        },
      });
      let out = "";
      return (async () => {
        let r = await gen.next();
        while (!r.done) { if (r.value.kind === "content") out += r.value.text; r = await gen.next(); }
        return parseHandoffClassifierResponse(out);
      })();
    };
    return runClassifier(classifierContext(), runOnce);
  };

  // ---- 子代理引擎装配(对齐 CC:runAgent 统一入口)----
  ctx.runAgent = (params) => runAgent({
    ...params,
    toolUseContext: { ...ctx, sessionModel: session.model },
    availableTools: registry,
    projectInstructions: systemPrompt, // CLAUDE.md/DAO.md/gitStatus 等;omitClaudeMd 的 agent(explore/plan)自己会跳过
    config: { baseUrl: cfg.baseUrl, apiKey: cfg.apiKey },
    streamChat,
    executeToolCalls,
    gate,
    runTurn,
    write: subagentWrite,
    // 不再按 isAsync 门控:TaskSend 对前台子代理(转后台前/后)一样要能送达,taskManager.drainPending
    // 对未注册的 id 只是无害地返回 [],不区分 isAsync 也没有额外代价。
    drainPending: () => taskManager.drainPending(params.override?.agentId ?? ""),
    auditSink: cacheSink,
    subagentsDir: path.join(workspaceRoot, ".dao", "subagents"),
    mcpConfig,
  });
  ctx.getForkMessages = () => session.messages;
  ctx.resumeAgent = async (agentId, prompt) => {
    if(taskManager.get(agentId)?.status === "interrupted" && recoveryAgentAuthorization!==agentId) throw new Error("中断代理须由用户 /recovery continue 明确继续。");
    await resumeAgentBackground({
      parentModel: session.model,
      agentId, prompt, durableStore:ctx.durableStore,
      subagentsDir: path.join(workspaceRoot, ".dao", "subagents"),
      agentDefs,
      runAgent: ctx.runAgent!,
      registerAsyncAgent: (o) => taskManager.registerAsyncAgent(o),
      messageParent: (id, text, kind, runId) => { taskManager.emitFromTask(id, text, kind, runId); },
      taskManager: {
        appendMessage: (id, m, runId) => taskManager.appendMessage(id, m, runId),
        updateSummary: (id, s, runId) => taskManager.updateSummary(id, s, runId),
        update: (id, patch, runId) => taskManager.update(id, patch, runId),
      },
    });
    return `已恢复子代理 ${agentId}。`;
  };

  // 申请访问工作区外路径(读类工具):一次授权后本会话不再追问;选"本仓库后续都用"则持久化。
  let externalReadGranted = alwaysApproved.has("external-read");
  let externalWriteGranted = alwaysApproved.has("external-write");
  // CC additionalDirectories:settings 里预先授权的工作区外目录,直接放行不弹窗。
  const extraDirs = loadedPerms.additionalDirectories.map((d) => path.resolve(workspaceRoot, d));
  const underExtra = (abs: string) => extraDirs.some((d) => abs === d || abs.startsWith(d.endsWith("/") ? d : d + "/"));
  // dao 自管的 skill/插件目录:skill 正文常引同目录伴随文件(如 superpowers 的 implementer-prompt.md),
  // 它们在区外但是受信内容,【只读】放行不追问(写仍走审批——故只用于 approveExternalRead,不进 extraDirs)。
  const daoSkillDirs = [path.join(os.homedir(), ".dao", "skills"), path.join(os.homedir(), ".dao", "plugins")];
  const underDaoSkills = (abs: string) => daoSkillDirs.some((d) => abs.startsWith(d.endsWith("/") ? d : d + "/"));
  ctx.approveExternalRead = async (abs: string): Promise<boolean> => {
    if (yolo || externalReadGranted || underExtra(abs) || underDaoSkills(abs)) return true; // dao skill/插件资源:只读放行
    if (!inkApprovalPrompt) return false; // 非交互(管道/eval)默认拒绝区外访问
    const decisions = await inkApprovalPrompt([
      { id: "ext", toolName: "读取(工作区外)", capability: "read", summary: `访问工作区外路径:${abs}` },
    ]);
    const d = decisions.get("ext") ?? "deny";
    if (d === "deny") return false;
    if (d === "always") {
      externalReadGranted = true;
      await appendAlwaysApproved(approvalsFile, "external-read");
    } else if (d === "session") {
      externalReadGranted = true;
    }
    return true; // once 放行本次
  };
  // 工作区外【写】授权(对标外部读):yolo / 已授权 / --add-dir 目录直接放行,否则弹审批。
  ctx.approveExternalWrite = async (abs: string): Promise<boolean> => {
    if (yolo || externalWriteGranted || underExtra(abs)) return true;
    if (!inkApprovalPrompt) return false; // 非交互默认拒绝区外写
    const decisions = await inkApprovalPrompt([
      { id: "extw", toolName: "写入(工作区外)", capability: "write", summary: `写入工作区外路径:${abs}` },
    ]);
    const d = decisions.get("extw") ?? "deny";
    if (d === "deny") return false;
    if (d === "always") { externalWriteGranted = true; await appendAlwaysApproved(approvalsFile, "external-write"); }
    else if (d === "session") { externalWriteGranted = true; }
    return true;
  };

  // L2.1:上下文窗口按模型默认值初始化(glm-5.2=200K,其他=1M,不区分渠道),可被 env 覆盖。
  // 真正的安全网是反应式压缩(见 loop.ts compact 钩子):即便此值偏大,撞上下文超限也会自动压缩重试。
  // /context-window 命令运行时修改此值(200K/1M 两档或自定义 K),同步写 env 供子进程继承。
  // /model 切换时:若用户未手动覆盖(env 未设),自动联动到新模型的默认值;手动覆盖后锁死,不随切换改变。
  const contextWindowManualOverride = Number.isFinite(Number(process.env.DAO_CONTEXT_WINDOW));
  let contextWindowManuallySet = contextWindowManualOverride;
  let CONTEXT_WINDOW = Number(process.env.DAO_CONTEXT_WINDOW) || contextWindowFor(cfg.model, cfg.provider, cfg.baseUrl);
  // Q1 当前上下文 token:优先用主模型上次真实 prompt_tokens(准,尤其中文)。
  // 无真实值时返回 0——启动与 /clear 后 StatusBar 应显示 0% 而非按系统提示估算的非零值
  // (系统提示是常驻开销,不是"对话已用上下文";真实用量要到首次 API 调用后才有)。
  const contextTokens = () => session.lastPromptTokens ?? 0;
  // P2-11 编辑后诊断命令(如 "tsc --noEmit"):设了才在写/改文件后跑、把报错回灌模型。
  // 显式 DAO_DIAGNOSTICS_CMD 优先;否则 DAO_DIAGNOSTICS=1 时按项目自动探测(tsc/eslint)。默认不跑。
  const DIAG_CMD = process.env.DAO_DIAGNOSTICS_CMD?.trim()
    || (process.env.DAO_DIAGNOSTICS === "1" ? detectDiagnosticsCmd(workspaceRoot) : undefined);
  const makeDiagnose = (signal?: AbortSignal) => (DIAG_CMD ? () => runDiagnosticsCmd(DIAG_CMD, workspaceRoot, signal) : undefined);

  // 压缩用:对【待摘要的结构化消息段】生成中文摘要。compact.ts 传来 [system, ...待摘要],本函数在尾部
  // 追加一条压缩指令、用【主模型】跑(同 reflect 模式)——待摘要段逐字节 = 主循环上次已发的前缀,故命中
  // 主对话热缓存(实测稳态命中 64–74%,首次冷启较低)。
  // 【成本实测/勿误信】命中虽真,但 pro 的 miss 价(3￥/1M)与输出价(6￥/1M)均是 flash 的 3 倍,
  // 64–74% 命中折扣压不过那部分 miss+输出 → pro 摘要其实比"冷发 flash"贵约 63%(整会话 ~+12%)。
  // 默认仍用主模型【是为摘要质量/长任务续接更稳】,不是为省钱;想省钱用 DAO_SUMMARY_MODEL=…flash 切回。
  // 先 <分析> 草稿过一遍,再 <摘要> 输出 9 个固定小节;不丢技术细节/决策/用户原话。
  const COMPACT_INSTRUCTION = `现在把【以上整段对话】压缩成一份详尽的中文摘要,重点保留用户的明确请求和你已做的动作,确保技术细节、代码模式、架构决策不丢,以便不丢上下文地继续工作。

注意:对话开头可能有【早期对话摘要】或【当前任务清单】这类系统消息——它们会被原样保留,请【不要重复摘要它们】,只摘要其后的真实对话内容。

先在 <分析> 标签里按时间顺序逐段过一遍对话——每段识别:用户的明确请求与意图、你的处理方式、关键决策与技术概念、具体文件名/代码片段/函数签名/文件改动、遇到的错误及修复、尤其用户给的纠正性反馈;核对技术准确与完整。然后在 <摘要> 标签里输出下面 9 个固定小节:

1. 主要请求与意图:详尽列出用户所有明确请求与意图
2. 关键技术概念:讨论到的所有重要技术/框架/概念
3. 文件与代码片段:查看/修改/新建的具体文件与代码段,附"为何重要"和关键代码(尤其最近的)
4. 错误与修复:遇到的错误、如何修复、以及用户对此的反馈
5. 问题解决:已解决的问题与进行中的排查
6. 所有用户消息:逐条列出所有非工具结果的用户消息(理解反馈与意图变化的关键)
7. 待办任务:明确被要求做、尚未完成的事
8. 当前工作:紧接本次压缩前正在做什么,含文件名与代码片段
9. 下一步(可选):仅当与用户最近的明确请求直接一致时才列,并附最近对话的【原话引用】以防任务理解漂移

只输出 <分析> 和 <摘要> 两个块的纯文本,不要寒暄。`;
  // 默认主模型(命中热缓存);DAO_SUMMARY_MODEL 可覆盖为 flash 等(会冷发、不命中缓存,省单价但失缓存)。
  const summarize = async (msgs: ChatMessage[]): Promise<string> => {
    const SUMMARY_MODEL = getAgentModel(process.env.DAO_SUMMARY_MODEL, session.model);
    const gen = streamChat({
      baseUrl: cfg.baseUrl,
      apiKey: cfg.apiKey,
      model: SUMMARY_MODEL,
      // 直接发结构化的待摘要段 + 尾部指令:[system, ...待摘要, 指令]。前缀 = 主对话热缓存前缀 → 命中。
      messages: [...msgs, { role: "user", content: COMPACT_INSTRUCTION }],
      // 摘要不需要深推理:关思考更快更省,温度 0 让压缩结果可复现。
      extra: { thinking: { type: "disabled" }, temperature: 0 },
      onUsage: (u) => {
        session.addUsage(u, SUMMARY_MODEL); // B-2 记摘要用量
        cacheSink.record({ agent: "summary", depth: 0, turn: 0, model: SUMMARY_MODEL, usage: u, sys: "", tools: "", tail: "" });
      },
    });
    let out = "";
    let r = await gen.next();
    while (!r.done) {
      if (r.value.kind === "content") out += r.value.text;
      r = await gen.next();
    }
    out = out.trim() || (typeof r.value.content === "string" ? r.value.content : "");
    // 剥掉 <分析> 草稿,只留 <摘要>(没标签则用全文)。
    const m = out.match(/<摘要>([\s\S]*?)<\/摘要>/);
    return (m ? m[1]! : out).trim() || "(摘要为空)";
  };

  // L2.4 压缩熔断(半开断路器):连续 3 次摘要失败 → 打开,之后冷却窗内的压缩直接抛(走 compactMessages
  // 硬截断兜底),不再浪费模型调用;过了冷却窗自动【放一发试探】,成功即彻底关闭复位、失败则重新计时再等一轮。
  // 这样瞬时抖动(模型短时过载)不再永久废掉整段会话的摘要能力——这是「只熔不复」的旧版最大的洞。
  const COOLDOWN_MS = Number(process.env.DAO_COMPACT_COOLDOWN_MS) || 5 * 60_000;
  let compactFails = 0;
  let breakerOpenedAt = 0; // 断路器打开的时刻;仅在 compactFails>=3 时有意义
  const summarizeWithBreaker = async (msgs: ChatMessage[]): Promise<string> => {
    // 打开中且冷却未到 → 拒(硬截断);冷却已过 → 落到下面放一发半开试探。
    if (compactFails >= 3 && Date.now() - breakerOpenedAt < COOLDOWN_MS) {
      throw new Error("压缩熔断冷却中:连续摘要失败,改用硬截断(待冷却后自动重试)");
    }
    try { const s = await summarize(msgs); compactFails = 0; breakerOpenedAt = 0; return s; }
    catch (e) { compactFails++; if (compactFails >= 3) breakerOpenedAt = Date.now(); throw e; }
  };

  const runCompaction = async (): Promise<void> => {
    // 按 token 量判断(而非消息条数):整段摘要把全部对话塌成一条摘要消息,条数骤减但要看 token 真减了多少。
    const before = estimateTokens(session.messages);
    session.messages = await compactMessages(
      session.messages,
      { summarize: summarizeWithBreaker },
      todoStore.get().length ? formatTodos(todoStore.get()) : undefined,
    );
    const after = estimateTokens(session.messages);
    write(after < before ? `\n[已压缩对话:~${before.toLocaleString()} → ~${after.toLocaleString()} tok]\n` : `\n[对话较短,无需压缩]\n`);
  };

  // P3-63 防休眠 + 长回合完成通知:回合期间持 wakelock;耗时超阈值则完成时弹桌面通知。
  const NOTIFY_MIN_MS = Number(process.env.DAO_NOTIFY_MIN_MS) || 30000;
  const withPresence = async <T>(fn: () => Promise<T>): Promise<T> => {
    const release = acquireWakeLock();
    const start = Date.now();
    let completed = false;
    try { const result = await fn(); completed = !!result && typeof result === "object" && "kind" in result && result.kind === "completed"; return result; }
    finally {
      release();
      const ms = Date.now() - start;
      if (completed && ms > NOTIFY_MIN_MS) notify("dao", `完成一轮(${Math.round(ms / 1000)}s)`);
    }
  };

  // onCheckpoint(可选):一次性/--goal 长任务(argvPrompt)整个用户回合可能含大量工具轮,
  // 中途异常上抛会丢掉此前已成功的所有步骤——传入时每个工具轮结束后落一次盘(与交互态同一层修复)。
  const runOneTurn = async (onCheckpoint?: () => void, signal?: AbortSignal, onBoundary?: () => Promise<void>): Promise<TurnOutcome> => {
    const outcome = await withPresence(() => runTurn({
      session,
      config: { baseUrl: cfg.baseUrl, apiKey: cfg.apiKey },
      registry,
      ctx,
      auditSink: cacheSink,
      auditId: { agent: "main", depth: 0 },
      gate,
      streamChat,
      executeToolCalls,
      write,
      events: deck?.events(plainEvents(write)),
      compact: runCompaction, // L2.2 反应式压缩
      shouldCompact: () => contextTokens() >= CONTEXT_WINDOW * 0.85, // §4 轮内主动压缩
      diagnose: makeDiagnose(), // P2-11 编辑后诊断
      reflect: (argvPrompt || !reflectChallengerFlag) ? undefined : reflect, // 轮内卡住检测(assessTurn→挑战者);一次性/eval 不反思,默认关闭需 --reflect-challenger
      progressAdvice: progressAdviceFlag, // 进度提醒(noProgress 计数器);仅 headless 默认开,交互式默认关;--no-progress-advice 显式关
      interactive: interactiveSession, // 进度提醒里"卡住了用 AskUserQuestion"这条只在真交互态才建议
      longTask,
      drainAdvisories: () => pendingReflectAdvisories.splice(0), // 反思器+(暂留)reply 的 advisory
      backgroundRuntime, signal, onBoundary,
      drainMcpNotices: () => mcpChangeQueue.splice(0), // MCP server 状态变化:回合边界回灌,不插进 tool_use/result 中间
      drainEnvNotices: () => envNoticeQueue.splice(0), // 环境探测补充:回合边界回灌(Task 5 新增)
      onCheckpoint,
    }));
    if (outcome.kind !== "completed") return outcome;
    // 回合末统一反思:记忆 + 方向。自适应节奏;压缩前同步先抢救。argvPrompt(一次性/eval)不跑。
    if (!argvPrompt) {
      const compactionImminent = contextTokens() >= CONTEXT_WINDOW * 0.85;
      if (compactionImminent || REFLECT_SYNC) await maybeReflect({ compactionImminent });
      else void maybeReflect({ compactionImminent });
    }
    if (contextTokens() >= CONTEXT_WINDOW * 0.85) {
      write("\n[接近上限,自动压缩…]\n");
      await runCompaction();
    }
    return outcome;
  };

  // Ink 态压缩:不向 stdout 写(会冲渲染),只压缩消息;提示由 App 通过 events/notice 给出。
  // 返回前后 token 估算,供 App 展示压缩效果(如 "~12K → ~3K tok")。
  const inkCompact = async (): Promise<{ before: number; after: number }> => {
    const before = estimateTokens(session.messages);
    session.messages = await compactMessages(
      session.messages,
      { summarize: summarizeWithBreaker },
      todoStore.get().length ? formatTodos(todoStore.get()) : undefined,
    );
    const after = estimateTokens(session.messages);
    return { before, after };
  };

  // 统一反思器(回合末):一个 fork,既反思进展(advisory,有问题才注入)又抽记忆(含 mergeInto 合并)。
  // 复用主前缀热缓存(fork:同 tools+思考强度);自适应节奏默认每回合、连续安静回退至多 N。
  let reflectBusy = false; // 防并发:上次后台反思未完成则跳过本次
  let cadenceState = initCadence();
  const pendingReflectAdvisories: string[] = []; // 反思器 advisory(有问题才入队),回合边界 append-only 注入
  const REFLECT_MAX_INTERVAL = process.env.DAO_REFLECT_EVERY === "1" ? 1 : (Number(process.env.DAO_REFLECT_MAX_INTERVAL) || 3);
  const NO_MEMORY = noMemory;
  const REFLECT_SYNC = process.env.DAO_REFLECT_SYNC === "1"; // 测试/demo:反思同步完成再继续(否则后台 void)

  const runReflector = async (): Promise<{ onTrack: boolean; mem: number }> => {
    if (reflectBusy || NO_MEMORY || !session.messages.some((m) => m.role === "user")) return { onTrack: true, mem: 0 };
    reflectBusy = true;
    try {
      const fork = process.env.DAO_DISTILL_FORK !== "0";
      const model = fork ? session.model : defaultClassifierModel(classifierContext());
      const reflectConfig = { baseUrl: cfg.baseUrl, apiKey: cfg.apiKey };
      const tools = fork ? apiToolsForMode(registry, session.mode, lang) : undefined;
      // 只发上次主请求已缓存的前缀(slice 到 lastSentLength)→ 前缀字节一致、命中热缓存。
      const msgs = fork && session.lastSentLength > 0 ? session.messages.slice(0, session.lastSentLength) : session.messages;
      const existing = await loadAllMemories(projectMemoryDir, userMemoryDir, knowledgeMemoryDir);
      // 已有候选(供 mergeInto):有 title 的按 importance 降序【全量】给(标题便宜、可全当合并目标 → 不漏低重要度相关条);
      // 200 条安全上限防极端;正文只取前 N(见 unified_reflect.buildTail)。
      const candidates = existing.filter((m) => m.title).sort((a, b) => b.importance - a.importance).slice(0, 200).map((m) => ({ title: m.title!, text: m.text }));
      const result = await unifiedReflect({
        streamChat, config: reflectConfig, model, messages: msgs, today,
        existing: candidates, fork, tools, reasoningEffort: process.env.DAO_REASONING_EFFORT || "max",
        onUsage: (u) => {
          session.addUsage(u as never, model);
          const sysRaw = typeof session.messages[0]?.content === "string" ? (session.messages[0]!.content as string) : "";
          cacheSink.record({ agent: "distill", depth: 0, turn: 0, model, usage: u as never, sys: sysRaw, tools: JSON.stringify(tools ?? []), tail: "", msgs: JSON.stringify(msgs) });
        },
      });
      // 记忆落盘:mergeInto 感知 → 精确键 upsert(同 name 覆盖即合并增强)。
      let added = 0, merged = 0;
      for (const m of result.memories) {
        const scope = routeScope(reflectMemToCand(m, existing, today).type);
        // 只给 knowledge 层打 origin(项目标签):user 层全局、project 层已按目录隔离,无需标签。
        const cand = reflectMemToCand(m, existing, today, scope === "knowledge" ? projectId : undefined);
        const dir = scope === "knowledge" ? knowledgeMemoryDir : scope === "user" ? userMemoryDir : projectMemoryDir;
        const res = await upsertMemory(dir, cand, existing);
        if (res.action === "updated") merged++; else added++;
      }
      // 纠错闭环:被实测推翻 → supersede/revise;被实测证实 → touch 续命。dirFor 按 type 路由作用域目录。
      const dirFor = (t: import("./memory/types.js").MemoryType) => {
        const sc = routeScope(t);
        return sc === "knowledge" ? knowledgeMemoryDir : sc === "user" ? userMemoryDir : projectMemoryDir;
      };
      const applied = await applyCorrections(result.corrections, existing, dirFor, today);
      const confirmed = await applyConfirmed(result.confirmed, existing, dirFor, today);
      for (const c of applied) memoryAudit.corrected({ target: c.target, action: c.action, reason: c.reason });
      const corrected = applied.length;
      const advisoryInjected = !!result.advisory;
      if (result.advisory) pendingReflectAdvisories.push(`[反思]\n${result.advisory}`); // 有问题才注入(append-only)
      memoryAudit.reflected({ ran: true, onTrack: result.onTrack, advisoryInjected, memAdded: added, memMerged: merged, interval: cadenceState.interval, note: result.note, corrected, confirmed });
      return { onTrack: result.onTrack, mem: added + merged };
    } catch (e) {
      if (process.env.DAO_DEBUG_REFLECT) console.error("[reflect] 失败:", e);
      return { onTrack: true, mem: 0 };
    } finally {
      reflectBusy = false;
    }
  };

  // 回合末入口:deepseek 官方 key 不限流,每轮都跑(仅 reflectBusy 防并发);
  // 其它 provider(volcengine/qianfan/zhipu 等 coding-plan/token-plan,计费敏感)用自适应节奏(连续安静则放慢)。
  const maybeReflect = async (opts: { compactionImminent: boolean }): Promise<void> => {
    if (!reflectMemoryFlag || argvPrompt || NO_MEMORY) return; // 默认关闭,--reflect-memory 才跑
    // deepseek 不限流:跳过 cadence,每轮直接跑(仅用 reflectBusy 防并发堆叠)。
    // 读 cfg.provider(活值,随 /account 切换更新)而非 resolved.provider(启动时快照,切账户后不再变)。
    if (cfg.provider === "deepseek") {
      void runReflector(); // fire-and-forget;reflectBusy 在内部防并发;真实 audit 在 runReflector 内写
      return;
    }
    // 非 deepseek 官方 key(coding-plan/token-plan 计费敏感):自适应 cadence,省钱
    const tick = tickCadence(cadenceState, REFLECT_MAX_INTERVAL);
    const run = tick.run || opts.compactionImminent;
    cadenceState = run ? { ...tick.next, counter: 0 } : tick.next;
    if (!run) {
      memoryAudit.reflected({ ran: false, onTrack: true, advisoryInjected: false, memAdded: 0, memMerged: 0, interval: cadenceState.interval });
      return;
    }
    const out = await runReflector();
    cadenceState = applyOutcome(cadenceState, out.onTrack && out.mem === 0, REFLECT_MAX_INTERVAL);
    if (process.env.DAO_DEBUG_REFLECT) console.error(`[reflect] ran onTrack=${out.onTrack} mem=${out.mem} interval=${cadenceState.interval}`);
  };

  // 反思层 fork:同模型(命中主对话热缓存)对进展做精简复核,返回结论(由 loop 作 advisory 注入参考)。
  // DAO_REFLECT=0 关闭。失败静默返回 null,绝不影响主流程。
  const reflect = async (kind: "challenger" | "refocuser"): Promise<string | null> => {
    if (process.env.DAO_REFLECT === "0") return null;
    try {
      const tail = kind === "challenger" ? CHALLENGER_PROMPT : REFOCUSER_PROMPT;
      const gen = streamChat({
        baseUrl: cfg.baseUrl, apiKey: cfg.apiKey, model: session.model,
        messages: [...session.messages, { role: "user", content: tail }],
        extra: { temperature: 0 },
        onUsage: (u) => session.addUsage(u as never, session.model),
      });
      let out = ""; let r = await gen.next();
      while (!r.done) { if (r.value?.kind === "content") out += r.value.text; r = await gen.next(); }
      if (!out && typeof r.value?.content === "string") out = r.value.content;
      return out.trim() || null;
    } catch {
      return null;
    }
  };

  // (原"路径① reply-challenger"已废弃:用户重提的检测由每回合统一反思器天然覆盖。)

  let exitSessionId: string | undefined; // 交互会话 id(供退出时打印 resume 提示;一次性路径无 store)
  try {
    if (argvPrompt) {
      // 一次性调用(含 eval 每次跑)不蒸馏:蒸馏只属于真实的交互式工作会话,
      // 既省掉快速查询的 flash 开销,也自动把 eval 排除在外、测量更干净。
      // 但仍建 session store + 全部审计 sink(与交互态同一套函数),让 headless/eval 也落一份完整结构化 trace
      // (state.json 全量 messages + cache/tool/perm/memory/skill 各 trace jsonl)——之前这条路径完全没有落盘,
      // eval 只能拿到 stdout 文本,补上后 evals/run.mjs 才能把它跟 pass/fail 一起归档供事后分析。
      const sessionsDir = path.join(workspaceRoot, ".dao", "sessions");
      const previous = continueFlag ? (cliResumeId ? loadState(sessionsDir,cliResumeId) : findResumable(sessionsDir,workspaceRoot)) : null;
      if(previous) { session.messages=previous.storageVersion===2?previous.messages:sanitizeHistoryForResume(previous.messages); session.setModel(previous.model); session.mode=previous.mode;Object.assign(session.usage,previous.usage); }
      const store = createSessionStore(sessionsDir,previous?.id,{cwd:workspaceRoot,durable:true});
      await bindStore(store);
      setObsSession(store.id);
      cacheSink = createCacheAuditSink(store.dir);
      memoryAudit = createMemoryAuditSink(store.dir);
      toolAudit = createToolAuditSink(store.dir);
      permAudit = createPermAuditSink(store.dir, getMode);
      skillSink = createSkillAuditSink(store.dir);
      ctx.toolAudit = toolAudit; ctx.permAudit = permAudit; ctx.memoryAudit = memoryAudit;
      // hook 钩子:SessionStart 注入 + UserPromptSubmit 裁决 + SessionEnd(与交互态同等防护;对齐 CC——headless `-p` 一次性运行同样触发 SessionEnd)。
      await injectSessionStart();
      const up = await gateUserPrompt(argvPrompt);
      if (up.blocked) { write(`[提交被 hook 阻止] ${up.reason || ""}\n`); return; }
      session.addUser(argvPrompt);
      // headless 模式强提醒:不会有用户在终端交互,所有命令必须是非交互式的。
      // 交互式命令(如 7z 不带 -p、mysql 不带密码、ssh 需要密码)会卡住等待输入,永远不会返回。
      session.messages.push({ role: "system", content: "[headless 提醒] 当前为无人值守模式,不会有用户在终端输入。所有命令必须是非交互式的——用参数或管道传入所需输入(如 7z -p<密码>、echo <密码> | 7z x),不要让命令等待 stdin。交互式命令会永久卡住。" });
      if (up.additionalContext) session.messages.push({ role: "system", content: `[hook 注入的上下文]\n${up.additionalContext}` });
      const argvCheckpoint = () =>
        store.saveState({ cwd: workspaceRoot, model: session.model, mode: session.mode, messages: session.messages, backgroundWait: backgroundRuntime.activeWaits > 0, usage: { ...session.usage } });
      activeScheduler = new SessionScheduler({ runtime: backgroundRuntime, session, save: argvCheckpoint,
        keepAlive: true, notice: write, user: async () => {},
        run: (signal, boundary) => runOneTurn(argvCheckpoint, signal, boundary) });
      connectDeck(activeScheduler);
      activeScheduler.recover();
      activeScheduler.submit(argvPrompt);
      await activeScheduler.finished();
      if (activeScheduler.lastError) throw activeScheduler.lastError;
      activeScheduler.close();
      await runHooks(hooks, "SessionEnd", { cwd: workspaceRoot }); // 会话结束钩子(CC 对等:一次性运行也触发)
      await cleanupDbBackups(workspaceRoot); // 清理本次运行留下的 .dao-backup 安全网文件
      store.saveState({
        cwd: workspaceRoot, model: session.model, mode: session.mode,
        messages: session.messages, backgroundWait: backgroundRuntime.activeWaits > 0, usage: { ...session.usage },
      });
      store.markDone();
      if (session.usage.promptTokens > 0) write(`\n${session.usageSummary()}\n`);
      return;
    }
    // caps / gitBranch / welcomeInfo / welcome 束已在首启分支之前构造(与 onboarding 共用);此处直接复用。
    if (process.stdout.isTTY && process.env.DAO_DECK_MANAGED !== "1") {
      // 交互态:Ink REPL(inline)。常见路径下从未创建 readline(stdin 干净),Ink 的 useInput 直接接管;
      // 仅当首次运行做过 key 引导才存在 rl,此时关掉让出 stdin。
      subagentWrite = () => {}; // Ink 态静默子代理直接输出
      closeRl();
      // @文件补全的文件缓存:启动时遍历一次工作区(上限 5000,沿用 walkFiles 的忽略规则)。
      const fileCache: string[] = [];
      try {
        for await (const { rel } of walkFiles(workspaceRoot)) {
          fileCache.push(rel);
          if (fileCache.length >= 5000) break;
        }
      } catch {}
      // 长任务地基:会话日志/状态快照(崩溃恢复)+ 影子 git 检查点(回滚)。
      const sessionsDir = path.join(workspaceRoot, ".dao", "sessions");
      let resumeId: string | undefined;
      let initialItems: TranscriptItem[] = [];
      let initialSessionTitle: string | undefined;
      let initialTaskTitle: string | undefined;
      if (continueFlag) {
        // 给了明确 id(dao -c <id>)就精确续写那一个会话文件;没给才退回"最近一个可续写的会话"。
        const prev = cliResumeId ? loadState(sessionsDir, cliResumeId) : findResumable(sessionsDir, workspaceRoot);
        if (prev) {
          // 清洗一遍再装载:防止磁盘上的旧历史里混进过半截/非法 JSON 的 tool_call(真实撞见过——
          // 一个跑着旧代码、迟迟没重启的进程把这类坏消息存进了 state.json,续写时原样加载回来,
          // 下一轮请求又会撞上同一个 400 Invalid request body)。
          session.messages = prev.storageVersion===2 ? prev.messages : sanitizeHistoryForResume(prev.messages);
          if (prev.backgroundWait && prev.storageVersion!==2) session.messages.push({ role: "system", content: "[旧等待未恢复] 上次会话等待的后台执行未被本进程接管,请重新确认任务状态。" });
          session.setModel(prev.model);
          session.mode = prev.mode;
          session.usage.promptTokens += prev.usage.promptTokens;
          session.usage.completionTokens += prev.usage.completionTokens;
          session.usage.cacheHitTokens += prev.usage.cacheHitTokens;
          session.usage.cacheMissTokens += prev.usage.cacheMissTokens;
          resumeId = prev.id; // 续写同一会话文件
          initialSessionTitle = prev.title;
          initialTaskTitle = prev.taskTitle;
          const recap = transcriptFromMessages(prev.messages);
          recap.unshift({ id: 0, kind: "notice", text: prev.backgroundWait ? "[已恢复上次会话;旧后台等待未恢复,请重新确认任务状态]" : "[已恢复上次会话]" });
          initialItems = recap.map((it, i) => ({ ...it, id: i + 1 })); // 统一编号(welcome 占 0)
        } else if (cliResumeId) {
          // 给了明确 id 但没找到:提示一下,而不是静默当成"无历史会话"从零开始,让人误以为续上了。
          initialItems = [{ id: 0, kind: "notice", text: `[未找到会话 ${cliResumeId},本次将开始新会话]` }];
        }
      }
      let store = createSessionStore(sessionsDir, resumeId, {cwd:workspaceRoot,durable:true});
      await bindStore(store);
      exitSessionId = store.id; // 记下,退出时给 resume 提示
      setObsSession(store.id); // obs:让 turn span 带上 session id,trace 可按 session 分组/查找
      // 缓存审计:主+子+fork+后台+三工具调用全写进 store.dir/cache.jsonl(常驻静默;DAO_CACHE_AUDIT=0 关)。
      cacheSink = createCacheAuditSink(store.dir);
      memoryAudit = createMemoryAuditSink(store.dir);
      toolAudit = createToolAuditSink(store.dir);
      permAudit = createPermAuditSink(store.dir, getMode);
      ctx.toolAudit = toolAudit; ctx.permAudit = permAudit; ctx.memoryAudit = memoryAudit;
      memoryAudit.recalled(injectedMems.length, recallStale, recallChanged, recallTypes, recallForeign);
      try {
        if (auditEnabled(process.env, "SKILL")) {
          writeFileSync(path.join(store.dir, "skills-catalog.json"),
            JSON.stringify(skills.map((s) => ({ name: s.name, description: s.description, whenToUse: s.whenToUse ?? "" }))));
        }
      } catch { /* 快照失败不影响 */ }
      skillSink = createSkillAuditSink(store.dir);
      // 影子 git 默认关闭;读 settings.json 的 checkpoint.enabled(项目级 > 用户级)决定是否开启。
      // DAO_NO_CHECKPOINT / DAO_CHECKPOINT 环境变量在 createCheckpointer 内部处理,优先级更高。
      const checkpointEnabled = await readCheckpointEnabled(
        path.join(os.homedir(), ".dao", "settings.json"),
        trustProject ? path.join(workspaceRoot, ".dao", "settings.json") : null,
      );
      const ckpt = createCheckpointer(workspaceRoot, { enabled: checkpointEnabled });
      const turnCheckpoints: (string | null)[] = []; // 第 k 项 = 第 k 条用户消息【之前】的影子 git 快照 sha,供 /rewind 联动回滚文件
      let sessionTitle = store.durable?.state()?.title ?? initialSessionTitle; // /rename 设置
      let taskTitle = store.durable?.state()?.taskTitle ?? initialTaskTitle ?? firstUserExcerpt(session.messages);
      if (longTask && !continueFlag) session.messages.push({ role: "system", content: lang === "en" ? LONG_TASK_DIRECTIVE_EN : LONG_TASK_DIRECTIVE });
      await injectSessionStart(); // SessionStart 注入(resume 替换后、首个回合前;幂等见 injectSessionStart)
      const persist = () =>
        store.saveState({
          cwd: workspaceRoot,
          model: session.model,
          mode: session.mode,
          title: sessionTitle,
          taskTitle,
          messages: session.messages,
          backgroundWait: backgroundRuntime.activeWaits > 0,
          usage: { ...session.usage },
        });
      let uiEvents: TurnEvents = plainEvents(() => {});
      const scheduler = new SessionScheduler({ runtime: backgroundRuntime, session, save: persist,
        notice: (text) => uiEvents.notice(text),
        user: async (text) => {
          // 命令/纯文本:走原有文本路径;图片(ContentPart[]):提取文字部分给 hook/store,图片部分随 session.addUser 一起发。
          const textStr = typeof text === "string" ? text : text.filter(p => p.type === "text").map(p => (p as { text: string }).text).join(" ");
          // UserPromptSubmit 钩子:可阻断本次提交、或把命令输出注入为上下文。
          const up = await gateUserPrompt(textStr);
          if (deck?.input(textStr, !up.blocked) && !up.blocked) uiEvents.userMessage?.(textStr);
          if (up.blocked) { uiEvents.notice(`[提交被 hook 阻止] ${up.reason || ""}`); return false; }
          turnCheckpoints.push(ckpt.snapshot(`回合前: ${textStr.slice(0, 60)}`)); // 回合前快照(供 /restore 与 /rewind code 回退)
          store.append({ t: "user", text: textStr });
          session.addUser(text);
          taskTitle ??= firstUserExcerpt([{ role: "user", content: textStr }]);
          skillRound++; // 新一轮:用于关联本轮 skill 加载(skillSink.loaded);模型从常驻技能列表按需加载,无 discovery 预筛。
          if (up.additionalContext) session.messages.push({ role: "system", content: `[hook 注入的上下文]\n${up.additionalContext}` });
          return true;
        },
        run: async (signal, boundary) => {
          const outcome = await withPresence(() => runTurn({
            session,
            config: cfg, // 活引用(不是快照)——账号切换要在同一次 runTurn 调用期间立刻生效
            registry,
            ctx,
            auditSink: cacheSink,
            auditId: { agent: "main", depth: 0 },
            gate,
            streamChat,
            executeToolCalls,
            write: () => {},
            compact: inkCompact, // L2.2 反应式压缩
            shouldCompact: () => contextTokens() >= CONTEXT_WINDOW * 0.85, // §4 轮内主动压缩
            diagnose: makeDiagnose(signal), // P2-11 编辑后诊断
            reflect: reflectChallengerFlag ? reflect : undefined, // 轮内卡住检测(assessTurn→挑战者);默认关闭,--reflect-challenger 才开
            progressAdvice: progressAdviceFlag, // 进度提醒(noProgress 计数器);仅 headless 默认开,交互式默认关;--no-progress-advice 显式关
            interactive: interactiveSession, // 进度提醒里"卡住了用 AskUserQuestion"这条只在真交互态才建议
            longTask,
            drainAdvisories: () => pendingReflectAdvisories.splice(0), // 反思器+(暂留)reply 的 advisory
            drainMcpNotices: () => mcpChangeQueue.splice(0), // MCP server 状态变化:回合边界回灌,不插进 tool_use/result 中间
            drainEnvNotices: () => envNoticeQueue.splice(0), // 环境探测补充:回合边界回灌(Task 5 新增)
            backgroundRuntime, onBoundary: boundary,
            listOtherAccounts: () => listAccounts().filter((a) => !a.active).map((a) => ({ name: a.name })), // 限流菜单用
            switchAccountAndWait,
            events: deck?.events(logEvents(uiEvents, store)) ?? logEvents(uiEvents, store), // 渲染的同时写日志
            // 主会话不限轮数:靠 token 预算触发自动 compact;DAO_MAX_TURNS 可设硬上限(eval 用)。
            signal,
            onCheckpoint: persist, // 每个工具轮落一次盘,回合中途异常上抛也不连带丢掉此前已成功的步骤
          }));
          if (outcome.kind !== "completed") return outcome;
          store.append({ t: "turn_end" });
          // 回合末统一反思:记忆 + 方向。自适应节奏;压缩前同步先抢救。
          {
            const compactionImminent = contextTokens() >= CONTEXT_WINDOW * 0.85;
            if (compactionImminent || REFLECT_SYNC) await maybeReflect({ compactionImminent });
            else void maybeReflect({ compactionImminent });
          }
          if (contextTokens() >= CONTEXT_WINDOW * 0.85) {
            const before = session.messages.length;
            uiEvents.notice("[接近上限,自动压缩…]");
            await inkCompact();
            store.append({ t: "compaction", before, after: session.messages.length });
          }
          persist(); // 回合末存档(崩溃可恢复)
          return outcome;
        },
      });
      activeScheduler = scheduler;
      connectDeck(scheduler);
      scheduler.recover();
      await runInkApp({
        welcome,
        skipBanner: firstRun,
        verbose,
        notify, // 审批/提问弹窗时桌面通知(对齐完成一轮的通知),用户切走也能知道 dao 在等确认
        getTabName: () => sessionTitle || taskTitle,
        scheduler,
        bindEvents: (events) => { uiEvents = events; },
        submit: async (text) => { scheduler.submit(text); await scheduler.settled(); },
        runCommand: async (line) => {
          const name = line.trim().slice(1).split(/\s+/)[0] ?? "";
          // 防御：命令名含 / . 等非法字符（如 /Users/xxx/a.png）-> 不是命令，当普通文本。
          if (!/^[a-zA-Z0-9:_-]+$/.test(name)) return { handled: false };
          if (name === "quit" && line.includes("--keep-background")) {keepBackgroundOnExit=true;return {handled:true,exit:true};}
          if(name === "recovery") return {handled:true,output:await recoveryCommand(line)};
          if (name === "clear") {
            scheduler.reset();
            const result = dispatchCommand(line, session, cfg.provider);
            taskTitle = undefined; // 只清自动摘录,保留 /rename 的手动标题。
            persist();
            return result;
          }
          if (name === "skills") {
            const rest = line.trim().split(/\s+/).slice(1);
            const sub = rest[0];
            const bundledCore = BUNDLED_SKILLS.filter((b) => b.core);
            const bundledNames = bundledCore.map((b) => b.name);
            const persist = () => { try { writeFileSync(disabledPath, JSON.stringify([...disabledSet])); } catch {} };
            const installedNames = diskSkills.map((s) => s.name);
            // 批量开关:/skills <bundled|installed|all> off|on(bundled=内置,installed=第三方/项目·用户·插件,all=全部)
            if ((sub === "bundled" || sub === "installed" || sub === "all") && (rest[1] === "off" || rest[1] === "on")) {
              const names = sub === "bundled" ? bundledNames : sub === "installed" ? installedNames : [...bundledNames, ...installedNames];
              const label = sub === "bundled" ? "内置" : sub === "installed" ? "第三方" : "全部";
              toggleBundled(disabledSet, names, rest[1] === "on");
              persist();
              return { handled: true, output: `已${rest[1] === "on" ? "开启" : "关闭"}${label}技能(${names.length} 个,重启 dao 生效)` };
            }
            if (sub === "off" || sub === "on") {
              const target = rest[1];
              const known = target && (bundledNames.includes(target) || diskSkills.some((s) => s.name === target));
              if (!known) return { handled: true, output: `未知技能:${target ?? "(空)"}。/skills 看列表;批量用 /skills <bundled|installed|all> off|on` };
              if (sub === "off") disabledSet.add(target!); else disabledSet.delete(target!);
              persist();
              return { handled: true, output: `已${sub === "off" ? "禁用" : "启用"}技能 ${target}(重启 dao 生效)` };
            }
            // 列表:内置 + 项目/用户。内置被同名磁盘技能覆盖时标注,避免"静默消失"。
            const bundledRows = bundledCore.map((b) => {
              const shadow = diskNames.has(b.name);
              const state = shadow ? "▷ 覆 " : disabledSet.has(b.name) ? "○ off" : "● on ";
              const tag = shadow ? `内置·被${skillSource(diskSkills.find((s) => s.name === b.name)!)}覆盖` : "内置";
              return `${state}  ${b.name}  ·  ${tag}  ·  ~${skillTokens(b)} tok  ·  ${b.description.slice(0, 48)}`;
            });
            const diskRows = diskSkills.map((s) => `${disabledSet.has(s.name) ? "○ off" : "● on "}  ${s.name}  ·  ${skillSource(s)}  ·  ~${skillTokens(s)} tok  ·  ${s.description.slice(0, 48)}`);
            const rows = [...bundledRows, ...diskRows];
            const bundledOn = bundledCore.filter((b) => !disabledSet.has(b.name) && !diskNames.has(b.name)).length;
            const diskOn = diskSkills.filter((s) => !disabledSet.has(s.name)).length;
            const head = `技能(内置 ${bundledOn}/${bundledCore.length} 开 · 第三方 ${diskOn}/${diskSkills.length} 开;on 的描述常驻上下文、模型按需加载正文)`;
            const foot = `/skills off|on <名> 开关单个(内置也可关);/skills <bundled|installed|all> off|on 批量(内置/第三方/全部);重启生效`;
            return { handled: true, output: `${head}\n${rows.join("\n")}\n${foot}` };
          }
          if (name === "context") {
            const used = contextTokens();
            const pct = Math.round((used / CONTEXT_WINDOW) * 100);
            const sys = estimateTokens(session.messages.slice(0, 1));
            // 工具定义 token：用 apiTools（已生成的 JSON schema 描述）粗估
            const toolTok = apiTools.reduce((s, t) => s + Math.ceil((JSON.stringify(t).length) / 3), 0);
            // 技能 frontmatter token（on 的技能描述常驻上下文）
            const onBundled = BUNDLED_SKILLS.filter((b) => b.core && !disabledSet.has(b.name) && !diskNames.has(b.name));
            const onDisk = diskSkills.filter((s) => !disabledSet.has(s.name));
            const skillTok = [...onBundled, ...onDisk].reduce((s, sk) => s + skillTokens(sk), 0);
            // 消息历史细分
            const histMsgs = session.messages.slice(1);
            let assistantTok = 0, userTok = 0, toolCallTok = 0, toolResultTok = 0;
            for (const m of histMsgs) {
              if (m.role === "assistant") {
                if (typeof m.content === "string") assistantTok += Math.ceil(m.content.length / 3);
                if (m.tool_calls) for (const tc of m.tool_calls) toolCallTok += Math.ceil((tc.function.name.length + tc.function.arguments.length) / 3);
              } else if (m.role === "user") {
                if (typeof m.content === "string") userTok += Math.ceil(m.content.length / 3);
                else if (Array.isArray(m.content)) for (const p of m.content) { if (p.type === "text") userTok += Math.ceil(p.text.length / 3); else userTok += 100; }
              } else if (m.role === "tool") {
                const c = m.content as string | unknown[];
                const len = typeof c === "string" ? c.length : JSON.stringify(c).length;
                toolResultTok += Math.ceil(len / 3);
              }
            }
            const histTok = assistantTok + userTok + toolCallTok + toolResultTok;
            // MCP 工具
            const mcpToolCount = registry.countMcpTools();
            const mcpActiveCount = mcp.connectedCount;
            // 自动压缩缓冲区
            const bufferTok = Math.round(CONTEXT_WINDOW * 0.15);
            const freeTok = Math.max(0, CONTEXT_WINDOW - used);
            // API 实际用量（本会话累计）
            const u = session.usage;
            const cacheRatio = u.promptTokens > 0 ? ((u.cacheHitTokens / u.promptTokens) * 100).toFixed(1) : "—";
            // 优化建议
            const suggestions: string[] = [];
            if (used > 0 && toolTok > used * 0.15) suggestions.push(`工具定义占 ${Math.round(toolTok / used * 100)}%（/mcp off 关不用的 server 减少工具数）`);
            if (toolResultTok > histTok * 0.5) suggestions.push(`工具结果占对话 ${Math.round(toolResultTok / Math.max(1, histTok) * 100)}%（/compact 压缩历史）`);
            if (skillTok > 5000) suggestions.push(`技能描述占 ~${skillTok.toLocaleString()} tok（/skills off <名> 关不需要的）`);
            if (pct >= 85) suggestions.push("接近上限，下回合将自动压缩（也可 /compact 主动压缩）");
            if (suggestions.length === 0) suggestions.push("余量充足，无需操作");

            const fmt = (n: number) => n.toLocaleString();
            const bar = (ratio: number) => {
              const w = 20;
              const filled = Math.round(ratio * w);
              return "█".repeat(filled) + "░".repeat(w - filled);
            };
            const lines = [
              `上下文用量  ${bar(used / CONTEXT_WINDOW)}  ${fmt(used)} / ${fmt(CONTEXT_WINDOW)} tok (${pct}%)`,
              `模型: ${session.model}`,
              "",
              "┌─ 分类明细 ──────────────────────────────┐",
              `  系统提示      ${fmt(sys).padStart(8)} tok  ${(sys / CONTEXT_WINDOW * 100).toFixed(1)}%`,
              `  工具定义      ${fmt(toolTok).padStart(8)} tok  ${(toolTok / CONTEXT_WINDOW * 100).toFixed(1)}%`,
              mcpToolCount > 0 ? `  MCP 工具      ${mcpToolCount} 个（${mcpActiveCount} server 连接中）` : null,
              `  技能描述      ${fmt(skillTok).padStart(8)} tok  ${onBundled.length + onDisk.length} 个启用`,
              `  对话历史      ${fmt(histTok).padStart(8)} tok`,
              `    ├ assistant ${fmt(assistantTok).padStart(8)} tok`,
              `    ├ user      ${fmt(userTok).padStart(8)} tok`,
              `    ├ tool_call ${fmt(toolCallTok).padStart(8)} tok`,
              `    └ tool_result ${fmt(toolResultTok).padStart(6)} tok`,
              `  压缩缓冲区    ${fmt(bufferTok).padStart(8)} tok  (15% 预留)`,
              `  剩余空间      ${fmt(freeTok).padStart(8)} tok`,
              "└──────────────────────────────────────────┘",
              "",
              `API 累计:输入 ${fmt(u.promptTokens)} · 输出 ${fmt(u.completionTokens)} · 缓存命中 ${cacheRatio}%`,
              "",
              ...suggestions.map((s) => `  • ${s}`),
            ].filter((l) => l !== null);
            return { handled: true, output: lines.join("\n") };
          }
          if (name === "tasks") {
            const r = taskManager.running();
            if (r.length === 0) return { handled: true, output: "无运行中的后台任务。" };
            return { handled: true, output: `后台任务(${r.length}):\n` + r.map((t) => `  ${t.id} · ${t.status} · ${t.description}`).join("\n") };
          }
          if (name === "mcp") {
            const rest = line.trim().split(/\s+/).slice(1);
            const sub = rest[0] ?? "";
            // /mcp reconnect <name>
            if (sub === "reconnect" && rest[1]) {
              mcp.reconnect(rest[1]).then(() => {}).catch(() => {});
              return { handled: true, output: `正在重连 MCP server「${rest[1]}」…(完成后会通知)` };
            }
            // /mcp toggle <name> [on|off]:不带 on/off 时真正"翻转"当前状态(查当前是否禁用取反),
            // 不再固定解读成"开启"——之前 rest[2] !== "off" 导致不带参数调用永远等于开启,对一个
            // 已经启用的 server 完全没法用这条命令关掉它,和"toggle"这个名字的直觉相悖。
            if (sub === "toggle" && rest[1]) {
              const explicit = rest[2] === "on" ? true : rest[2] === "off" ? false : undefined;
              const currentlyDisabled = mcp.getServerStatus().find((s) => s.name === rest[1])?.disabled ?? false;
              const on = explicit ?? currentlyDisabled;
              mcp.toggle(rest[1], on).then(() => {}).catch(() => {});
              return { handled: true, output: `正在${on ? "启用" : "禁用"} MCP server「${rest[1]}」…` };
            }
            // /mcp add <name> <command> [args...]
            if (sub === "add" && rest[1] && rest[2]) {
              const serverName = rest[1]!;
              const cmd = rest[2]!;
              const args = rest.slice(3);
              mcp.addServer(serverName, { command: cmd, args }, mcpConfigFiles).then(() => {}).catch(() => {});
              return { handled: true, output: `正在添加 MCP server「${serverName}」…` };
            }
            // /mcp(无子命令)-- 列表展示
            const statuses = mcp.getServerStatus();
            if (statuses.length === 0) return { handled: true, output: "未配置 MCP 服务器。在 ~/.dao/mcp.json 或 <项目>/.dao/mcp.json 写 mcpServers 即可。" };
            return { handled: true, output: "MCP 服务器:\n" + statuses.map((s) => `  ${s.disabled ? "⊘" : s.ok ? "✓" : "✗"} ${s.name} · ${s.tools} 工具${s.error ? ` · ${s.error}` : ""}${s.disabled ? " · 已禁用" : ""}`).join("\n") + "\n\n用法: /mcp reconnect <name> | /mcp toggle <name> [on|off] | /mcp add <name> <command> [args...]" };
          }
          if (name === "diff") {
            try {
              const status = execSync("git status --short", { cwd: workspaceRoot, encoding: "utf8" }).trim();
              const stat = execSync("git diff --stat", { cwd: workspaceRoot, encoding: "utf8" }).trim();
              if (!status && !stat) return { handled: true, output: "无未提交变更。" };
              return { handled: true, output: (status ? `变更文件:\n${status}\n` : "") + (stat ? `\n${stat}` : "") };
            } catch (e) { return { handled: true, output: `git 失败(可能非 git 仓库):${(e as Error).message}` }; }
          }
          if (name === "doctor") {
            const checks: string[] = [];
            checks.push(cfg.apiKey ? `✓ API key 已配置(来源 ${keySource})` : "✗ 缺 API key(设 DEEPSEEK_API_KEY 或写 ~/.dao/config.json)");
            try { checks.push(`✓ dao 在 PATH:${execSync("command -v dao", { encoding: "utf8" }).trim()}`); }
            catch { checks.push("✗ dao 不在 PATH(把 ~/.local/bin 加进 PATH)"); }
            if (process.platform === "darwin") {
              try { execSync(`codesign -v "${process.execPath}" 2>&1`); checks.push("✓ 二进制签名有效"); }
              catch { checks.push("✗ 二进制签名无效 → 重装:npm run bundle:install"); }
            }
            checks.push(`· 工作区 ${workspaceRoot} · 模型 ${session.model} · ${mcp.getServerStatus().length} 个 MCP 服务器`);
            return { handled: true, output: "dao doctor:\n" + checks.map((c) => "  " + c).join("\n") };
          }
          if (name === "memory") {
            const tiers: [string, string][] = [["用户", userMemoryDir], ["知识", knowledgeMemoryDir], ["项目", projectMemoryDir]];
            const rest = line.trim().split(/\s+/).slice(1);
            const today = new Date().toISOString().slice(0, 10);
            if (rest[0] === "delete" || rest[0] === "rm" || rest[0] === "forget") {
              const targets = rest.slice(1);
              if (!targets.length) return { handled: true, output: "用法:/memory delete <名> [名…](名见 /memory 审核报告)" };
              const done: string[] = [], miss: string[] = [];
              for (const t of targets) {
                let hit = false;
                for (const [, dir] of tiers) {
                  const fp = path.join(dir, `${t}.md`);
                  try { rmSync(fp); hit = true; break; } catch { /* 该层没有 */ }
                }
                (hit ? done : miss).push(t);
              }
              return { handled: true, output: `${done.length ? `已删除:${done.join(", ")}` : ""}${miss.length ? `\n未找到:${miss.join(", ")}` : ""}`.trim() || "无操作" };
            }
            return { handled: true, output: formatAudit(gatherAudit(tiers, today), today) };
          }
          if (name === "permissions") {
            const r = getRules();
            const fmt = (label: string, arr: string[]) => `${label}:${arr.length ? arr.join(", ") : "(无)"}`;
            return { handled: true, output: `权限规则(模式 ${getMode()};deny>ask>allow):\n  ${fmt("allow", r.allow)}\n  ${fmt("ask", r.ask)}\n  ${fmt("deny", r.deny)}\n(改 .dao/settings.json 的 permissions)` };
          }
          if (name === "session") {
            const title = sessionTitle ? sessionTitle : "(未命名,用 /rename 命名)";
            const cachePath = path.join(store.dir, "cache.jsonl");
            return { handled: true, output:
              `会话 · ${store.id}\n` +
              `  标题:${title}\n` +
              `  目录:${store.dir}\n` +
              `  工作区:${workspaceRoot}\n` +
              `  模型:${session.model} · 模式:${session.mode}\n` +
              `  消息:${session.messages.length} 条\n` +
              `  缓存审计:${cachePath}(/audit cache 查看)` };
          }
          if (name === "audit") {
            const parts = line.trim().split(/\s+/);
            const sub = parts[1];
            const id = parts[2];
            const dir = id ? path.join(sessionsDir, id) : store.dir;
            const valid = ["memory", "reflect", "tools", "perms", "cache", "skills", "all"];
            if (!sub || !valid.includes(sub)) return { handled: true, output: `用法:/audit <memory|reflect|tools|perms|cache|skills|all> [会话id]\n默认审当前会话(${store.id})。` };
            const readJsonl = (file: string): Record<string, unknown>[] => {
              try {
                return readFileSync(path.join(dir, file), "utf8").trim().split("\n").filter(Boolean)
                  .flatMap((l) => { try { return [JSON.parse(l)]; } catch { return []; } });
              } catch { return []; }
            };
            const sections: string[] = [];
            const want = (k: string) => sub === "all" || sub === k;
            if (want("memory")) sections.push(formatMemoryReport(summarizeMemoryTrace(readJsonl("memory-trace.jsonl") as never)));
            if (want("reflect")) sections.push(formatReflectReport(summarizeReflectTrace(readJsonl("memory-trace.jsonl") as never)));
            if (want("tools")) sections.push(formatToolReport(summarizeToolTrace(readJsonl("tool-trace.jsonl") as never)));
            if (want("perms")) sections.push(formatPermReport(summarizePermTrace(readJsonl("perm-trace.jsonl") as never)));
            if (want("cache")) sections.push(formatCacheReport(readJsonl("cache.jsonl") as never));
            if (want("skills")) sections.push(formatSkillReport(summarizeSkillTrace(readAllSkillTraces(sessionsDir))));
            const head = `审计 · 会话 ${id ?? store.id} · 目录 ${dir}\n`;
            return { handled: true, output: head + sections.join("\n\n") };
          }
          if (name === "resume") {
            const id = line.trim().split(/\s+/)[1];
            // P3-29 秒列:只读轻量 meta(不解析整份 state.json),并按最近更新排序。
            const metas = listSessions(sessionsDir);
            if (metas.length === 0) return { handled: true, output: "本工作区无历史会话。" };
            if (!id) return { handled: true, output: `历史会话(${metas.length}):\n` + metas.slice(0, 15).map((m) => `  ${m.id}${m.title ?? m.summary ? ` — ${m.title ?? m.summary}` : ""}${m.done ? "" : " ·未完成"}`).join("\n") + "\n用 /resume <会话id> 载入其上下文。" };
            const st = loadState(sessionsDir, id);
            if (!st) return { handled: true, output: `未找到会话:${id}(/resume 看列表)` };
            // 恢复原会话身份；先保存当前会话，再转移 owner 与运行时。
            if(id===store.id)return {handled:true,output:"当前已在此会话。"};
            if(taskManager.running().length)return {handled:true,output:"仍有子代理运行，请先停止后再切换。"};
            scheduler.pause(); await scheduler.settled(); persist();
            const next=createSessionStore(sessionsDir,id,{cwd:workspaceRoot,durable:true});
            processManager.detach(); taskManager.clearRestored();
            scheduler.reset(); store.close?.(); store=next;
            session.messages=st.storageVersion===2?st.messages:sanitizeHistoryForResume(st.messages);
            session.setModel(st.model);session.mode=st.mode;Object.assign(session.usage,st.usage);sessionTitle=st.title;
            taskTitle = st.taskTitle ?? firstUserExcerpt(st.messages);
            await bindStore(store); exitSessionId=store.id;setObsSession(store.id);
            persist();scheduler.recover();
            // 重放末段对话作回顾,让用户一眼看到"上次做到哪"(只取文本 user/assistant,末 6 条)。
            const recap = transcriptFromMessages(st.messages);
            const tail = recap.slice(-6);
            const resumeItems: TranscriptItem[] = tail.length
              ? [{ id: 0, kind: "notice", text: `── 会话 ${id} 最近对话(共 ${st.messages.length} 条消息,显示末 ${tail.length} 条)──` }, ...tail]
              : [];
            return { handled: true, output: `✓ 已恢复会话 ${id}，继续写入原会话。`, clearTranscript: true, resumeItems };
          }
          if (name === "branch") {
            const label = line.trim().split(/\s+/).slice(1).join(" ");
            const b = createSessionStore(sessionsDir); // 新会话 id
            b.saveState({ cwd: workspaceRoot, model: session.model, mode: session.mode, title: label || undefined, taskTitle, messages: session.messages, backgroundWait: backgroundRuntime.activeWaits > 0, usage: { ...session.usage } });
            return { handled: true, output: `已把当前会话快照分支为 ${b.id}${label ? `(${label})` : ""}。\n切到该分支上下文:/resume ${b.id}(当前会话不受影响)` };
          }
          if (name === "rename") {
            const t = line.trim().split(/\s+/).slice(1).join(" ").trim();
            if (!t) return { handled: true, output: `用法:/rename <标题>${sessionTitle ? `(当前:${sessionTitle})` : ""}` };
            sessionTitle = t;
            persist();
            return { handled: true, output: `会话已命名:${t}` };
          }
          if (name === "rewind") {
            const arg = line.trim().split(/\s+/)[1];
            const userIdx = session.messages.map((m, i) => (m.role === "user" ? i : -1)).filter((i) => i >= 0);
            if (userIdx.length === 0) return { handled: true, output: "本会话还没有可回退的节点。" };
            if (!arg) {
              const list = userIdx.map((idx, n) => {
                const c = session.messages[idx]!.content;
                return `  ${n + 1}. ${(typeof c === "string" ? c : "").replace(/\n/g, " ").slice(0, 60)}`;
              });
              return { handled: true, output: `回退节点(到第几条用户消息【之前】):\n${list.join("\n")}\n用 /rewind <序号> 截断对话;/rewind <序号> code 同时回滚文件(影子 git,不动你的真实提交)` };
            }
            const rest = line.trim().split(/\s+/).slice(1);
            const n = Number(rest[0]);
            const withCode = rest.includes("code");
            if (!Number.isInteger(n) || n < 1 || n > userIdx.length) return { handled: true, output: `序号越界(1–${userIdx.length})` };
            session.messages = session.messages.slice(0, userIdx[n - 1]); // 丢弃该用户消息及其后
            let codeMsg = "";
            if (withCode) {
              const sha = turnCheckpoints[n - 1];
              if (!ckpt.enabled) codeMsg = " 文件未回滚(影子 git 未开启,可在 settings.json 设 checkpoint.enabled = true)。";
              else if (!sha) codeMsg = " 文件未回滚(该节点无快照)。";
              else {
                ckpt.snapshot("回退前自动快照"); // 先存当前状态,回退可逆
                codeMsg = ckpt.restore(sha) ? " 文件已回滚到该节点(真实 git 提交未动;回退前状态已存为\"回退前自动快照\")。" : " 文件回滚失败。";
              }
            }
            return { handled: true, output: `已回退到第 ${n} 条用户消息之前(现 ${session.messages.length} 条消息)。${codeMsg || "(对话回退;加 code 可同时回滚文件)"}`, clearTranscript: true };
          }
          if (name === "export") {
            const ts = new Date().toISOString().replace(/[:.]/g, "-");
            const dir = path.join(workspaceRoot, ".dao", "exports");
            mkdirSync(dir, { recursive: true });
            const file = path.join(dir, `session-${ts}.md`);
            const md = session.messages
              .map((m) => `## ${m.role}\n\n${typeof m.content === "string" ? m.content : JSON.stringify(m.content, null, 2)}`)
              .join("\n\n---\n\n");
            writeFileSync(file, md);
            return { handled: true, output: `已导出对话 → ${file}(${session.messages.length} 条消息)` };
          }
          if (name === "Config") {
            return { handled: true, output: `配置:\n  模型 ${cfg.model} · baseUrl ${cfg.baseUrl} · 权限模式 ${getMode()}\n  账户 profile ${profilesCfg.activeProfile} · key 来源 ${keySource}(/account 管理多 key)\n  设置文件:~/.dao/settings.json(用户)· <项目>/.dao/settings.json · .dao/settings.local.json\n(编辑这些文件改配置;权限规则见 /permissions,MCP 见 ~/.dao/mcp.json)` };
          }
          if (name === "effort") {
            const valid = ["low", "medium", "high", "max"];
            const arg = line.trim().split(/\s+/)[1];
            const cur = process.env.DAO_REASONING_EFFORT || "max";
            if (!arg) return { handled: true, output: `当前思考强度:${cur}。用法:/effort <${valid.join("|")}>` };
            if (!valid.includes(arg)) return { handled: true, output: `无效:${arg}(可选 ${valid.join("/")})` };
            process.env.DAO_REASONING_EFFORT = arg;
            return { handled: true, output: `思考强度已设为 ${arg}(下一回合生效)` };
          }
          if (name === "context-window") {
            const arg = line.trim().split(/\s+/)[1];
            const fmtTok = (n: number) => n.toLocaleString();
            if (!arg) {
              return { handled: true, output: `当前上下文窗口:${fmtTok(CONTEXT_WINDOW)} tok(${(CONTEXT_WINDOW / 1000).toFixed(0)}K)。\n用法:\n  /context-window 200K  — 200,000 tok\n  /context-window 1M    — 1,000,000 tok\n  /context-window 500   — 自定义,单位 K(即 500,000 tok)` };
            }
            // 解析:200K / 1M / 纯数字(单位 K)
            const m = arg.match(/^(\d+(?:\.\d+)?)\s*([KkMm])?$/);
            if (!m) return { handled: true, output: `无效格式:「${arg}」。用法:/context-window <200K|1M|<数字>K>(纯数字单位为 K)` };
            const num = Number(m[1]);
            const unit = (m[2] ?? "K").toUpperCase();
            const tok = unit === "M" ? num * 1_000_000 : num * 1_000;
            if (tok < 1000) return { handled: true, output: `上下文窗口过小(${tok} tok),最小 1K。` };
            CONTEXT_WINDOW = tok;
            process.env.DAO_CONTEXT_WINDOW = String(tok);
            contextWindowManuallySet = true; // 手动设过后锁死,后续切模型不再自动联动
            return { handled: true, output: `上下文窗口已设为 ${fmtTok(tok)} tok(${(tok / 1000).toFixed(0)}K),自动压缩阈值 ${fmtTok(Math.round(tok * 0.85))} tok(85%)。立即生效。` };
          }
          if (name === "status") {
            const pct = Math.round((contextTokens() / CONTEXT_WINDOW) * 100);
            const flags = [yolo ? "免审批" : "", longTask ? "长任务" : ""].filter(Boolean).join("/") || "—";
            return { handled: true, output: `状态:模型 ${session.model} · 模式 ${getMode()} · 开关 ${flags} · 上下文 ${pct}% · 思考 ${process.env.DAO_REASONING_EFFORT || "max"}${obsLabel() ? ` · ${obsLabel()}` : ""}\n${session.usageSummary()}` };
          }
          if (name === "plugin") {
            if (installedPlugins.length === 0) return { handled: true, output: "未装插件。装:dao plugin add <git-url|路径>(插件根需 plugin.json + skills/)。" };
            const lines = installedPlugins.map((p) => {
              const n = diskSkills.filter((s) => s.dir.startsWith(p.dir)).length;
              return `  ${p.name} · ${n} 技能 · ${p.description}`;
            });
            return { handled: true, output: `已装插件(${installedPlugins.length}):\n` + lines.join("\n") + "\n(增删:dao plugin add/remove,重启生效)" };
          }
          if (name === "hooks") {
            const lines = hooks.map((h) => `  ${h.event}${h.matcher ? `[${h.matcher}]` : ""}: ${h.type === "command" ? h.command : h.type}`);
            if (lines.length === 0) return { handled: true, output: "未配置 hooks。在 ~/.dao/hooks.json 或 <项目>/.dao/hooks.json 配(事件:PreToolUse/PostToolUse/UserPromptSubmit/SessionStart/SessionEnd)。" };
            return { handled: true, output: `已配置 hooks:\n${lines.join("\n")}` };
          }
          if (name === "agents") {
            const types = (ctx.agentDefinitions ?? []).filter((d) => d.source !== "built-in");
            if (types.length === 0) return { handled: true, output: "无自定义子代理类型(默认通用子代理可用)。在 .dao/agents/ 定义后用 agent 工具的 agent_type 调。" };
            return { handled: true, output: `可用子代理类型(${types.length}):\n` + types.map((t) => `  ${t.agentType} — ${t.whenToUse}`).join("\n") };
          }
          if (name === "files") {
            const files = [...(ctx.readFiles ?? [])].map((f) => path.relative(workspaceRoot, f) || f);
            if (files.length === 0) return { handled: true, output: "本会话尚未读取任何文件。" };
            return { handled: true, output: `上下文中读过的文件(${files.length}):\n` + files.slice(0, 50).map((f) => "  " + f).join("\n") + (files.length > 50 ? `\n  …等共 ${files.length} 个` : "") };
          }
          if (name === "copy") {
            const last = [...session.messages].reverse().find((m) => m.role === "assistant" && typeof m.content === "string" && (m.content as string).trim());
            if (!last) return { handled: true, output: "没有可复制的回答。" };
            const text = last.content as string;
            const cmd = process.platform === "darwin" ? "pbcopy" : process.platform === "win32" ? "clip" : "xclip -selection clipboard";
            try { execSync(cmd, { input: text }); return { handled: true, output: `已复制最后一条回答到剪贴板(${text.length} 字)。` }; }
            catch { return { handled: true, output: "复制失败(未找到剪贴板工具:macOS 用 pbcopy,Linux 装 xclip)。" }; }
          }
          if (name === "btw") {
            const note = line.trim().split(/\s+/).slice(1).join(" ").trim();
            if (!note) return { handled: true, output: "用法:/btw <随手备注>(加入上下文供模型参考,不触发动作)" };
            session.messages.push({ role: "system", content: `[用户备注] ${note}` });
            return { handled: true, output: "已记入上下文(下次回复时模型会看到)。" };
          }
          // /account 无参的选择器交互由 App 拦截;这里处理带参的文本路径(add/rm/切换/列表)。
          if (name === "account" || name === "accounts") {
            const [target, ...restA] = line.trim().split(/\s+/).slice(1);
            if (target === "add") {
              const key = restA[0];
              if (!key) return { handled: true, output: "用法:/account add <key> [provider] [name](provider 缺省 deepseek,name 缺省自动起名;Ink 下直接 /account 弹➕引导)" };
              const knownProviders = Object.keys(DEFAULTS) as Provider[];
              const providerArg = restA[1] as Provider | undefined;
              if (providerArg && !knownProviders.includes(providerArg)) {
                return { handled: true, output: `未知 provider:${providerArg}(可选:${knownProviders.join(" / ")})` };
              }
              const nameArg = restA[2];
              addAccount(key, nameArg, providerArg ?? "deepseek")
                .then((r) => write(r.ok ? `\n✓ 已添加并切到账户「${r.name}」。\n` : `\n✗ /account add 失败:${accountReasonText(r.reason)}\n`))
                .catch((e) => write(`\n✗ /account add 出错:${e instanceof Error ? e.message : String(e)}\n`));
              return { handled: true, output: "校验中,请稍候…(结果稍后打印)" };
            }
            if (target === "rm" && restA[0]) {
              if (!profilesCfg.profiles[restA[0]]) return { handled: true, output: `无此账户:${restA[0]}` };
              removeAccount(restA[0]);
              return { handled: true, output: `✓ 已删除账户「${restA[0]}」。当前:${profilesCfg.activeProfile}` };
            }
            if (target) {
              if (!profilesCfg.profiles[target]) return { handled: true, output: `无此账户:${target}(/account 看列表)` };
              return switchAccount(target)
                ? { handled: true, output: `✓ 已切到账户「${target}」,下一回合生效。` }
                : { handled: true, output: `切换失败:${target}` };
            }
            // 无参且无选择器(非 Ink/退化):退回文本列表
            const rows = listAccounts();
            const list = rows.length ? rows.map((r) => `${r.active ? "● " : "  "}${r.name} · ${r.detail}`).join("\n") : "  (无,/account add <key> 添加)";
            return { handled: true, output: `账户 · 当前来源 ${keySource}\n${list}\n(Ink 下直接 /account 弹选择器;/account add <key> [provider] [name] 添加 · /account <名> 切换 · /account rm <名> 删除)` };
          }
          if (name === "bypass" || name === "yolo") { // /yolo 保留为别名
            // /yolo 是全权放行的快捷开关(可开可关,与 /mode 全权放行 等价)。
            if (yolo) {
              yolo = false;
              permModeOverride = null;
              return { handled: true, output: "全权放行已关闭:恢复智能判定审批。" };
            }
            session.mode = "normal";
            yolo = true;
            permModeOverride = null;
            return { handled: true, output: "⚡ 全权放行:免审批已开启(权限全交出去,deny 规则与危险命令仍拦)。慎用。" };
          }
          if (name === "mode") {
            const arg = line.trim().split(/\s+/)[1];
            if (!arg) {
              return { handled: true, output: `当前权限模式:${getMode() === "bypassPermissions" ? "全权放行" : getMode() === "auto" ? "智能判定" : getMode()}。Shift+Tab 两档循环:智能判定 → 全权放行;也可 /mode <auto|全权放行|default> 直接指定;plan 只读规划用 /plan 进入` };
            }
            if (arg === "plan") {
              return { handled: true, output: "plan 是只读规划权限模式,不经 /mode 切换——用 /plan(会话只读)或 settings.defaultMode = \"plan\"/`--permission-mode plan` 进入。" };
            }
            if (arg === "yolo" || arg === "bypass" || arg === "bypassPermissions" || arg === "全权放行") {
              session.mode = "normal";
              yolo = true;
              permModeOverride = null;
              return { handled: true, output: "⚡ 全权放行:免审批已开启(权限全交出去,deny 规则与危险命令仍拦)。慎用。" };
            }
            if (arg === "default" || arg === "auto") {
              if (session.mode === "plan") session.mode = "normal";
              yolo = false;
              permModeOverride = arg as PermissionMode;
              return { handled: true, output: arg === "auto" ? "⊙ 智能判定:只读命令/工作区内编辑自动放行;其余(含敏感目标)交 AI 分类器,确信安全的自动过、拿不准的转人工审批(不会替你拒绝);deny 规则/危险命令仍拦。" : "权限模式已设为 default(写/执行前询问)" };
            }
            return { handled: true, output: `未知模式:${arg}(可选 auto / 全权放行 / default)` };
          }
          if (name === "goal" || name === "task") { // task 为旧别名
            const arg = line.trim().slice(1).split(/\s+/).slice(1).join(" ").trim();
            if (arg) {
              // /goal <目标>:确保长任务模式已开,并立即把目标当作一个回合跑(不丢 prompt)。
              if (!longTask) {
                longTask = true;
                // 自主模式用 auto(AI 判定自动批准),而非 yolo 全开——更安全;yolo 只能 --yolo 启动。
                if (!yolo && session.mode !== "plan") permModeOverride = "auto";
                session.messages.push({ role: "system", content: lang === "en" ? LONG_TASK_DIRECTIVE_EN : LONG_TASK_DIRECTIVE });
              }
              return { handled: true, prompt: arg };
            }
            // 无参数:沿用开关语义。
            longTask = !longTask;
            if (longTask) {
              if (!yolo && session.mode !== "plan") permModeOverride = "auto";
              session.messages.push({ role: "system", content: lang === "en" ? LONG_TASK_DIRECTIVE_EN : LONG_TASK_DIRECTIVE });
              return { handled: true, output: lang === "en" ? "∞ Long-task mode enabled: auto approval (AI-judged) + autonomous continuous advancement + higher turn limit. Use /goal <goal> or describe your long task to begin." : "∞ 长任务自主模式已开启:auto 自动批准(AI 判定)+ 自主连续推进 + 更高轮数;直接 /goal <目标> 或说出要做的长任务即可。" };
            }
            if (!yolo) permModeOverride = null;
            return { handled: true, output: lang === "en" ? "Long-task mode disabled (permission mode restored to default)." : "长任务模式已关闭(权限模式恢复 default)。" };
          }
          if (name === "coordinator") {
            // Coordinator 已并入长任务自主模式(阶段化编排现写在 LONG_TASK_DIRECTIVE 里)。保留为别名:开启长任务。
            if (!longTask) {
              longTask = true;
              if (!yolo && session.mode !== "plan") permModeOverride = "auto";
              session.messages.push({ role: "system", content: lang === "en" ? LONG_TASK_DIRECTIVE_EN : LONG_TASK_DIRECTIVE });
            }
            return { handled: true, output: "❖ Coordinator 已并入长任务自主模式:已开启(auto 自动批准 + 自主推进 + 任务大时自动按研究→综合→实现→验证分阶段)。直接说出要做的较大任务即可。" };
          }
          // /permissions add/remove/list:运行时增删权限规则(直接操作 settings 文件)。
          if (name === "permissions") {
            const parts = line.trim().slice(1).split(/\s+/);
            const sub = parts[1] ?? "list";
            const rules = getRules();
            if (sub === "list") {
              const fmt = (k: "allow" | "ask" | "deny") => rules[k].length
                ? rules[k].map(r => `  ${r}  ${ruleSources.get(`${k}:${r}`) ? `(${ruleSources.get(`${k}:${r}`)})` : "(session/cli)"}`).join("\n")
                : "  (无)";
              return { handled: true, output: `权限规则:\n[deny]\n${fmt("deny")}\n[ask]\n${fmt("ask")}\n[allow]\n${fmt("allow")}` };
            }
            if (sub === "add" || sub === "remove") {
              const kind = (parts[2] ?? "") as "allow" | "ask" | "deny";
              if (!["allow", "ask", "deny"].includes(kind)) return { handled: true, output: "用法:/permissions add <allow|ask|deny> <规则>  或  /permissions remove <allow|ask|deny> <规则>" };
              const rule = parts.slice(3).join(" ");
              if (!rule) return { handled: true, output: "缺少规则。用法:/permissions add deny Bash(rm:*)" };
              if (sub === "add") {
                appendRuleSync(localSettingsFile, rule, kind);
                // 更新内存
                (loadedPerms[kind] as string[]).push(rule);
                ruleSources.set(`${kind}:${rule}`, localSettingsFile);
                return { handled: true, output: `✓ 已添加 ${kind} 规则:${rule}(写入 ${localSettingsFile})` };
              } else {
                // remove:先查 source 映射找到规则在哪个文件,再删
                const src = ruleSources.get(`${kind}:${rule}`);
                if (!src) return { handled: true, output: `✗ 规则不在任何已加载的 settings 文件中(可能是 session/CLI 规则,无法通过此命令删除):${rule}` };
                const ok = removeRuleSync(src, rule, kind);
                if (ok) {
                  const idx = loadedPerms[kind].indexOf(rule);
                  if (idx >= 0) loadedPerms[kind].splice(idx, 1);
                  ruleSources.delete(`${kind}:${rule}`);
                  return { handled: true, output: `✓ 已移除 ${kind} 规则:${rule}(从 ${src})` };
                }
                return { handled: true, output: `✗ 未在 ${src} 中找到规则:${rule}` };
              }
            }
            return { handled: true, output: "用法:\n  /permissions list\n  /permissions add <allow|ask|deny> <规则>\n  /permissions remove <allow|ask|deny> <规则>" };
          }
          // 内置 prompt 命令(simplify/remember/debug/skillify):展开成 prompt 跑一回合。
          if (name) {
            const args = line.trim().slice(1).split(/\s+/).slice(1).join(" ");
            const b = runBuiltinCommand(name, args);
            if (b) return { handled: true, ...b };
          }
          // 自定义命令:/name [args] → 展开成 prompt 跑一个回合。
          if (name && customCommands.has(name)) {
            const args = line.trim().slice(1).split(/\s+/).slice(1).join(" ");
            return { handled: true, prompt: expandCommand(customCommands.get(name)!.body, args) };
          }
          if (name === "restore") {
            if (!ckpt.enabled) return { handled: true, output: "检查点不可用(影子 git 未开启)。可在 settings.json 设置 checkpoint.enabled = true 开启。" };
            const snaps = ckpt.list();
            const target = snaps[1] ?? snaps[0]; // 回退到上一个回合前的快照
            if (!target) return { handled: true, output: "暂无可回退的检查点" };
            ckpt.snapshot("回退前自动快照"); // 先存当前状态,使回退本身可逆(防丢未快照的手动改动)
            const ok = ckpt.restore(target.ref);
            return { handled: true, output: ok ? `已回退工作区到检查点:${target.label}(回退前状态已存为"回退前自动快照",可再 /restore 找回)` : "回退失败" };
          }
          // 通用技能手动调用(对齐 CC 的 /skill-name):/<slug> → 把 user-invocable 技能正文当 prompt 跑一回合。
          // 放在最后(已知命令之后);排除保留命令名,避免遮蔽。
          if (name && !["model", "clear", "compact", "cost", "help", "exit"].includes(name)) {
            const sk = findUserInvocableSkill(skills, name);
            if (sk) return { handled: true, prompt: sk.body };
          }
          // /model:委托 dispatchCommand 切换会话模型，并持久化到当前 profile 的 model 字段（下次启动保持）。
          // 自定义网关的 model 不在 MODELS_BY_PROVIDER 里,跳过 dispatchCommand 的校验直接设置。
          if (name === "model") {
            const activeProf = profilesCfg.profiles[profilesCfg.activeProfile];
            const isCustomGw = activeProf && activeProf.baseUrl !== DEFAULTS[activeProf.provider].baseUrl;
            const modelArg = line.trim().split(/\s+/)[1];
            if (isCustomGw && modelArg) {
              session.setModel(modelArg);
              if (activeProf) { activeProf.model = modelArg; saveProfiles(keyFile, profilesCfg).catch(() => {}); }
              // 未手动覆盖时,切模型联动上下文窗口到新模型默认值
              if (!contextWindowManuallySet) {
                CONTEXT_WINDOW = contextWindowFor(session.model, cfg.provider, cfg.baseUrl);
                process.env.DAO_CONTEXT_WINDOW = String(CONTEXT_WINDOW);
              }
              return { handled: true, output: `已切换模型:${modelArg}` };
            }
            const result = dispatchCommand(line, session, cfg.provider);
            if (activeProf) {
              activeProf.model = session.model;
              saveProfiles(keyFile, profilesCfg).catch(() => {});
            }
            // 未手动覆盖时,切模型联动上下文窗口到新模型默认值
            if (!contextWindowManuallySet) {
              CONTEXT_WINDOW = contextWindowFor(session.model, cfg.provider, cfg.baseUrl);
              process.env.DAO_CONTEXT_WINDOW = String(CONTEXT_WINDOW);
            }
            return result;
          }
          return dispatchCommand(line, session, cfg.provider);
        },
        compact: inkCompact,
        getStatus: () => ({
          model: session.model,
          accountName: profilesCfg.activeProfile,
          mode: session.mode,
          permMode: getMode(),
          promptTokens: session.usage.promptTokens,
          completionTokens: session.usage.completionTokens,
          cacheHitRatio: session.cacheHitRatio(),
          costCNY: session.costCNY(),
          yolo,
          longTask,
          branch: readGitBranch(),
          contextPct: (contextTokens() / CONTEXT_WINDOW) * 100,
          contextWindow: CONTEXT_WINDOW,
          contextUsed: contextTokens(),
          version: VERSION,
          sessionId: store.id,
        }),
        cycleMode: () => {
          // Shift+Tab 两档循环:auto(智能判定,AI 裁决)↔ bypassPermissions(全权放行)。
          // plan 只读规划不在循环里(经 /plan/settings 进入);当前若在 plan/default,Shift+Tab 落到 auto。
          const order: PermissionMode[] = ["auto", "bypassPermissions"];
          const cur = getMode();
          const idx = order.indexOf(cur);
          const next = order[(idx + 1) % order.length]!; // idx=-1(plan/default/未知)→ 0 → auto
          yolo = next === "bypassPermissions";
          session.mode = "normal";
          permModeOverride = next === "bypassPermissions" ? null : next;
          return next;
        },
        register: ({ approvalPrompt, askUser, askChoice }) => {
          inkApprovalPrompt = approvalPrompt;
          inkAsk = async (q) => {
            const clear = deck?.attention("question", q);
            try { return await askUser(q); } finally { clear?.(); }
          };
          inkAskChoice = async (q, options, multi) => {
            const clear = deck?.attention("question", q + "\n" + options.join(" / "));
            try { return await askChoice(q, options, multi); } finally { clear?.(); }
          };
        },
        completeFiles: (prefix) =>
          (prefix ? fileCache.filter((f) => f.includes(prefix)) : fileCache).slice(0, 8),
        listResume: () =>
          listSessions(sessionsDir).map((m) => ({
            id: m.id,
            label: `${m.id}${m.title ?? m.summary ? ` — ${m.title ?? m.summary}` : ""}${m.done ? "" : " ·未完成"}`,
          })),
        initialItems,
        listAgentTasks: () => taskManager.all().filter((task) => task.kind === "agent"),
        subscribeTasks: (cb) => backgroundRuntime.subscribe(cb),
        runningTasks: () => backgroundRuntime.running().filter((s) => s.kind === "agent").length,
        runningShells: () => processManager.runningCount(),
        convertForegroundToBackground: () => ctx.foregroundRegistry!.convertAll(),

        listAccounts,
        switchAccount: (n) => { switchAccount(n); },
        removeAccount,
        addAccount,
        fetchGatewayModels: (baseUrl, key) => fetchModels(baseUrl, key),
        listGatewayModels: async () => {
          const p = profilesCfg.profiles[profilesCfg.activeProfile];
          if (!p || p.baseUrl === DEFAULTS[p.provider].baseUrl) return null;
          const cred = await resolveCredential(profilesCfg, kc);
          if (!cred) return null;
          return fetchModels(p.baseUrl, cred.key);
        },
        listSkills,
        setSkillEnabled,
        batchSkills,
        listInvocableSkills,
        listModels,
      });
      scheduler.close();
      taskManager.cancelAll(); // 退出时中止所有后台任务
      await runHooks(hooks, "SessionEnd", { cwd: workspaceRoot }); // 会话结束钩子
      await cleanupDbBackups(workspaceRoot); // 清理本次运行留下的 .dao-backup 安全网文件
      await mcp.close(); // 关闭 MCP 连接
      lspManager.disposeAll(); // 关闭 LSP server 进程
      store.markDone(); // 干净退出 → 标记会话完成(不再被 findResumable 当崩溃会话)
    } else {
      // 非交互(管道/CI/eval):纯文本 banner + readline REPL,行为不变。
      write(buildWelcome(welcomeInfo, caps, undefined, bg) + "\n");
      // 修盲区:非 TTY 也建会话存储 + 审计 sink(此前仅 TTY 分支建,导致 --goal/管道长跑无缓存审计,无从诊断)。
      const sessionsDir = path.join(workspaceRoot, ".dao", "sessions");
      // --continue/-c 在这条路径此前完全没生效(只在 TTY 分支处理过),同一个 dao -c <id> 换成非 TTY
      // 环境(管道/CI/某些嵌入式终端)跑就静默失效——续写同一套逻辑:给了 id 精确续写,没给找最近一个。
      let resumeId: string | undefined;
      if (continueFlag) {
        const prev = cliResumeId ? loadState(sessionsDir, cliResumeId) : findResumable(sessionsDir, workspaceRoot);
        if (prev) {
          // 清洗一遍再装载:防止磁盘上的旧历史里混进过半截/非法 JSON 的 tool_call(真实撞见过——
          // 一个跑着旧代码、迟迟没重启的进程把这类坏消息存进了 state.json,续写时原样加载回来,
          // 下一轮请求又会撞上同一个 400 Invalid request body)。
          session.messages = prev.storageVersion===2 ? prev.messages : sanitizeHistoryForResume(prev.messages);
          if (prev.backgroundWait && prev.storageVersion!==2) session.messages.push({ role: "system", content: "[旧等待未恢复] 上次会话等待的后台执行未被本进程接管,请重新确认任务状态。" });
          session.setModel(prev.model);
          session.mode = prev.mode;
          session.usage.promptTokens += prev.usage.promptTokens;
          session.usage.completionTokens += prev.usage.completionTokens;
          session.usage.cacheHitTokens += prev.usage.cacheHitTokens;
          session.usage.cacheMissTokens += prev.usage.cacheMissTokens;
          resumeId = prev.id;
          write(`[已恢复会话 ${prev.id}]\n`);
        } else if (cliResumeId) {
          write(`[未找到会话 ${cliResumeId},本次将开始新会话]\n`);
        }
      }
      let store = createSessionStore(sessionsDir, resumeId, {cwd:workspaceRoot,durable:true});
      await bindStore(store);
      exitSessionId = store.id;
      setObsSession(store.id); // obs:session id 注入(同交互路径)
      cacheSink = createCacheAuditSink(store.dir);
      memoryAudit = createMemoryAuditSink(store.dir);
      toolAudit = createToolAuditSink(store.dir);
      permAudit = createPermAuditSink(store.dir, getMode);
      ctx.toolAudit = toolAudit; ctx.permAudit = permAudit; ctx.memoryAudit = memoryAudit;
      const readLine = async (): Promise<string | null> => {
        // 托管模式由桥接接收输入,面板重启不会结束当前 Agent。
        if (process.env.DAO_DECK_MANAGED === "1") return await new Promise<null>((resolve) => {
          const stop = () => { activeScheduler?.pause(); process.removeListener("SIGTERM", stop); process.removeListener("SIGINT", stop); resolve(null); };
          process.once("SIGTERM", stop); process.once("SIGINT", stop);
        });
        write("\n> ");
        return nextLine();
      };
      // 修盲区②:这条路径此前建了 store(供 cache/tool/perm 审计 sink),却从没调用过
      // store.saveState()——跟一次性 argvPrompt 路径(补过"state.json 全量 messages"那个
      // 盲区)不一样,这里连一次完整快照都没有,/resume 也找不到东西续。补上:每个工具轮
      // 落一次盘(同交互态/一次性路径的 onCheckpoint 机制),干净退出前再存一次兜底。
      const persistRepl = () =>
        store.saveState({ cwd: workspaceRoot, model: session.model, mode: session.mode, messages: session.messages, backgroundWait: backgroundRuntime.activeWaits > 0, usage: { ...session.usage } });
      await injectSessionStart(); // SessionStart 注入(首回合前)
      const scheduler = new SessionScheduler({ runtime: backgroundRuntime, session, save: persistRepl,
        keepAlive: true, notice: write,
        user: async (text) => {
          const input = typeof text === "string" ? text : JSON.stringify(text);
          const up = await gateUserPrompt(input);
          deck?.input(input, !up.blocked);
          if (up.blocked) { write(`[提交被 hook 阻止] ${up.reason || ""}\n`); return false; }
          session.addUser(text);
          if (up.additionalContext) session.messages.push({ role: "system", content: up.additionalContext });
          return true;
        },
        run: (signal, boundary) => runOneTurn(persistRepl, signal, boundary),
      });
      activeScheduler = scheduler;
      connectDeck(scheduler);
      scheduler.recover();
      await runRepl({ session, readLine, scheduler, runTurn: async () => {}, write, compact: runCompaction, getProvider: () => cfg.provider,
        command: async(line)=>{
          if(/^\/quit\s+--keep-background\s*$/.test(line)){keepBackgroundOnExit=true;return {handled:true,exit:true};}
          const recovery=await recoveryCommand(line);if(recovery!==undefined)return {handled:true,output:recovery};
          if(!/^\/resume\b/.test(line))return {handled:false};
          const id=line.trim().split(/\s+/)[1];
          if(!id)return {handled:true,output:listSessions(sessionsDir,workspaceRoot).map(m=>`${m.id} ${m.title??m.summary??""}`).join("\n")};
          if(id===store.id)return {handled:true,output:"当前已在此会话。"};
          const st=loadState(sessionsDir,id);if(!st)return {handled:true,output:"未找到会话。"};
          if(taskManager.running().length)return {handled:true,output:"请先停止运行中的子代理。"};
          persistRepl();
          const next=createSessionStore(sessionsDir,id,{cwd:workspaceRoot,durable:true});
          processManager.detach();taskManager.clearRestored();scheduler.reset();store.close?.();store=next;
          session.messages=st.storageVersion===2?st.messages:sanitizeHistoryForResume(st.messages);
          session.setModel(st.model);session.mode=st.mode;Object.assign(session.usage,st.usage);
          await bindStore(store);exitSessionId=store.id;setObsSession(store.id);persistRepl();scheduler.recover();
          return {handled:true,output:`已恢复会话 ${id}。`};
        }
      });
      if (scheduler.lastError) throw scheduler.lastError;
      scheduler.close();
      persistRepl(); // 干净退出前再存一次(覆盖最后一轮是"纯文本收尾早退"、没触发过 onCheckpoint 的情形)
      await runHooks(hooks, "SessionEnd", { cwd: workspaceRoot }); // 会话结束钩子(与 TTY 分支对齐)
      await cleanupDbBackups(workspaceRoot); // 清理本次运行留下的 .dao-backup 安全网文件
      await mcp.close();
      lspManager.disposeAll();
      store.markDone(); // 干净退出标记(与 TTY 分支对齐)
    }
    if (session.usage.promptTokens > 0) write(`\n${session.usageSummary()}\n`);
    if (exitSessionId) write(`会话 ${exitSessionId} · 续写:dao -c ${exitSessionId}(或省略 id 续写最近一个)或启动后 /resume ${exitSessionId}\n`);
    // 退出【不再】蒸馏:记忆已在各热回合边界增量捕获;退出时缓存已凉,全量蒸只会撞冷缓存全价。
  } finally {
    deck?.close();
    activeScheduler?.close();
    taskManager.cancelAll();
    backgroundRuntime.dispose();
    if(keepBackgroundOnExit) processManager.detach(); else processManager.reset();
    activeStore?.close?.();
    process.removeListener("SIGTERM",preserveStop);process.removeListener("SIGINT",preserveStop);
    closeRl();
  }
}

// 收尾后显式退出:distill 的 flash HTTP keep-alive socket 等滞留 handle 会让 Node 排不空事件循环、
// 不自然退出(看起来卡在"✓ 记忆无需更新"那行)。要紧的 await(distill/upsert/mcp.close)都已在 main 内完成。
(process.argv[2] === "--dao-shell-runner" && process.argv[3] ? runShellRunner(process.argv[3]) : main()).then(
  async () => { await flushObs(); process.exit(0); },
  (err) => {
    console.error("\n" + (err as Error).message);
    process.exit(1);
  },
);
